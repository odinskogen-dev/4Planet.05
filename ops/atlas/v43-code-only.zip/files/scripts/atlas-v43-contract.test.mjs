/**
 * ATLAS v43 — Founder review fixes of 08 Oct 2026, as contracts.
 *
 * Each test states a promise a visitor can feel. They run on Node ≥ 22 with
 * type stripping (alias-free modules only) and read the committed place files.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync, readdirSync } from "node:fs";

const root = new URL("../", import.meta.url);
const read = (path) => readFileSync(new URL(path, root), "utf8");

/* ── P0: the address bar can never take ATLAS down again ─────────────────── */
test("URL writes are deduplicated and kept far under Safari's 100 per 10 s", async () => {
  let calls = 0;
  const location = { pathname: "/atlas", search: "", hash: "" };
  globalThis.window = {
    location,
    history: {
      state: null,
      replaceState(_s, _t, url) {
        calls += 1;
        const u = new URL(url, "https://4planetatlas.com");
        location.pathname = u.pathname; location.search = u.search; location.hash = u.hash;
      },
    },
  };
  const { replaceAtlasUrl, __resetAtlasUrlBudget } = await import("../src/earth/atlasUrl.ts");
  __resetAtlasUrlBudget();
  for (let i = 0; i < 50; i += 1) replaceAtlasUrl("/atlas?z=2.00");
  assert.equal(calls, 1, "the same URL is written once");
  for (let i = 0; i < 400; i += 1) replaceAtlasUrl(`/atlas?z=${(2 + i / 100).toFixed(2)}`);
  assert.ok(calls <= 40, `at most 40 writes per 10 s (was ${calls})`);
  __resetAtlasUrlBudget();
  delete globalThis.window;
});

test("every ATLAS address-bar write goes through the guarded writer", () => {
  for (const file of ["src/earth/World.tsx", "src/earth/AtlasTimeControls.tsx"]) {
    assert.doesNotMatch(read(file), /history\.replaceState/, `${file} must use replaceAtlasUrl`);
  }
  assert.match(read("src/earth/World.tsx"), /lastFailureRepaint/, "failure repaints are throttled");
});

/* ── P0: images are fully open or not shown ──────────────────────────────── */
test("only fully open image licences are accepted", async () => {
  const { openLicence } = await import("../src/planet/openLicence.ts");
  assert.equal(openLicence("cc-by"), "CC BY");
  assert.equal(openLicence("cc0"), "CC0");
  assert.equal(openLicence("http://creativecommons.org/licenses/by-sa/3.0/"), "CC BY-SA 3.0");
  for (const refused of ["cc-by-nc", "cc-by-nd", "CC_BY_NC_4_0", "https://creativecommons.org/licenses/by-nc-sa/4.0/", "(c) Pierre Noel, all rights reserved", "", undefined]) {
    assert.equal(openLicence(refused), null, `refuses ${refused}`);
  }
  const connectors = read("src/planet/connectors.ts");
  assert.match(connectors, /openLicence\(photo\?\.license_code\)/, "iNaturalist photos pass the licence gate");
  assert.match(connectors, /openLicence\(m\?\.license \|\| m\?\.rights\)/, "GBIF media pass the licence gate");
});

/* ── names a person recognises ───────────────────────────────────────────── */
test("English names are chosen by agreement, not first match", async () => {
  const { bestEnglishName } = await import("../src/planet/englishName.ts");
  assert.equal(bestEnglishName([{ language: "eng", vernacularName: "Renard Roux" }, { language: "eng", vernacularName: "Red Fox", source: "Catalogue of Life" }, { language: "eng", vernacularName: "red fox" }], "Vulpes vulpes"), "Red Fox");
  assert.match(bestEnglishName([{ language: "eng", vernacularName: "Native Scots Pinewood" }, { language: "eng", vernacularName: "Scots pine", preferred: true }], "Pinus sylvestris"), /^Scots pine$/i);
  assert.equal(bestEnglishName([{ language: "fra", vernacularName: "Renard" }], "Vulpes vulpes"), undefined, "no English name → no name");
});

test("map records are titled by binomial, never by citation", () => {
  const layers = read("src/earth/layers.ts");
  assert.match(layers, /const sci = o\.species \|\|/);
  assert.doesNotMatch(layers, /<b class="nm">\$\{esc\(sci\)\}<\/b><br><span class="lat">\$\{esc\(sci\)\}/);
  assert.match(read("src/earth/World.tsx"), /binomialOf\(rawSci\)/);
});

/* ── no layer is ever lost ───────────────────────────────────────────────── */
test("every layer on LIVE (f4914a4 ≡ 5dc63fe) is still registered", () => {
  const ids = new Set([...read("src/earth/layers.ts").matchAll(/\{ id: "([a-z0-9-]+)"/g), ...read("src/earth/atlasLeadingExtensions.ts").matchAll(/id: "([a-z0-9-]+)"/g)].map((m) => m[1]));
  for (const id of ["bluemarble", "truecolor", "sst", "night", "fires", "ndvi", "seaice", "aerosol", "precip", "shade", "forest", "coral", "protected", "biodiv", "whales", "species", "events", "quakes", "emissions", "iss",
    "emodnet-bathymetry", "emodnet-seabed-habitats", "emodnet-dissolved-oxygen-climatology", "emodnet-fishing-vessel-density"]) {
    assert.ok(ids.has(id), `layer ${id} must stay`);
  }
});

test("a renamed layer always leads back to its source", async () => {
  const { layerSource, layerPresentation, LAYER_CATEGORIES } = await import("../src/earth/layerPresentation.ts");
  assert.equal(layerPresentation({ id: "emissions" }).name, "Emission sources");
  assert.deepEqual(layerSource("Climate TRACE"), { name: "Climate TRACE", detail: "Climate TRACE", url: "https://climatetrace.org/" });
  assert.ok(LAYER_CATEGORIES.includes("Sapiens") && !LAYER_CATEGORIES.includes("People"), "People is Sapiens");
  assert.match(read("src/earth/World.tsx"), /className="layer-source"/);
});

/* ── themes ──────────────────────────────────────────────────────────────── */
test("dark ATLAS is Ink + E4RTH green; light ATLAS is Paper + 4PLANET Blue", () => {
  const css = read("src/earth/world.css");
  const dark = css.slice(css.indexOf(':root[data-atlas-theme="dark"]'), css.indexOf("}", css.indexOf(':root[data-atlas-theme="dark"]')));
  assert.match(dark, /--atlas-accent: var\(--atlas-green\)/);
  assert.match(dark, /--atlas-wordmark: var\(--atlas-green\)/);
  assert.match(css, /--atlas-accent: var\(--atlas-blue\);/);
  assert.doesNotMatch(css.replace(/--atlas-blue: #2e2eff;|--blue: var\(--atlas-blue\);|--atlas-accent: var\(--atlas-blue\);|--atlas-wordmark: var\(--atlas-blue\);/g, ""), /var\(--atlas-blue\)/, "nothing paints blue directly; the accent decides");
});

/* ── the family is one tap away, and sign-in travels with you ────────────── */
test("family links leave the ATLAS host for 4planet.org, ATLAS-owned paths stay", async () => {
  const { familyHref } = await import("../src/seo/ownership.ts");
  assert.equal(familyHref("/", "4planetatlas.com"), "https://4planet.org/");
  assert.equal(familyHref("/missions", "4planetatlas.com"), "https://4planet.org/missions");
  assert.equal(familyHref("/places", "4planetatlas.com"), "/places");
  assert.equal(familyHref("/missions", "4planet.org"), "/missions");
  const identity = read("src/identity/identityClient.ts");
  assert.match(identity, /export async function navigateWithIdentity/);
  assert.match(identity, /export function hasStoredIdentitySession/);
  assert.match(read("src/earth/AtlasSavedViews.tsx"), /if \(!hasStoredIdentitySession\(\)\) return;/, "anonymous visitors do not load the auth SDK");
});

/* ── places: every point on Earth can be named ──────────────────────────── */
const places = new URL("../public/atlas-data/places/v1/", import.meta.url);
test("the place files are present, sourced and licensed", () => {
  const manifest = JSON.parse(readFileSync(new URL("manifest.json", places), "utf8"));
  assert.equal(manifest.cellDegrees, 5);
  assert.equal(readdirSync(new URL("cells/", places)).length, 2592, "every 5° cell of the planet");
  for (const source of manifest.sources) {
    assert.ok(source.licence && source.attribution && /^[0-9a-f]{64}$/.test(source.sha256), `${source.id} carries licence, attribution and checksum`);
  }
  assert.ok(manifest.counts.towns > 100_000 && manifest.counts.country > 200 && manifest.counts.marine > 250);
});

async function withLocalPlaces(run) {
  const original = globalThis.fetch;
  globalThis.fetch = async (url) => {
    const path = String(url).replace("/atlas-data/places/v1/", "");
    const file = new URL(path, places);
    if (!existsSync(file)) return { ok: false, status: 404, json: async () => null };
    return { ok: true, status: 200, json: async () => JSON.parse(readFileSync(file, "utf8")) };
  };
  try { return await run(await import("../src/earth/placeKnowledge.ts")); } finally { globalThis.fetch = original; }
}

test("a tap is named by what it is in, or by the nearest town with its distance", () => withLocalPlaces(async ({ knowPlace, describeKnowledge }) => {
  const larvik = await knowPlace(59.053, 10.027);
  assert.equal(larvik.status, "OK");
  const d = describeKnowledge(larvik.value);
  assert.equal(d.title, "Larvik");
  assert.match(d.sub, /Vestfold, Norway/);
  assert.equal(larvik.value.timezone, "Europe/Oslo");

  const sea = describeKnowledge((await knowPlace(58.6, 9.9)).value);
  assert.equal(sea.title, "Skagerrak");
  assert.match(sea.sub, /^Off .+ · \d+ km$/, "at sea, the nearest town comes with its distance");

  const sahara = describeKnowledge((await knowPlace(23, 10)).value);
  assert.match(`${sahara.title} ${sahara.sub}`, /Sahara/);

  const atlantic = describeKnowledge((await knowPlace(30, -40)).value);
  assert.match(atlantic.title, /Atlantic Ocean/);
}));

test("a place file that does not load is unavailable, never 'nothing here'", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async () => ({ ok: false, status: 503, json: async () => null });
  const { knowPlace } = await import("../src/earth/placeKnowledge.ts?unavailable");
  const result = await knowPlace(12.34, 56.78);
  globalThis.fetch = original;
  assert.equal(result.status, "UNAVAILABLE");
});

test("worldwide search finds towns, capitals, seas and landscapes", () => withLocalPlaces(async ({ searchPlaces }) => {
  const oslo = await searchPlaces("oslo", 3);
  assert.equal(oslo[0].name, "Oslo");
  assert.equal(oslo[0].kind, "Capital");
  assert.match(oslo[0].context, /Norway/);
  assert.equal((await searchPlaces("sahara", 1))[0].kind, "Desert");
  assert.equal((await searchPlaces("north sea", 1))[0].kind, "Sea");
  assert.ok((await searchPlaces("bergen", 6)).some((h) => /Norway/.test(h.context)));
}));

/* ── the place function: ecoregion + Wikipedia, honest about failure ────── */
test("/api/atlas-place reads the ecoregion, verifies town articles by position and says when a source fails", async () => {
  const mod = await import("../functions/api/atlas-place.ts");
  const original = globalThis.fetch;
  const respond = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
  globalThis.fetch = async (url) => {
    const u = String(url);
    if (u.includes("Resolve_Ecoregions")) return respond({ features: [{ attributes: { eco_name: "Scandinavian and Russian taiga", biome_name: "Boreal Forests/Taiga", realm: "Palearctic", nnh_name: "Nature Could Reach Half Protected", eco_id: 664, ecoregion_area_km2: 2156000 } }] });
    if (u.includes("summary/Bergen")) return respond({ type: "standard", title: "Bergen", extract: "Bergen is a city in Norway. It is the second largest.", content_urls: { desktop: { page: "https://en.wikipedia.org/wiki/Bergen" } }, coordinates: { lat: 60.39, lon: 5.32 } });
    if (u.includes("summary/Scandinavian")) return respond({ type: "standard", title: "Scandinavian and Russian taiga", extract: "A taiga ecoregion.", content_urls: { desktop: { page: "https://en.wikipedia.org/wiki/Scandinavian_and_Russian_taiga" } } });
    if (u.includes("wikidata")) return respond({ entities: {} });
    return respond({}, 404);
  };
  try {
    const ok = await (await mod.onRequestGet({ request: new Request("https://4planetatlas.com/api/atlas-place?lat=60.39&lon=5.32&land=1&town=Bergen&tlat=60.39&tlon=5.32") })).json();
    assert.equal(ok.ecoregion.status, "OK");
    assert.equal(ok.ecoregion.value.name, "Scandinavian and Russian taiga");
    assert.match(ok.ecoregion.value.nnhSentence, /half/);
    assert.equal(ok.about.value.title, "Bergen");
    assert.equal(ok.ecoregionAbout.status, "OK");

    const far = await (await mod.onRequestGet({ request: new Request("https://4planetatlas.com/api/atlas-place?lat=51.5&lon=4.3&town=Bergen&tlat=51.49&tlon=4.29") })).json();
    assert.notEqual(far.about.value?.title, "Bergen", "Bergen (Norway) is never shown for Bergen op Zoom");

    globalThis.fetch = async () => { throw new Error("offline"); };
    const down = await (await mod.onRequestGet({ request: new Request("https://4planetatlas.com/api/atlas-place?lat=60&lon=10&land=1&q=Q20") })).json();
    assert.equal(down.ecoregion.status, "UNAVAILABLE");
    assert.equal(down.about.status, "UNAVAILABLE");

    const bad = await mod.onRequestGet({ request: new Request("https://4planetatlas.com/api/atlas-place?lat=200&lon=10") });
    assert.equal(bad.status, 400);
  } finally {
    globalThis.fetch = original;
  }
});
