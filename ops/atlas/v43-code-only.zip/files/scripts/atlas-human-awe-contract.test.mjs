import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";

/**
 * ATLAS R1 — HUMAN AWE FIRST: behaviour-level contract.
 *
 * These are invariants a visitor can feel, expressed against the modules that
 * own them. The rendered journeys are proven in
 * tests/e2e/atlas-r1-human-awe.spec.ts; this file pins the logic and the
 * regressions that must never return, and runs without a browser.
 */
const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), "utf8");
const world = read("src/earth/World.tsx");
const context = read("src/earth/Context.tsx");
const css = read("src/earth/world.css");
const connectors = read("src/planet/connectors.ts");

/* ── WHERE IS THIS POINT? — no request, never an invented place ───────────── */
const { describePoint, pointTitle, nameRadiusKm, searchLoadedPlaces } = await import("../src/earth/placeNames.ts");

const fakeMap = ({ zoom = 8, places = [], waterNames = [], onWater = false }) => ({
  getZoom: () => zoom,
  getStyle: () => ({ sources: { openmaptiles: { type: "vector" }, imagery: { type: "raster" } } }),
  project: () => ({ x: 100, y: 100 }),
  queryRenderedFeatures: () => (onWater ? [{ sourceLayer: "water" }] : [{ sourceLayer: "landcover" }]),
  querySourceFeatures: (_id, { sourceLayer }) => (sourceLayer === "place" ? places : sourceLayer === "water_name" ? waterNames : []),
});
const place = (name, cls, lng, lat) => ({ properties: { name, class: cls }, geometry: { type: "Point", coordinates: [lng, lat] } });

test("a tapped point is named by the nearest label, with its distance", () => {
  const d = describePoint(fakeMap({ places: [place("Drøbak", "town", 10.63, 59.66), place("Oslo", "city", 10.75, 59.91)] }), 10.6, 59.67);
  assert.equal(d.name, "Drøbak");
  assert.ok(d.distanceKm < 3);
  assert.equal(pointTitle(d), "Near Drøbak".replace("Near ", d.distanceKm <= 2 ? "" : "Near "));
});

test("a label too far away for the zoom is not used — no invented place", () => {
  const d = describePoint(fakeMap({ zoom: 11, places: [place("Oslo", "city", 10.75, 59.91)] }), 5.32, 60.39);
  assert.equal(d.name, undefined);
  assert.equal(pointTitle(d), "This point");
  assert.ok(nameRadiusKm(11) < nameRadiusKm(4), "the fair distance shrinks as the view narrows");
});

test("near is said as near; a point is never claimed to be inside a place", () => {
  const d = describePoint(fakeMap({ zoom: 6, places: [place("Larvik", "town", 10.03, 59.05)] }), 10.5, 59.3);
  assert.match(pointTitle(d), /^Near Larvik$/);
  assert.ok(d.distanceKm > 20);
});

test("open water is named as water, not as the nearest town", () => {
  const sea = describePoint(fakeMap({ zoom: 4, onWater: true, waterNames: [place("Norwegian Sea", "sea", 3, 67)], places: [place("Bodø", "town", 14.4, 67.3)] }), 4, 67.2);
  assert.equal(pointTitle(sea), "Norwegian Sea");
  assert.equal(pointTitle(describePoint(fakeMap({ zoom: 4, onWater: true }), -140, 30)), "Open water");
});

test("a country label answers only a region-scale question on land", () => {
  const wide = describePoint(fakeMap({ zoom: 3, places: [place("Kenya", "country", 37.9, 0.02)] }), 37, 0.5);
  assert.equal(pointTitle(wide), "Kenya");
  const close = describePoint(fakeMap({ zoom: 9, places: [place("Kenya", "country", 37.9, 0.02)] }), 37, 0.5);
  assert.equal(close.name, undefined, "zoomed in, a country label says nothing about the point");
});

test("map-in-view place search finds only what is loaded and never throws", () => {
  const map = fakeMap({ places: [place("Berlin", "city", 13.4, 52.5), place("Bergen", "city", 5.32, 60.39), place("Germany", "country", 10, 51)] });
  assert.deepEqual(searchLoadedPlaces(map, "ber").map((h) => h.name), ["Bergen", "Berlin"]);
  assert.deepEqual(searchLoadedPlaces(map, "germany"), [], "countries are not offered as points");
  assert.deepEqual(searchLoadedPlaces(map, "be"), [], "two letters is not a query");
  assert.deepEqual(searchLoadedPlaces(null, "berlin"), []);
  assert.deepEqual(describePoint(null, 0, 0), {});
});

/* ── LAYERS — every layer has a plain name and an honest kind of time ─────── */
const { layerPresentation, layerStatusText, TIME_LABEL } = await import("../src/earth/layerPresentation.ts");
const layerIds = [...read("src/earth/layers.ts").matchAll(/^\s*\{ id: "([a-z0-9-]+)", dom:/gm)].map((m) => m[1])
  .concat([...read("src/earth/atlasLeadingExtensions.ts").matchAll(/^\s{4}id: "([a-z0-9-]+)",/gm)].map((m) => m[1]));

test("every registry layer is presented in plain language", () => {
  assert.ok(layerIds.length >= 22, `expected the full layer set, found ${layerIds.length}`);
  for (const id of layerIds) {
    const p = layerPresentation({ id, label: id.toUpperCase() });
    assert.notEqual(p.name.toUpperCase(), p.name, `${id} has no plain-language name`);
    assert.doesNotMatch(p.name, /4[A-Z]|NDVI|·|_/, `${id} name still carries internal vocabulary: ${p.name}`);
    assert.ok(p.what.length > 8, `${id} does not say what the person is looking at`);
    assert.ok(TIME_LABEL[p.time], `${id} has no time class`);
  }
});

test("LIVE is reserved for sources that are genuinely live", () => {
  const live = layerIds.filter((id) => layerPresentation({ id }).time === "LIVE");
  assert.deepEqual(live, ["iss"], "only the ISS position is live");
  assert.equal(layerPresentation({ id: "precip" }).time, "OBSERVED");
  assert.equal(layerPresentation({ id: "emodnet-dissolved-oxygen-climatology" }).time, "CLIMATOLOGY");
  assert.equal(layerPresentation({ id: "night" }).time, "HISTORICAL");
  assert.doesNotMatch(read("src/earth/layers.ts"), /falling right now|water cycle, live/i, "yesterday's precipitation is not called live");
});

test("a failed layer is unavailable, never silently on or empty", () => {
  assert.equal(layerStatusText("UNAVAILABLE", "raster"), "Unavailable right now");
  assert.equal(layerStatusText("OFFLINE", "point"), "Source did not respond");
  assert.equal(layerStatusText("412 · 10:02Z", "point"), "412 on the map");
  assert.equal(layerStatusText("ON", "raster"), "");
});

/* ── SPECIES IDENTITY — the "Orca → NO RECORDS" regression ────────────────── */
test("species search resolves backbone keys only, so records always resolve", () => {
  assert.match(connectors, /GBIF_BACKBONE_DATASET = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c"/);
  assert.match(connectors, /species\/search\?q=[\s\S]{0,160}datasetKey=\$\{GBIF_BACKBONE_DATASET\}/);
  assert.match(connectors, /seenNames\.has\(nameKey\)/, "one row per species, not one per checklist");
  assert.match(connectors, /Math\.min\(300, Math\.max\(1, limit\)\)/, "GBIF page size is capped at 300");
});

test("authorship is citation depth, not a name", async () => {
  const names = { "Orcinus orca (Linnaeus, 1758)": "Orcinus orca", "Argyropelecus lychnus Garman, 1899": "Argyropelecus lychnus", "Canis lupus familiaris Linnaeus, 1758": "Canis lupus familiaris", "Mirounga angustirostris (Gill, 1866)": "Mirounga angustirostris" };
  const fn = /export const binomialOf = \(scientificName: string\): string => \{([\s\S]*?)\n\};/.exec(connectors);
  assert.ok(fn, "binomialOf present");
  const binomialOf = new Function("scientificName", fn[1].replace(/: string/g, ""));
  for (const [input, expected] of Object.entries(names)) assert.equal(binomialOf(input), expected);
});

/* ── TRUTH — source failure is never zero ─────────────────────────────────── */
test("NASA events are read through the same-origin bridge the CSP allows", () => {
  assert.match(connectors, /getJson\("\/api\/atlas-feed\?source=eonet"\)/);
  const csp = read("public/_headers");
  assert.doesNotMatch(csp, /eonet\.gsfc\.nasa\.gov/, "if the CSP starts allowing EONET directly, revisit the bridge-first order");
  assert.match(world, /eonetDown/);
  assert.match(world, /did not answer\. That is a connection problem, not a\s+quiet planet/);
});

test("a gap is always spoken on the first read", () => {
  assert.match(context, /NO SECTION RENDERS WITHOUT A STATUS/);
  assert.match(context, /const GAP: ReadonlySet<DataStatus>/);
  for (const status of ["NO_RECORDS", "NOT_CHECKED", "NO_COVERAGE", "SOURCE_UNAVAILABLE", "BUNDLED"]) assert.match(context, new RegExp(`"${status}"`));
  assert.match(context, /not an empty place/);
  assert.match(context, /statement about the records, not about the world/);
  assert.match(context, /A bounding box is a box on a map, not the boundary of the place/);
});

/* ── HUMAN FIRST READ — technical metadata lives at evidence depth ────────── */
test("identifiers, coordinates and query geometry are rendered only inside Sources and limits", () => {
  const outside = context.replace(/<Evidence[\s\S]*?<\/Evidence>/g, "");
  assert.doesNotMatch(outside, /<Fact k="(Identity|Centre|Point|Location|Area queried)"/, "technical facts leaked onto the first read");
  assert.doesNotMatch(outside, /className="ctx-id"/);
  assert.ok((context.match(/<Evidence>/g) || []).length >= 9, "every object type keeps its evidence block");
});

/* ── MOBILE CRAFT — regressions a phone user feels ────────────────────────── */
test("the search field can never trigger iOS focus zoom", () => {
  const rule = /\.search-line input \{([\s\S]*?)\n\}/.exec(css)?.[1] ?? "";
  assert.match(rule, /font-size:\s*16px/);
  assert.match(world, /enterKeyHint="search"/);
  assert.match(world, /--atlas-vvh/, "search results follow the visual viewport above the keyboard");
});

test("one stylesheet authority, no override layer", () => {
  const forced = css.split("\n").filter((line) => line.includes("!important"));
  assert.ok(forced.length <= 2 && forced.every((line) => /animation: none|transition-duration/.test(line)), `only the reduced-motion preference may force a value: ${forced.join(" | ")}`);
  assert.equal(existsSync(new URL("../src/earth/atlasPolish.css", import.meta.url)), false, "the unused polish override sheet stays deleted");
  assert.equal(existsSync(new URL("../src/earth/AtlasHumanSurfacePolish.tsx", import.meta.url)), false, "no body-wide MutationObserver polish sidecar");
});

test("no hidden interception, no third-party geocoder", () => {
  assert.equal(existsSync(new URL("../src/earth/AtlasPlaceNameBridge.tsx", import.meta.url)), false);
  for (const file of ["src/earth/World.tsx", "src/earth/PublicWorld.tsx", "src/earth/placeNames.ts"]) {
    assert.doesNotMatch(read(file), /window\.fetch\s*=|bigdatacloud|nominatim/i, `${file} must not patch fetch or call a geocoder`);
  }
});

test("NO INVISIBLE WORK — the basemap style is swapped only for a real theme change", () => {
  const sync = read("src/earth/AtlasBasemapSync.tsx");
  assert.match(sync, /if \(nextMode === observedMode\) return;/);
  assert.doesNotMatch(world, /setInterval\([^\n]*1000\)/);
});

test("one surface at a time, announced on one contract", () => {
  assert.match(world, /data-atlas-surface=\{surface\}/);
  assert.match(world, /new CustomEvent\("4p:atlas-surface-open", \{ detail: surface \}\)/);
  assert.match(read("src/earth/AtlasSavedViews.tsx"), /4p:atlas-my-atlas-closed/);
  for (const token of ["body:has(.world.search-active)", "body:has(.world.context-active)", "body:has(.world.lens-active)", "body:has(.world.layers-active)"]) assert.ok(css.includes(token));
});
