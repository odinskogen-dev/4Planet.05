import fs from "node:fs";
import path from "node:path";
import { ATLAS_ORIGIN, BUILD_ORIGIN, IS_ATLAS_BUILD, canonicalPath, isAtlasOwnedPath } from "./seo-ownership.mjs";

/**
 * DEDICATED ATLAS HOST FINALIZER
 *
 * Runs at the end of every build and does NOTHING unless the build is the
 * standalone ATLAS deployment (PUBLIC_SITE_ORIGIN=https://4planetatlas.com).
 * The main 4planet.org artifact is byte-identical with or without this step.
 *
 * For the ATLAS deployment it makes the artifact say one consistent thing to a
 * crawler, with no hand-editing in the release workflow:
 *
 *   /                 200 — the prerendered ATLAS entry, canonical = ATLAS root
 *   /atlas            200 — same entry (compatibility route), canonical = ATLAS root
 *   /sitemap.xml      ATLAS-owned URLs only (/, /places, /place/*, /atlas/*)
 *   /robots.txt       points at the ATLAS sitemap only
 *   /_redirects       SPA fallback preserved; the old "/ → /atlas 302" is gone
 *
 * Species, Living Systems, Magazine and every other route keep the MAIN host as
 * canonical and are deliberately absent from the ATLAS sitemap.
 */
if (!IS_ATLAS_BUILD) {
  console.log(`ATLAS host finalizer: skipped (build origin ${BUILD_ORIGIN} is not the ATLAS host)`);
  process.exit(0);
}

const root = process.cwd();
const dist = path.join(root, "dist");
const read = (file) => fs.readFileSync(path.join(dist, file), "utf8");
const escapeXml = (value) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");

// 1. "/" serves the ATLAS entry directly — no redirect hop for people or crawlers.
const entry = read("atlas/index.html");
if (!entry.includes(`<link rel="canonical" href="${ATLAS_ORIGIN}/">`)) {
  throw new Error("ATLAS entry does not canonicalise to the ATLAS root; refusing to finalise");
}
fs.writeFileSync(path.join(dist, "index.html"), entry, "utf8");

// 2. Sitemap: exactly the prerendered routes ATLAS owns, each at its canonical path.
const inventory = JSON.parse(fs.readFileSync(path.join(root, "src/data/discoveryInventory.json"), "utf8"));
const atlasDiscovery = JSON.parse(fs.readFileSync(path.join(root, "src/data/atlasDiscovery.json"), "utf8"));
const routes = [
  "/atlas",
  "/places",
  ...(inventory.places ?? []).filter((item) => item.indexable === true).map((item) => `/place/${item.slug}`),
  ...(atlasDiscovery.objects ?? []).filter((item) => item.indexable === true).map((item) => `/atlas/${item.slug}`),
];
const urls = [...new Set(routes.filter(isAtlasOwnedPath).map(canonicalPath))];
for (const route of urls) {
  const file = route === "/" ? "index.html" : path.join(...route.split("/").filter(Boolean), "index.html");
  if (!fs.existsSync(path.join(dist, file))) throw new Error(`ATLAS sitemap route has no prerendered page: ${route}`);
}
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((route) => `  <url><loc>${escapeXml(ATLAS_ORIGIN + route)}</loc></url>`).join("\n")}\n</urlset>\n`;
fs.writeFileSync(path.join(dist, "sitemap.xml"), sitemap, "utf8");

// 3. Robots: same crawl policy as the main host, ATLAS sitemap only.
const robots = `User-agent: OAI-SearchBot\nAllow: /\n\nUser-agent: Googlebot\nAllow: /\n\nUser-agent: Bingbot\nAllow: /\n\nUser-agent: *\nAllow: /\nDisallow: /labs\nDisallow: /os\nDisallow: /sandbox\nDisallow: /checkout\nDisallow: /api\nDisallow: /4nation\n\nSitemap: ${ATLAS_ORIGIN}/sitemap.xml\n`;
fs.writeFileSync(path.join(dist, "robots.txt"), robots, "utf8");

// 4. Main-host-only feeds do not belong on the ATLAS host.
for (const file of ["news-sitemap.xml"]) fs.rmSync(path.join(dist, file), { force: true });

// 5. Redirects: keep the repository's rules (SPA fallback, living-systems), and
//    make sure no rule sends "/" away — "/" is a real page on this host.
const redirectsPath = path.join(dist, "_redirects");
const existing = fs.existsSync(redirectsPath) ? fs.readFileSync(redirectsPath, "utf8") : "";
const kept = existing.split("\n").filter((line) => !/^\s*\/\s+\S+\s+30[1278]\s*$/.test(line));
if (!kept.some((line) => /^\s*\/\*\s+\/index\.html\s+200\s*$/.test(line))) kept.push("/*  /index.html  200");
fs.writeFileSync(redirectsPath, kept.join("\n").replace(/\n+$/, "") + "\n", "utf8");

console.log(`ATLAS host finalizer: / and /atlas canonical → ${ATLAS_ORIGIN}/ · sitemap ${urls.length} URLs · robots → ${ATLAS_ORIGIN}/sitemap.xml`);
