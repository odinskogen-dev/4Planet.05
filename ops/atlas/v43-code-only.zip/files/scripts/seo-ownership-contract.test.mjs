import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";

/**
 * CANONICAL OWNERSHIP CONTRACT
 *
 * One repository renders several public hosts. Two hosts must never tell a
 * crawler two different things about the same page. This contract pins:
 *   · ATLAS + PLACE routes canonicalise to https://4planetatlas.com in EVERY build;
 *   · the ATLAS root is "/" ("/atlas" is the compatibility route);
 *   · SPECIES / LIVING SYSTEMS / everything else is untouched (MAIN host);
 *   · build-side (scripts) and runtime-side (src) resolve identically.
 */
const resolveWith = (env) => JSON.parse(execFileSync(process.execPath, ["--input-type=module", "-e", `
  const m = await import(${JSON.stringify(new URL("./seo-ownership.mjs", import.meta.url).href)});
  const paths = ["/", "/atlas", "/atlas?l=fires&z=3", "/atlas/fires", "/places", "/place/kenya", "/place/kenya/", "/species/orca", "/living-systems/oslofjord", "/magazine", "/now"];
  console.log(JSON.stringify({ isAtlas: m.IS_ATLAS_BUILD, main: m.MAIN_ORIGIN, atlas: m.ATLAS_ORIGIN,
    canonical: Object.fromEntries(paths.map((p) => [p, m.canonicalUrl(p)])),
    absolute: { deep: m.absoluteUrl("/atlas?l=fires&z=3"), species: m.absoluteUrl("/species/orca") } }));
`], { env: { ...process.env, PUBLIC_SITE_ORIGIN: "", VITE_PUBLIC_SITE_ORIGIN: "", PUBLIC_MAIN_ORIGIN: "", PUBLIC_ATLAS_ORIGIN: "", ...env }, encoding: "utf8" }));

const expectOwnership = (r) => {
  assert.equal(r.canonical["/atlas"], "https://4planetatlas.com/");
  assert.equal(r.canonical["/atlas?l=fires&z=3"], "https://4planetatlas.com/", "query strings never canonicalise");
  assert.equal(r.canonical["/atlas/fires"], "https://4planetatlas.com/atlas/fires");
  assert.equal(r.canonical["/places"], "https://4planetatlas.com/places");
  assert.equal(r.canonical["/place/kenya"], "https://4planetatlas.com/place/kenya");
  assert.equal(r.canonical["/place/kenya/"], "https://4planetatlas.com/place/kenya", "trailing slash is normalised");
  assert.equal(r.canonical["/species/orca"], "https://4planet.org/species/orca", "SPECIES ownership is not moved");
  assert.equal(r.canonical["/living-systems/oslofjord"], "https://4planet.org/living-systems/oslofjord", "LIVING SYSTEMS ownership is not moved");
  assert.equal(r.canonical["/magazine"], "https://4planet.org/magazine");
  assert.equal(r.absolute.deep, "https://4planetatlas.com/?l=fires&z=3", "deep ATLAS links keep their state on the ATLAS host");
  assert.equal(r.absolute.species, "https://4planet.org/species/orca");
};

test("main build: ATLAS and PLACE routes canonicalise to the standalone ATLAS host", () => {
  const r = resolveWith({});
  assert.equal(r.isAtlas, false);
  assert.equal(r.canonical["/"], "https://4planet.org/");
  expectOwnership(r);
});

test("dedicated ATLAS build: owns ATLAS and PLACE, never claims SPECIES / LIVING SYSTEMS / MAGAZINE", () => {
  const r = resolveWith({ PUBLIC_SITE_ORIGIN: "https://4planetatlas.com", VITE_PUBLIC_SITE_ORIGIN: "https://4planetatlas.com" });
  assert.equal(r.isAtlas, true);
  assert.equal(r.main, "https://4planet.org");
  expectOwnership(r);
});

test("www and trailing-slash origins are recognised as the ATLAS build", () => {
  assert.equal(resolveWith({ PUBLIC_SITE_ORIGIN: "https://www.4planetatlas.com/" }).isAtlas, true);
  assert.equal(resolveWith({ PUBLIC_SITE_ORIGIN: "https://test.4planet.org" }).isAtlas, false);
});

test("runtime ownership agrees with build ownership", async () => {
  const runtime = await import("../src/seo/ownership.ts");
  const build = resolveWith({});
  for (const [path, expected] of Object.entries(build.canonical)) {
    if (path === "/") continue; // "/" belongs to whichever host serves it
    assert.equal(runtime.canonicalUrlFor(path, "https://4planet.org"), expected, `runtime ≠ build for ${path}`);
    // The same page rendered on the ATLAS host must say exactly the same thing.
    assert.equal(runtime.canonicalUrlFor(path, "https://4planetatlas.com"), expected, `ATLAS-host runtime ≠ build for ${path}`);
  }
  assert.equal(runtime.isAtlasHost("4planetatlas.com"), true);
  assert.equal(runtime.isAtlasHost("www.4planetatlas.com"), true);
  assert.equal(runtime.isAtlasHost("4planet.org"), false);
  assert.equal(runtime.isAtlasHost("4species.com"), false);
});

test("every SEO writer resolves origins through the ownership module", () => {
  const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), "utf8");
  for (const file of ["scripts/generate-sitemap.mjs", "scripts/prerender-atlas-seo.mjs", "scripts/prerender-discovery-seo.mjs", "scripts/prerender-magazine-seo.mjs", "scripts/finalize-atlas-host.mjs"]) {
    const source = read(file);
    assert.match(source, /seo-ownership\.mjs/, `${file} must use the ownership module`);
    assert.doesNotMatch(source, /process\.env\.PUBLIC_SITE_ORIGIN\s*\|\|/, `${file} must not resolve its own origin`);
  }
  assert.match(read("src/components/Seo.tsx"), /canonicalUrlFor\(path, origin\)/);
  assert.match(read("src/routes/router.tsx"), /isAtlasHost\(\)/, "the ATLAS host root must open the map");
});

test("a dedicated ATLAS artifact, when present, says one consistent thing to a crawler", { skip: !(existsSync(new URL("../dist/robots.txt", import.meta.url)) && readFileSync(new URL("../dist/robots.txt", import.meta.url), "utf8").includes("4planetatlas.com")) }, () => {
  const dist = (p) => readFileSync(new URL(`../dist/${p}`, import.meta.url), "utf8");
  const canonicalOf = (html) => /<link rel="canonical" href="([^"]+)"/.exec(html)?.[1];
  assert.equal(canonicalOf(dist("index.html")), "https://4planetatlas.com/");
  assert.equal(canonicalOf(dist("atlas/index.html")), "https://4planetatlas.com/");
  assert.equal(canonicalOf(dist("places/index.html")), "https://4planetatlas.com/places");
  assert.equal(canonicalOf(dist("place/oslofjord/index.html")), "https://4planetatlas.com/place/oslofjord");
  assert.equal(canonicalOf(dist("species/orca/index.html")), "https://4planet.org/species/orca");
  assert.match(dist("index.html"), /<h1>One planet\. Many ways to see it\.<\/h1>/, "the root is real crawlable HTML");
  const robots = dist("robots.txt");
  assert.match(robots, /Sitemap: https:\/\/4planetatlas\.com\/sitemap\.xml/);
  assert.doesNotMatch(robots, /4planet\.org/);
  const sitemap = dist("sitemap.xml");
  const locs = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1]);
  assert.ok(locs.includes("https://4planetatlas.com/"));
  assert.ok(locs.includes("https://4planetatlas.com/place/oslofjord"));
  assert.ok(locs.every((loc) => loc.startsWith("https://4planetatlas.com/")), "only ATLAS-owned URLs");
  assert.ok(!locs.some((loc) => /\/species|\/living-systems|\/magazine/.test(loc)), "no SPECIES / LIVING SYSTEMS / MAGAZINE URLs");
  assert.ok(!locs.includes("https://4planetatlas.com/atlas"), "the compatibility route is not listed");
  const redirects = dist("_redirects");
  assert.doesNotMatch(redirects, /^\/\s+\/atlas\s+30\d/m, "the root is a real page, not a redirect");
  assert.match(redirects, /^\/\*\s+\/index\.html\s+200/m);
});
