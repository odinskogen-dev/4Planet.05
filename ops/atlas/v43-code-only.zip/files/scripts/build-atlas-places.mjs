#!/usr/bin/env node
/**
 * ATLAS PLACE KNOWLEDGE — build step
 *
 * Compiles open geography (scripts/atlas-places-sources.json) into small static
 * files ATLAS can read with no third-party call at runtime:
 *
 *   public/atlas-data/places/v1/cells/{cx}_{cy}.json
 *     One 10°×10° cell of the planet. For any point in it: the country, the
 *     state/province, the sea or ocean, the physical region (desert, range,
 *     island…), the lake, the towns (GeoNames, ≥1,000 people) and the named
 *     peaks — polygons clipped to the cell and simplified to ~100 m.
 *
 *   public/atlas-data/places/v1/search/{letter}.json
 *     Worldwide place search: towns of 5,000+ people and every capital, plus
 *     countries, states/provinces, seas, physical regions, lakes and peaks.
 *
 *   public/atlas-data/places/v1/manifest.json
 *     Sources, licences, attribution, counts and build time.
 *
 * Usage:
 *   node scripts/build-atlas-places.mjs [--cache .cache/atlas-places] [--out public/atlas-data/places/v1]
 *
 * Downloads are cached; a missing download fails the build loudly (no partial
 * data is ever written over a good set). The output is committed, so a normal
 * `npm run build` does not need the network.
 */
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, renameSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const arg = (name, fallback) => {
  const at = process.argv.indexOf(`--${name}`);
  return at > 0 && process.argv[at + 1] ? resolve(process.argv[at + 1]) : fallback;
};
const CACHE = arg("cache", join(root, ".cache/atlas-places"));
const OUT = arg("out", join(root, "public/atlas-data/places/v1"));
const SOURCES = JSON.parse(readFileSync(join(root, "scripts/atlas-places-sources.json"), "utf8"));

const CELL = 5; // degrees — one tap downloads one small cell
const CX = 360 / CELL, CY = 180 / CELL;
const cellOf = (lon, lat) => [
  Math.min(CX - 1, Math.max(0, Math.floor((lon + 180) / CELL))),
  Math.min(CY - 1, Math.max(0, Math.floor((lat + 90) / CELL))),
];
const r3 = (n) => Math.round(n * 1000) / 1000;
const r4 = (n) => Math.round(n * 10000) / 10000;

/* ── download (cached) ─────────────────────────────────────────────────────── */
async function fetchSource(source) {
  mkdirSync(CACHE, { recursive: true });
  const file = join(CACHE, `${source.id}${source.url.endsWith(".tgz") ? ".tgz" : ".geojson"}`);
  if (!existsSync(file)) {
    const response = await fetch(source.url, { headers: { "user-agent": "4PLANET-ATLAS-places-build (+https://4planetatlas.com)" } });
    if (!response.ok) throw new Error(`${source.id}: HTTP ${response.status} from ${source.url}`);
    writeFileSync(file, Buffer.from(await response.arrayBuffer()));
  }
  const bytes = readFileSync(file);
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  if (source.sha256 && source.sha256 !== sha256) throw new Error(`${source.id}: sha256 ${sha256} does not match the pinned ${source.sha256}`);
  if (file.endsWith(".tgz")) {
    const dir = join(CACHE, source.id);
    if (!existsSync(join(dir, source.member))) {
      mkdirSync(dir, { recursive: true });
      execFileSync("tar", ["-xzf", file, "-C", dir]);
    }
    return { sha256, text: readFileSync(join(dir, source.member), "utf8") };
  }
  return { sha256, json: JSON.parse(bytes.toString("utf8")) };
}

/* ── geometry ──────────────────────────────────────────────────────────────── */
function simplify(points, tolerance) {
  // Douglas–Peucker on [lon, lat] pairs; closed rings keep their closure.
  if (points.length <= 4 || tolerance <= 0) return points;
  const keep = new Uint8Array(points.length);
  keep[0] = 1; keep[points.length - 1] = 1;
  const stack = [[0, points.length - 1]];
  const t2 = tolerance * tolerance;
  while (stack.length) {
    const [a, b] = stack.pop();
    const [ax, ay] = points[a]; const [bx, by] = points[b];
    const dx = bx - ax, dy = by - ay; const len2 = dx * dx + dy * dy;
    let maxD = -1, maxI = -1;
    for (let i = a + 1; i < b; i += 1) {
      const [px, py] = points[i];
      let d;
      if (len2 === 0) d = (px - ax) ** 2 + (py - ay) ** 2;
      else {
        const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
        d = (px - (ax + t * dx)) ** 2 + (py - (ay + t * dy)) ** 2;
      }
      if (d > maxD) { maxD = d; maxI = i; }
    }
    if (maxD > t2) { keep[maxI] = 1; stack.push([a, maxI], [maxI, b]); }
  }
  return points.filter((_, i) => keep[i]);
}

function clipRing(ring, minX, minY, maxX, maxY) {
  // Sutherland–Hodgman against an axis-aligned rectangle. Clipping a ring to the
  // cell keeps even-odd point membership exact for every point inside the cell.
  const edges = [
    (p) => p[0] >= minX, (p) => p[0] <= maxX, (p) => p[1] >= minY, (p) => p[1] <= maxY,
  ];
  const cross = [
    (a, b) => { const t = (minX - a[0]) / (b[0] - a[0]); return [minX, a[1] + t * (b[1] - a[1])]; },
    (a, b) => { const t = (maxX - a[0]) / (b[0] - a[0]); return [maxX, a[1] + t * (b[1] - a[1])]; },
    (a, b) => { const t = (minY - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), minY]; },
    (a, b) => { const t = (maxY - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), maxY]; },
  ];
  let output = ring;
  for (let e = 0; e < 4; e += 1) {
    const input = output; output = [];
    if (!input.length) break;
    for (let i = 0; i < input.length; i += 1) {
      const current = input[i]; const prev = input[(i + input.length - 1) % input.length];
      const inCur = edges[e](current); const inPrev = edges[e](prev);
      if (inCur) { if (!inPrev) output.push(cross[e](prev, current)); output.push(current); }
      else if (inPrev) output.push(cross[e](prev, current));
    }
  }
  return output;
}

const polygonsOf = (geometry) => {
  if (!geometry) return [];
  if (geometry.type === "Polygon") return [geometry.coordinates];
  if (geometry.type === "MultiPolygon") return geometry.coordinates;
  return [];
};

function bboxOf(rings) {
  let minX = 180, minY = 90, maxX = -180, maxY = -90;
  for (const ring of rings) for (const [x, y] of ring) {
    if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  return [minX, minY, maxX, maxY];
}

function pointInRings(lon, lat, rings) {
  let inside = false;
  for (const ring of rings) {
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [xi, yi] = ring[i]; const [xj, yj] = ring[j];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
    }
  }
  return inside;
}

/* ── naming ────────────────────────────────────────────────────────────────── */
const fold = (s) => String(s || "").normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
const letterOf = (name) => { const c = fold(name).charAt(0); return c >= "a" && c <= "z" ? c : "0"; };
const prop = (p, ...keys) => { for (const k of keys) { const v = p[k] ?? p[k.toUpperCase()] ?? p[k.toLowerCase()]; if (v !== undefined && v !== null && v !== "") return v; } return undefined; };

const MARINE_TYPE = { ocean: "Ocean", sea: "Sea", gulf: "Gulf", bay: "Bay", strait: "Strait", sound: "Sound", channel: "Channel", lagoon: "Lagoon", fjord: "Fjord", reef: "Reef", river: "River mouth", generic: "Marine area" };
const REGION_TYPE = {
  "Island": "Island", "Island group": "Island group", "Range/mtn": "Mountain range", "Plateau": "Plateau",
  "Desert": "Desert", "Pen/cape": "Peninsula", "Peninsula": "Peninsula", "Geoarea": "Region", "Coast": "Coast",
  "Plain": "Plain", "Delta": "Delta", "Basin": "Basin", "Valley": "Valley", "Lowland": "Lowland", "Wetlands": "Wetland",
  "Tundra": "Tundra", "Foothills": "Foothills", "Gorge": "Gorge", "Isthmus": "Isthmus", "Depression": "Depression",
  "Continent": "Continent", "Lake": "Lake",
};
const SKIP_REGION = new Set(["Dragons-be-here"]);
// Natural Earth classes the Skagerrak as a fjord; it is a strait between seas.
const MARINE_TYPE_FIX = { Skagerrak: "Strait", Kattegat: "Strait" };

/* ── build ─────────────────────────────────────────────────────────────────── */
async function main() {
  const byId = Object.fromEntries(SOURCES.sources.map((s) => [s.id, s]));
  const loaded = {};
  for (const source of SOURCES.sources) loaded[source.id] = await fetchSource(source);

  const cells = new Map(); // "cx_cy" -> { areas: [], towns: [], peaks: [] }
  const cell = (cx, cy) => {
    const key = `${cx}_${cy}`;
    if (!cells.has(key)) cells.set(key, { areas: [], towns: [], peaks: [], tz: [] });
    return cells.get(key);
  };
  const search = new Map(); // letter -> rows
  const addSearch = (row) => {
    const letter = letterOf(row[0]);
    if (!search.has(letter)) search.set(letter, []);
    search.get(letter).push(row);
  };
  const counts = {};

  // Polygons → clipped, simplified, per cell.
  const admin1Index = []; // for naming towns in search: { rings, bbox, name, cc }
  const countryNames = {};
  function addPolygons(kind, features, describe, tolerance) {
    let n = 0;
    for (const feature of features) {
      const meta = describe(feature.properties || {});
      if (!meta) continue;
      n += 1;
      const featureRings = [];
      for (const polygon of polygonsOf(feature.geometry)) {
        for (const ring of polygon) {
          const simple = simplify(ring, tolerance);
          if (simple.length >= 4) featureRings.push(simple);
        }
      }
      if (!featureRings.length) continue;
      if (kind === "admin1") admin1Index.push({ rings: featureRings, bbox: bboxOf(featureRings), name: meta.n, cc: meta.cc });
      const [minX, minY, maxX, maxY] = bboxOf(featureRings);
      const [cx0, cy0] = cellOf(minX, minY); const [cx1, cy1] = cellOf(maxX, maxY);
      for (let cx = cx0; cx <= cx1; cx += 1) for (let cy = cy0; cy <= cy1; cy += 1) {
        const x0 = cx * CELL - 180, y0 = cy * CELL - 90;
        const rings = [];
        for (const ring of featureRings) {
          const [rx0, ry0, rx1, ry1] = bboxOf([ring]);
          if (rx1 < x0 || rx0 > x0 + CELL || ry1 < y0 || ry0 > y0 + CELL) continue;
          const clipped = clipRing(ring, x0, y0, x0 + CELL, y0 + CELL);
          if (clipped.length >= 3) rings.push(clipped.flatMap(([x, y]) => [r3(x), r3(y)]));
        }
        if (rings.length) cell(cx, cy).areas.push({ k: kind, ...meta, r: rings });
      }
    }
    counts[kind] = n;
  }

  addPolygons("country", loaded["ne-countries"].json.features, (p) => {
    const n = prop(p, "NAME_EN", "NAME"); if (!n) return null;
    // Natural Earth leaves ISO_A2 as -99 for a few countries (Norway, France);
    // ISO_A2_EH carries their real code.
    const iso = prop(p, "ISO_A2"); const cc = iso && iso !== "-99" ? iso : prop(p, "ISO_A2_EH");
    if (cc && cc !== "-99") countryNames[cc] = n;
    return { n, cc: cc && cc !== "-99" ? cc : undefined, q: prop(p, "WIKIDATAID"), c: prop(p, "CONTINENT"), s: prop(p, "SUBREGION") };
  }, 0.008);
  addPolygons("admin1", loaded["ne-admin1"].json.features, (p) => {
    const n = prop(p, "name_en", "name"); if (!n) return null;
    return { n, t: prop(p, "type_en"), cc: prop(p, "iso_a2"), q: prop(p, "wikidataid") };
  }, 0.008);
  // Marine areas and lakes keep their own `name` ("North Pacific Ocean", "Lake
  // Victoria"); their `name_en` is sometimes a broader or older name.
  addPolygons("marine", loaded["ne-marine"].json.features, (p) => {
    const n = prop(p, "name", "name_en"); if (!n) return null;
    return { n, t: MARINE_TYPE_FIX[n] || MARINE_TYPE[String(prop(p, "featurecla") || "").toLowerCase()] || "Marine area", q: prop(p, "wikidataid"), z: prop(p, "scalerank") };
  }, 0.01);
  addPolygons("region", loaded["ne-regions"].json.features, (p) => {
    const n = prop(p, "NAME_EN", "NAME"); if (!n || SKIP_REGION.has(prop(p, "FEATURECLA"))) return null;
    return { n, t: REGION_TYPE[prop(p, "FEATURECLA")] || "Region", q: prop(p, "WIKIDATAID"), z: prop(p, "SCALERANK") };
  }, 0.01);
  addPolygons("lake", loaded["ne-lakes"].json.features, (p) => {
    const n = prop(p, "name", "name_en"); if (!n) return null;
    return { n, t: String(prop(p, "featurecla") || "Lake").replace("Alkaline Lake", "Salt lake"), q: prop(p, "wikidataid") };
  }, 0.004);

  // Peaks.
  let peaks = 0;
  for (const feature of loaded["ne-peaks"].json.features) {
    const p = feature.properties || {}; const n = prop(p, "name_en", "name");
    if (!n || feature.geometry?.type !== "Point") continue;
    const [lon, lat] = feature.geometry.coordinates;
    const kind = String(prop(p, "featurecla") || "mountain");
    const row = [n, r4(lat), r4(lon), Number(prop(p, "elevation")) || null, prop(p, "wikidataid") || null, kind];
    const [cx, cy] = cellOf(lon, lat);
    cell(cx, cy).peaks.push(row);
    addSearch([n, kind === "mountain" ? "Mountain" : kind === "depression" ? "Depression" : "Landmark", r4(lat), r4(lon), Number(prop(p, "elevation")) || 0, null, prop(p, "region") || "", prop(p, "wikidataid") || null]);
    peaks += 1;
  }
  counts.peaks = peaks;

  // Named areas in search (at their label point: the centre of the largest ring).
  const areaLabel = (geometry) => {
    let best = null, bestArea = -1;
    for (const polygon of polygonsOf(geometry)) {
      const ring = polygon[0]; if (!ring) continue;
      let a = 0, cx = 0, cy = 0;
      for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
        const f = ring[j][0] * ring[i][1] - ring[i][0] * ring[j][1];
        a += f; cx += (ring[j][0] + ring[i][0]) * f; cy += (ring[j][1] + ring[i][1]) * f;
      }
      if (Math.abs(a) > bestArea && a !== 0) { bestArea = Math.abs(a); best = [cx / (3 * a), cy / (3 * a)]; }
    }
    return best;
  };
  const searchAreas = (sourceId, kindLabel, nameKeys, context) => {
    for (const feature of loaded[sourceId].json.features) {
      const p = feature.properties || {}; const n = prop(p, ...nameKeys);
      const at = n && areaLabel(feature.geometry); if (!at) continue;
      if (sourceId === "ne-regions" && SKIP_REGION.has(prop(p, "FEATURECLA"))) continue;
      const iso = prop(p, "iso_a2", "ISO_A2"); const cc = iso && iso !== "-99" ? iso : prop(p, "ISO_A2_EH");
      addSearch([n, kindLabel(p), r4(at[1]), r4(at[0]), 0, cc && cc !== "-99" ? cc : null, context(p), prop(p, "wikidataid", "WIKIDATAID") || null]);
    }
  };
  searchAreas("ne-countries", () => "Country", ["NAME_EN", "NAME"], (p) => prop(p, "CONTINENT") || "");
  searchAreas("ne-admin1", (p) => prop(p, "type_en") || "Region", ["name_en", "name"], (p) => prop(p, "admin") || "");
  searchAreas("ne-marine", (p) => MARINE_TYPE_FIX[prop(p, "name")] || MARINE_TYPE[String(prop(p, "featurecla") || "").toLowerCase()] || "Marine area", ["name", "name_en"], () => "");
  searchAreas("ne-regions", (p) => REGION_TYPE[prop(p, "FEATURECLA")] || "Region", ["NAME_EN", "NAME"], (p) => [prop(p, "SUBREGION"), prop(p, "REGION")].filter(Boolean).join(", "));
  searchAreas("ne-lakes", (p) => String(prop(p, "featurecla") || "Lake").replace("Alkaline Lake", "Salt lake"), ["name", "name_en"], (p) => prop(p, "admin") || "");

  // Towns (GeoNames cities1000).
  const admin1Of = (lon, lat, cc) => {
    for (const a of admin1Index) {
      if (a.cc !== cc) continue;
      const [x0, y0, x1, y1] = a.bbox;
      if (lon < x0 || lon > x1 || lat < y0 || lat > y1) continue;
      if (pointInRings(lon, lat, a.rings)) return a.name;
    }
    return "";
  };
  let towns = 0, searchTowns = 0;
  for (const line of loaded["geonames-cities1000"].text.split("\n")) {
    if (!line) continue;
    const f = line.split("\t");
    const [, name, , , latS, lonS, , fcode, cc, , , , , , popS, , , tz] = f;
    const lat = Number(latS), lon = Number(lonS), pop = Number(popS) || 0;
    if (!name || !Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    const [cx, cy] = cellOf(lon, lat);
    // Compact row: the time zone is an index into the cell's own list, and the
    // GeoNames feature code is reduced to what ATLAS says ("C" capital, "A"
    // administrative seat).
    const home = cell(cx, cy);
    let tzi = home.tz.indexOf(tz || "");
    if (tzi < 0) { home.tz.push(tz || ""); tzi = home.tz.length - 1; }
    const rank = fcode === "PPLC" ? "C" : /^PPLA/.test(fcode) ? "A" : "";
    const row = [name, r3(lat), r3(lon), pop, cc, tzi];
    if (rank) row.push(rank);
    home.towns.push(row);
    towns += 1;
    if (pop >= 5000 || /^PPLC|^PPLA$/.test(fcode)) {
      const region = admin1Of(lon, lat, cc);
      addSearch([name, fcode === "PPLC" ? "Capital" : pop >= 100000 ? "City" : "Town", r4(lat), r4(lon), pop, cc, [region, countryNames[cc] || cc].filter(Boolean).join(", "), null]);
      searchTowns += 1;
    }
  }
  counts.towns = towns; counts.searchTowns = searchTowns;

  // Write atomically: build into a temp folder, then swap.
  const tmp = `${OUT}.tmp`;
  rmSync(tmp, { recursive: true, force: true });
  mkdirSync(join(tmp, "cells"), { recursive: true });
  mkdirSync(join(tmp, "search"), { recursive: true });
  let cellBytes = 0;
  for (const [key, value] of cells) {
    value.towns.sort((a, b) => b[3] - a[3]);
    const body = JSON.stringify({ v: 1, cell: key, ...value });
    cellBytes += body.length;
    writeFileSync(join(tmp, "cells", `${key}.json`), body);
  }
  let searchBytes = 0;
  for (const [letter, rows] of search) {
    rows.sort((a, b) => (b[4] || 0) - (a[4] || 0));
    const body = JSON.stringify({ v: 1, letter, rows });
    searchBytes += body.length;
    writeFileSync(join(tmp, "search", `${letter}.json`), body);
  }
  const manifest = {
    v: 1,
    cellDegrees: CELL,
    cells: [...cells.keys()].sort(),
    letters: [...search.keys()].sort(),
    counts,
    bytes: { cells: cellBytes, search: searchBytes },
    sources: SOURCES.sources.map((s) => ({ id: s.id, name: s.name, licence: s.licence, attribution: s.attribution, home: s.home, url: s.url, sha256: loaded[s.id].sha256 })),
    runtime: SOURCES.runtime,
    rowFormat: {
      town: ["name", "lat", "lon", "population", "countryCode", "timezone index into cell.tz", "rank: C capital · A administrative seat (optional)"],
      peak: ["name", "lat", "lon", "elevationM", "wikidata", "kind"],
      area: { k: "country|admin1|marine|region|lake", n: "name", t: "type", q: "wikidata", cc: "country code", r: "rings as flat [lon,lat,…] arrays clipped to the cell" },
      search: ["name", "kind", "lat", "lon", "population or elevation", "countryCode", "context", "wikidata"],
    },
  };
  writeFileSync(join(tmp, "manifest.json"), JSON.stringify(manifest, null, 2));
  rmSync(OUT, { recursive: true, force: true });
  mkdirSync(dirname(OUT), { recursive: true });
  renameSync(tmp, OUT);
  console.log(`ATLAS places: ${cells.size} cells (${(cellBytes / 1e6).toFixed(1)} MB) · search ${(searchBytes / 1e6).toFixed(1)} MB · ${JSON.stringify(counts)}`);
  void byId;
}

main().catch((error) => { console.error(`ATLAS places build failed: ${error.message}`); process.exit(1); });
