import test from "node:test";
import assert from "node:assert/strict";
import {readFile} from "node:fs/promises";

test("mobile context sheet leaves native MapLibre navigation controls physically operable",async()=>{
  const css=await readFile(new URL("../src/earth/world.css",import.meta.url),"utf8");
  assert.match(css,/\.world:has\(\.ctx\) \.maplibregl-ctrl-bottom-right/);
  // R1: the sheet has fixed detents, so the controls sit exactly on its edge
  // (--sheet-h) instead of at a guessed 72vh. Behaviour is proven with a real
  // click in tests/e2e/atlas-r1-human-awe.spec.ts.
  assert.match(css,/bottom: calc\(var\(--sheet-h\) \+ 12px\)/);
  assert.match(css,/--atlas-sheet-mid:\s*min\(46dvh, 430px\)/);
});

test("camera proof still uses a real native zoom-control click, not force-click masking",async()=>{
  const spec=await readFile(new URL("../tests/e2e/atlas-core-parent-release.spec.ts",import.meta.url),"utf8");
  assert.match(spec,/await zoomIn\.click\(\)/);
  assert.doesNotMatch(spec,/zoomIn\.click\(\{\s*force:\s*true/);
});
