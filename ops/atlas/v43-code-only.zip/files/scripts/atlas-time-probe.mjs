#!/usr/bin/env node
/**
 * ATLAS TIME probe — does choosing a different year/month change the picture?
 *
 * Founder report 08 Oct 2026: "it does not react to time". The control now
 * appears reliably and rewrites the tile request; whether the PROVIDER answers
 * a different slice can only be proven against the deployed bridge, which the
 * sandbox cannot reach. Run this against HEIR or LIVE:
 *
 *   node scripts/atlas-time-probe.mjs https://test.4planet.org
 *
 * For each time-aware layer it fetches the same European tile for two time
 * values through /api/atlas-wms and compares the bytes. Identical bytes for
 * every pair means the provider ignores the TIME value as sent → the time
 * format in src/earth/atlasLeadingExtensions.ts must be corrected (R3 TIME).
 */
import { createHash } from "node:crypto";

const origin = (process.argv[2] || "https://test.4planet.org").replace(/\/+$/, "");
// A 3857 tile over the North Sea / Skagerrak at z5.
const bbox = "0,7514065.628545966,1252344.271424327,8766409.899970295";
const probes = [
  {
    layer: "emodnet-fishing-vessel-density", source: "emodnet-human-activities", version: "1.1.1",
    layers: "vesseldensity_01avg", styles: "VesselDensity", values: ["2017-01-01T00:00:00Z", "2023-01-01T00:00:00Z"],
  },
  {
    layer: "emodnet-dissolved-oxygen-climatology", source: "emodnet-chemistry", version: "1.3.0",
    layers: "All_European_Seas/Water_body_dissolved_oxygen_concentration.nc*Water_body_dissolved_oxygen_concentration_L2",
    styles: "pcolor_flat", elevation: "-0.0", values: ["02", "08"],
  },
];

const sha = (buf) => createHash("sha256").update(buf).digest("hex").slice(0, 16);
let ignored = 0;
for (const probe of probes) {
  const results = [];
  for (const time of probe.values) {
    const params = new URLSearchParams({ source: probe.source, version: probe.version, layers: probe.layers, styles: probe.styles, width: "256", height: "256", bbox, time });
    if (probe.elevation) params.set("elevation", probe.elevation);
    const url = `${origin}/api/atlas-wms?${params}`;
    try {
      const response = await fetch(url);
      const body = Buffer.from(await response.arrayBuffer());
      results.push({ time, status: response.status, type: response.headers.get("content-type"), bytes: body.length, sha: sha(body) });
    } catch (error) {
      results.push({ time, status: "NETWORK", error: String(error.message || error) });
    }
  }
  const same = results.length === 2 && results[0].sha && results[0].sha === results[1].sha;
  if (same) ignored += 1;
  console.log(`${probe.layer}\n${results.map((r) => `  time=${r.time} → ${r.status} ${r.type || ""} ${r.bytes ?? ""} bytes sha ${r.sha ?? r.error}`).join("\n")}\n  verdict: ${same ? "PROVIDER IGNORES THIS TIME VALUE (same image)" : "time changes the image"}\n`);
}
console.log(ignored ? `${ignored} layer(s) do not react to time as sent. Note: the layer names above mirror atlasLeadingExtensions.ts — check them there first.` : "Every probed layer reacts to time.");
process.exit(0);
