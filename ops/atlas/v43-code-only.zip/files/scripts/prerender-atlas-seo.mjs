import fs from "node:fs";
import path from "node:path";
import { ATLAS_ORIGIN, IS_ATLAS_BUILD, canonicalUrl } from "./seo-ownership.mjs";

/**
 * ATLAS search entry: real, crawlable HTML for the interactive map.
 *
 * Canonical ownership: ATLAS lives at the ROOT of its own host
 * (https://4planetatlas.com/). "/atlas" is the compatibility route on every
 * host and canonicalises to that root, so the standalone product and the copy
 * of the same route on 4planet.org never compete.
 *
 * The page is always written to dist/atlas/index.html. In the dedicated ATLAS
 * build it is additionally exported as `atlasEntryHtml` for
 * scripts/finalize-atlas-host.mjs, which serves it at "/".
 */
const root = process.cwd();
const dist = path.join(root, "dist");
const indexPath = path.join(dist, "index.html");
if (!fs.existsSync(indexPath)) throw new Error("dist/index.html missing; run Vite build first");

const canonical = canonicalUrl("/atlas"); // → ATLAS_ORIGIN + "/"
const title = "4PLANET ATLAS — Planetary Intelligence Map";
const description = "See the living planet: Earth observation, places, species records and recent natural events on one interactive map, each with its source and its limits.";
const image = ATLAS_ORIGIN + "/og.png";
const base = fs.readFileSync(indexPath, "utf8");
const inventory = JSON.parse(fs.readFileSync(path.join(root, "src/data/discoveryInventory.json"), "utf8"));
const atlasDiscovery = JSON.parse(fs.readFileSync(path.join(root, "src/data/atlasDiscovery.json"), "utf8"));
const places = (inventory.places || []).filter((item) => item.indexable === true);
const objects = (atlasDiscovery.objects || []).filter((item) => item.indexable === true);

const esc = (v = "") => String(v).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
const json = (v) => JSON.stringify(v).replaceAll("<", "\\u003c");

let html = base
  .replace(/<title>[\s\S]*?<\/title>/i, "")
  .replace(/<meta\s+name=["']description["'][^>]*>/gi, "")
  .replace(/<meta\s+name=["']robots["'][^>]*>/gi, "")
  .replace(/<meta\s+property=["']og:[^"']+["'][^>]*>/gi, "")
  .replace(/<meta\s+name=["']twitter:[^"']+["'][^>]*>/gi, "")
  .replace(/<link\s+rel=["']canonical["'][^>]*>/gi, "");

const structured = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "4PLANET ATLAS",
  alternateName: "4Planet Atlas",
  description,
  url: canonical,
  applicationCategory: "ScienceApplication",
  operatingSystem: "Any modern web browser",
  isAccessibleForFree: true,
  creator: { "@type": "Organization", name: "4PLANET_", url: "https://4planet.org/" },
  about: [
    { "@type": "Thing", name: "Earth observation" },
    { "@type": "Thing", name: "Biodiversity observations" },
    { "@type": "Thing", name: "Living systems" }
  ]
};

const head = [
  `<title>${esc(title)}</title>`,
  `<meta name="description" content="${esc(description)}">`,
  '<meta name="robots" content="index,follow,max-image-preview:large">',
  `<link rel="canonical" href="${esc(canonical)}">`,
  '<meta property="og:type" content="website">',
  '<meta property="og:site_name" content="4PLANET ATLAS">',
  '<meta property="og:locale" content="en_GB">',
  `<meta property="og:title" content="${esc(title)}">`,
  `<meta property="og:description" content="${esc(description)}">`,
  `<meta property="og:url" content="${esc(canonical)}">`,
  `<meta property="og:image" content="${esc(image)}">`,
  '<meta name="twitter:card" content="summary_large_image">',
  `<meta name="twitter:title" content="${esc(title)}">`,
  `<meta name="twitter:description" content="${esc(description)}">`,
  `<meta name="twitter:image" content="${esc(image)}">`,
  `<script type="application/ld+json" data-4planet-atlas-prerender="true">${json(structured)}</script>`
].join("\n    ");

html = html.replace("</head>", `    ${head}\n  </head>`);

// Internal links are what let a crawler walk from the map to every place and
// data page ATLAS owns. They are the same inventory the sitemap lists.
const placeLinks = places.map((place) => `<li><a href="/place/${esc(place.slug)}">${esc(place.name)}</a></li>`).join("\n    ");
const objectLinks = objects.map((object) => `<li><a href="/atlas/${esc(object.slug)}">${esc(object.name)}</a></li>`).join("\n    ");

const crawlableBody = `
<main id="atlas-search-entry">
  <p>4PLANET ATLAS</p>
  <h1>One planet. Many ways to see it.</h1>
  <p>Explore source-grounded planetary intelligence through Earth observation, biodiversity records, species, places and living systems.</p>
  <h2>Places</h2>
  <ul>
    ${placeLinks}
    <li><a href="/places">All places</a></li>
  </ul>
  <h2>What ATLAS shows</h2>
  <ul>
    ${objectLinks}
  </ul>
  <h2>Explore the living planet</h2>
  <ul>
    <li><a href="/places">Places — source-grounded ecological context</a></li>
    <li><a href="/species">Species — identity, evidence and reported observations</a></li>
    <li><a href="/living-systems">Living Systems — relationships, pressures and responses</a></li>
  </ul>
  <h2>Data sources visible in ATLAS</h2>
  <p>ATLAS surfaces public source data from providers including NASA Earthdata/GIBS, GBIF, OBIS, USGS and NOAA. Each layer retains its own scope and limitations.</p>
  <p>Occurrence records are reported observations, not complete range, abundance, population trend or live animal tracking.</p>
</main>`.trim();

html = html.replace('<div id="root"></div>', `<div id="root">${crawlableBody}</div>`);

const target = path.join(dist, "atlas");
fs.mkdirSync(target, { recursive: true });
fs.writeFileSync(path.join(target, "index.html"), html, "utf8");
console.log(`Prerendered ATLAS search entry: ${canonical}${IS_ATLAS_BUILD ? " (dedicated ATLAS build)" : ""}`);
