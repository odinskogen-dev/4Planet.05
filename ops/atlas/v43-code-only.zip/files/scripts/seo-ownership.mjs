/**
 * 4PLANET — CANONICAL URL OWNERSHIP (build side)
 *
 * One repository renders several public hosts. Which host OWNS a route in search
 * is a product decision, not a side effect of which host happened to build it:
 *
 *   ATLAS  https://4planetatlas.com   →  /  ·  /atlas  ·  /atlas/*  ·  /places  ·  /place/*
 *   MAIN   https://4planet.org        →  everything else in this build
 *
 * SPECIES and LIVING SYSTEMS ownership is deliberately untouched here: they keep
 * the MAIN origin exactly as before. Do not move them as collateral work.
 *
 * Keep in step with src/seo/ownership.ts (runtime). scripts/seo-ownership-contract
 * .test.mjs fails if the two disagree.
 */
const clean = (value) => String(value || "").trim().replace(/\/+$/, "");

export const ATLAS_ORIGIN = clean(process.env.PUBLIC_ATLAS_ORIGIN) || "https://4planetatlas.com";
export const DEFAULT_MAIN_ORIGIN = "https://4planet.org";

/** The origin this build will be SERVED from. */
export const BUILD_ORIGIN = clean(process.env.PUBLIC_SITE_ORIGIN || process.env.VITE_PUBLIC_SITE_ORIGIN) || DEFAULT_MAIN_ORIGIN;

const hostOf = (origin) => { try { return new URL(origin).hostname.replace(/^www\./, "").toLowerCase(); } catch { return ""; } };

/** True when this build is the dedicated standalone ATLAS deployment. */
export const IS_ATLAS_BUILD = hostOf(BUILD_ORIGIN) === hostOf(ATLAS_ORIGIN);

/** Origin that owns every non-ATLAS route. An ATLAS build never claims them. */
export const MAIN_ORIGIN = clean(process.env.PUBLIC_MAIN_ORIGIN) || (IS_ATLAS_BUILD ? DEFAULT_MAIN_ORIGIN : BUILD_ORIGIN);

const pathOnly = (value) => {
  const raw = String(value || "/");
  const path = raw.split("#")[0].split("?")[0] || "/";
  return path.length > 1 ? path.replace(/\/+$/, "") : "/";
};

export function isAtlasOwnedPath(value) {
  const path = pathOnly(value);
  return path === "/atlas" || path.startsWith("/atlas/") || path === "/places" || path.startsWith("/place/");
}

/** ATLAS lives at the root of its own host; /atlas is the compatibility route. */
export function canonicalPath(value) {
  const path = pathOnly(value);
  return path === "/atlas" ? "/" : path;
}

/** Canonical absolute URL for a route. Query strings and fragments never canonicalise. */
export function canonicalUrl(value) {
  if (isAtlasOwnedPath(value)) return ATLAS_ORIGIN + canonicalPath(value);
  return MAIN_ORIGIN + pathOnly(value);
}

/**
 * Absolute URL for a link/asset reference inside structured data. Deep ATLAS
 * links ("/atlas?l=fires") keep their query and point at the ATLAS host.
 */
export function absoluteUrl(value) {
  const raw = String(value || "/");
  if (/^https?:\/\//i.test(raw)) return raw;
  const [path, rest = ""] = [raw.split(/[?#]/)[0], raw.slice(raw.split(/[?#]/)[0].length)];
  if (isAtlasOwnedPath(path)) {
    const target = canonicalPath(path);
    return ATLAS_ORIGIN + (target === "/" && rest ? "/" + rest : target + rest);
  }
  return MAIN_ORIGIN + (path.startsWith("/") ? path : "/" + path) + rest;
}

/** Static assets are served by whichever host serves the page that references them. */
export function assetUrl(value, forPath = "/") {
  const raw = String(value || "/og.png");
  if (/^https?:\/\//i.test(raw)) return raw;
  return (isAtlasOwnedPath(forPath) ? ATLAS_ORIGIN : MAIN_ORIGIN) + (raw.startsWith("/") ? raw : "/" + raw);
}
