import type { Page, Route } from "@playwright/test";

/**
 * OFFLINE WORLD — deterministic provider fixtures for ATLAS behavioural proof.
 *
 * Every external host ATLAS talks to is answered locally, in the SHAPE the real
 * provider uses, so the product's own behaviour can be proven without depending
 * on (or loading) NASA, GBIF, USGS, iNaturalist or the basemap provider. These
 * are test fixtures. They are not product data and never ship.
 *
 * `fail` makes a provider unreachable, to prove that a source failure is said as
 * a failure and never rendered as zero.
 */
export type OfflineOptions = { fail?: Array<"gbif" | "eonet" | "usgs" | "inat" | "place">; emptyArea?: boolean };

const BACKBONE = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c";
const LAND = { type: "FeatureCollection", features: [
  { type: "Feature", properties: {}, geometry: { type: "Polygon", coordinates: [[[-10, 36], [30, 36], [40, 60], [28, 71], [5, 62], [-10, 44], [-10, 36]]] } },
  { type: "Feature", properties: {}, geometry: { type: "Polygon", coordinates: [[[-17, 14], [10, 37], [35, 31], [51, 11], [40, -15], [20, -34], [12, -17], [-17, 14]]] } },
] };

const style = (mode: "dark" | "light") => ({
  version: 8,
  name: mode === "dark" ? "OpenFreeMap Dark (offline fixture)" : "OpenFreeMap Liberty light (offline fixture)",
  sources: { land: { type: "geojson", data: LAND } },
  layers: [
    { id: "bg", type: "background", paint: { "background-color": mode === "dark" ? "#0c2340" : "#cfe0ee" } },
    { id: "land", type: "fill", source: "land", paint: { "fill-color": mode === "dark" ? "#3d5a45" : "#e9ecdf" } },
  ],
});

const SPECIES: Record<string, { canonicalName: string; class: string; eng: string | null }> = {
  "2440483": { canonicalName: "Orcinus orca", class: "Mammalia", eng: "Killer whale" },
  "2498252": { canonicalName: "Somateria mollissima", class: "Aves", eng: "Common eider" },
  "2440669": { canonicalName: "Phocoena phocoena", class: "Mammalia", eng: "Harbour porpoise" },
  "2481139": { canonicalName: "Larus argentatus", class: "Aves", eng: "European herring gull" },
  "9999001": { canonicalName: "Argyropelecus lychnus", class: "Actinopterygii", eng: null },
};

const json = (route: Route, body: unknown, status = 200) =>
  route.fulfill({ status, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify(body) });

const hoursAgo = (h: number) => new Date(Date.now() - h * 3600e3).toISOString();

export async function offlineWorld(page: Page, options: OfflineOptions = {}) {
  const fail = new Set(options.fail ?? []);
  const seen: string[] = [];
  const firstParty = new URL(process.env.BASE_URL || "http://localhost:4173").hostname;

  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    const host = url.hostname;
    const path = url.pathname;

    if (host === firstParty || host === "localhost" || host === "127.0.0.1") {
      if (path === "/api/atlas-feed") {
        seen.push("atlas-feed");
        if (fail.has("eonet")) return json(route, { ok: false, error: "UPSTREAM_503" }, 502);
        return json(route, { ok: true, source: "eonet", retrievedAt: new Date().toISOString(), data: { events: [
          { id: "EONET_1", title: "Wildfire — Paraguay, Boquerón", categories: [{ title: "Wildfires" }], geometry: [{ date: hoursAgo(5), coordinates: [-60.1, -21.4] }] },
          { id: "EONET_2", title: "Tropical Storm Krosa", categories: [{ title: "Severe Storms" }], geometry: [{ date: hoursAgo(9), coordinates: [132.5, 21.2] }] },
          { id: "EONET_3", title: "Etna Volcano, Italy", categories: [{ title: "Volcanoes" }], geometry: [{ date: hoursAgo(30), coordinates: [14.99, 37.75] }] },
        ] } });
      }
      if (path === "/api/atlas-place") {
        seen.push("atlas-place");
        if (fail.has("place")) return json(route, { ok: false, error: "UPSTREAM_503" }, 502);
        const land = url.searchParams.get("land") === "1";
        // Deterministic FIXTURE text — not Wikipedia, not RESOLVE. It proves layout and
        // truth handling only.
        return json(route, {
          ok: true, retrievedAt: new Date().toISOString(),
          ecoregion: land
            ? { status: "OK", value: { name: "Fixture ecoregion", biome: "Temperate broadleaf and mixed forests", realm: "Palearctic", nnh: "Nature Could Recover", nnhSentence: "Too little natural habitat remains for half to be protected today; restoration could change that.", id: 1, areaKm2: 100000 } }
            : { status: "NOT_ASKED", value: null },
          about: { status: "OK", value: { title: "Fixture place", description: null, extract: "Fixture lead for the offline proof. It stands where the first two sentences of the Wikipedia article appear on the live site.", url: "https://en.wikipedia.org/wiki/Special:Random", licence: "CC BY-SA 4.0" } },
          ecoregionAbout: { status: "NONE", value: null },
        });
      }
      if (path.startsWith("/api/")) return json(route, { ok: false, error: "NOT_AVAILABLE_OFFLINE" }, 502);
      return route.continue();
    }

    if (host === "tiles.openfreemap.org") {
      if (path.endsWith("/dark")) return json(route, style("dark"));
      if (path.endsWith("/liberty")) return json(route, style("dark"));
      return route.abort();
    }

    if (host === "api.gbif.org") {
      seen.push(`gbif:${path}`);
      if (fail.has("gbif")) return route.abort();
      const q = url.searchParams;
      if (path === "/v1/species/search") {
        if (q.get("datasetKey") !== BACKBONE) {
          // What GBIF returns WITHOUT the backbone filter: one usage per checklist,
          // with keys the occurrence index does not understand.
          return json(route, { results: [177668116, 177668117, 177668118].map((key) => ({ key, scientificName: "Orcinus orca", rank: "SPECIES", vernacularNames: [{ language: "eng", vernacularName: "Orca" }] })) });
        }
        return json(route, { results: (q.get("q") || "").toLowerCase().includes("orc")
          ? [{ key: 2440483, nubKey: 2440483, datasetKey: BACKBONE, scientificName: "Orcinus orca (Linnaeus, 1758)", canonicalName: "Orcinus orca", rank: "SPECIES", kingdom: "Animalia", vernacularNames: [{ language: "eng", vernacularName: "Killer whale" }] }]
          : [] });
      }
      if (path === "/v1/species/match") return json(route, { usageKey: 2440483, scientificName: "Orcinus orca (Linnaeus, 1758)", canonicalName: "Orcinus orca", rank: "SPECIES" });
      const species = /^\/v1\/species\/(\d+)(\/vernacularNames)?$/.exec(path);
      if (species) {
        const row = SPECIES[species[1]];
        if (!row) return json(route, {}, 404);
        if (species[2]) return json(route, { results: row.eng ? [{ language: "eng", vernacularName: row.eng }] : [] });
        return json(route, { key: Number(species[1]), canonicalName: row.canonicalName, class: row.class });
      }
      if (path === "/v1/occurrence/search") {
        if (q.get("facet") === "speciesKey") {
          if (options.emptyArea) return json(route, { count: 0, results: [], facets: [{ field: "SPECIES_KEY", counts: [] }] });
          return json(route, { count: 48211, results: [], facets: [{ field: "SPECIES_KEY", counts: [
            { name: "2498252", count: 9120 }, { name: "2481139", count: 7044 }, { name: "2440669", count: 1322 }, { name: "9999001", count: 212 },
          ] }] });
        }
        const key = q.get("taxonKey");
        if (key && key !== "2440483") return json(route, { count: 0, results: [] });
        const base = key ? [-20, 45] : [10.55, 59.45];
        const spread = key ? [26, 14] : [0.25, 0.3];
        return json(route, { count: key ? 31418 : 48211, results: Array.from({ length: 60 }, (_, i) => ({
          key: 1000 + i, taxonKey: 2440483, species: key ? "Orcinus orca" : "Somateria mollissima",
          scientificName: key ? "Orcinus orca (Linnaeus, 1758)" : "Somateria mollissima (Linnaeus, 1758)",
          decimalLongitude: base[0] + Math.cos(i * 1.3) * spread[0], decimalLatitude: base[1] + Math.sin(i * 1.7) * spread[1],
        })) });
      }
      return json(route, {});
    }

    if (host === "api.inaturalist.org") return fail.has("inat") ? route.abort() : json(route, { results: [] });

    if (host === "earthquake.usgs.gov") {
      seen.push("usgs");
      if (fail.has("usgs")) return route.abort();
      const quake = (id: string, mag: number, place: string, h: number) => ({ id, properties: { mag, place, time: Date.now() - h * 3600e3, url: `https://earthquake.usgs.gov/earthquakes/eventpage/${id}` }, geometry: { coordinates: [-155 + mag, 54, 10] } });
      return json(route, { features: [
        quake("us1", 5.6, "243 km SE of Chignik, Alaska", 3), quake("us2", 4.8, "62 km W of Illapel, Chile", 11),
        ...Array.from({ length: 40 }, (_, i) => quake(`s${i}`, 0.5 + (i % 20) / 10, `${3 + i} km NW of The Geysers, CA`, 0.5 + i * 0.3)),
      ] });
    }

    if (host === "eonet.gsfc.nasa.gov") { seen.push("eonet-direct"); return route.abort(); }
    // Fonts, imagery tiles, analytics: unreachable offline. The product must not depend on them to work.
    return route.abort();
  });

  return { seen };
}

export async function openAtlas(page: Page, query = "") {
  await page.goto(`/atlas?atlasCiWebgl=1${query ? `&${query}` : ""}`);
  await page.waitForFunction(() => Boolean((window as any).__4planet_map?.isStyleLoaded?.()), undefined, { timeout: 30_000 });
  // Let the one-time startup settle (theme check, first idle) so a test measures
  // what the visitor does, not the boot sequence.
  await page.waitForFunction(() => { const m = (window as any).__4planet_map; return m.loaded() && !m.isMoving(); }, undefined, { timeout: 30_000 });
  await page.waitForTimeout(600);
}
