import { test, expect, type Locator, type Page } from "@playwright/test";
import { offlineWorld, openAtlas } from "./fixtures/atlasOfflineWorld";

/**
 * ATLAS R1 — HUMAN AWE FIRST · behavioural proof
 *
 * What a first-time visitor on a phone can feel, proven with real clicks against
 * the running product. Providers are answered by deterministic fixtures
 * (fixtures/atlasOfflineWorld.ts), so this proves ATLAS's own behaviour — one
 * surface at a time, human first read, honest gaps, working map — not the
 * availability of NASA or GBIF on the day.
 *
 * It does NOT prove: real provider responses, real basemap labels, real-device
 * Safari behaviour or the credentialed 4PLANET ID journey. Those stay AXE/human gates.
 */
const COMPACT = ["mobile-390", "mobile-430", "webkit-390", "webkit-430"];
const compactOnly = (name: string) => test.skip(!COMPACT.includes(name), "compact-screen proof");

type Box = { x: number; y: number; width: number; height: number };
const overlaps = (a: Box, b: Box) => a.x < b.x + b.width - 0.5 && a.x + a.width > b.x + 0.5 && a.y < b.y + b.height - 0.5 && a.y + a.height > b.y + 0.5;
const boxOf = async (locator: Locator) => { await expect(locator).toBeVisible(); return (await locator.boundingBox())!; };
const surface = (page: Page) => page.locator(".world").getAttribute("data-atlas-surface");
const camera = (page: Page) => page.evaluate(() => { const m = (window as any).__4planet_map; const c = m.getCenter(); return { zoom: m.getZoom(), lng: c.lng, lat: c.lat }; });

/** Every visible control is a real touch target and no text is smaller than 12px. */
async function craft(page: Page) {
  return page.evaluate(() => {
    const visible = (el: Element) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none" && Number(s.opacity) > 0.05 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth; };
    const label = (el: Element) => (el.getAttribute("aria-label") || el.textContent || "").trim().slice(0, 28);
    const small = [...document.querySelectorAll('button, a[href], input, [role="button"], [role="option"], summary')].filter(visible)
      .filter((el) => { const r = el.getBoundingClientRect(); return r.width < 43.5 || r.height < 43.5; }).map((el) => `${label(el)} ${Math.round(el.getBoundingClientRect().width)}×${Math.round(el.getBoundingClientRect().height)}`);
    const tiny = [...document.querySelectorAll(".world *, .atlas-saved-views *, .atlas-product-identity *")].filter((el) => el.children.length === 0 && el.textContent!.trim() && visible(el))
      .filter((el) => parseFloat(getComputedStyle(el).fontSize) < 12).map((el) => `${label(el)} ${getComputedStyle(el).fontSize}`);
    return { small, tiny, overflowX: document.documentElement.scrollWidth - innerWidth };
  });
}

test("R1 A — first open: Earth, one search line, one dock, nothing colliding", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  // NO INVISIBLE WORK at boot: the default (dark) visit loads exactly one basemap style.
  const styles: string[] = [];
  page.on("request", (request) => { if (/tiles\.openfreemap\.org\/styles\//.test(request.url())) styles.push(new URL(request.url()).pathname); });
  await openAtlas(page);
  expect(styles).toEqual(["/styles/dark"]);

  expect(await surface(page)).toBe("REST");
  const identity = await boxOf(page.locator(".atlas-product-identity"));
  const search = await boxOf(page.locator(".search-line"));
  const dock = await boxOf(page.locator(".atlas-dock"));
  const zoom = await boxOf(page.locator(".maplibregl-ctrl-group").first());
  for (const [a, b] of [[identity, search], [search, dock], [dock, zoom], [search, zoom]] as const) expect(overlaps(a, b)).toBe(false);

  const viewport = page.viewportSize()!;
  const covered = [identity, search, dock, zoom].reduce((sum, b) => sum + b.width * b.height, 0) / (viewport.width * viewport.height);
  expect(covered, "the interface is a frame; Earth is the screen").toBeLessThan(0.2);

  const quality = await craft(page);
  expect(quality.overflowX).toBeLessThanOrEqual(1);
  expect(quality.small, "touch targets under 44px").toEqual([]);
  expect(quality.tiny, "text under 12px").toEqual([]);

  // 16px is the floor below which iOS Safari zooms the page on focus and leaves it panned.
  expect(parseFloat(await page.locator(".search-line input").evaluate((el) => getComputedStyle(el).fontSize))).toBeGreaterThanOrEqual(16);
  await expect(page.locator(".atlas-hint")).toContainText("Tap anywhere on Earth");
});

test("R1 B — species: one result, real records, nothing over the panel", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page);

  await page.locator(".search-line input").click();
  await page.locator(".search-line input").fill("Orca");
  await expect(page.locator(".results .ritem")).toHaveCount(1);
  expect(await surface(page)).toBe("SEARCH");
  await expect(page.locator(".atlas-dock")).toBeHidden();
  expect((await craft(page)).overflowX).toBeLessThanOrEqual(1);

  await page.locator(".results .ritem").first().click();
  const panel = page.locator(".ctx");
  await expect(panel.locator(".ctx-title")).toHaveText("Orca");
  await expect(panel.locator(".lead-fact")).toContainText("31,418");
  await expect(panel).not.toContainText(/no records/i);
  await expect.poll(() => decodeURIComponent(page.url())).toContain("entity=taxon:gbif:2440483");

  // Nothing floats over the header: the element under the close button IS the close button.
  const close = await boxOf(panel.locator(".ctx-close"));
  expect(await page.evaluate(([x, y]) => document.elementFromPoint(x, y)?.closest("button")?.className ?? "", [close.x + close.width / 2, close.y + close.height / 2])).toContain("ctx-close");
  await expect(page.locator(".search-line")).toBeHidden();
  await expect(page.locator(".atlas-dock")).toBeHidden();

  const follow = await boxOf(panel.locator(".follow-btn"));
  expect(follow.y + follow.height, "Follow is on the first read, without scrolling").toBeLessThanOrEqual(page.viewportSize()!.height);
});

test("R1 C — place: human first read, exact evidence one tap away, map stays the visitor's", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page);

  await page.locator(".search-line input").click();
  await page.locator(".search-line input").fill("Oslofjord");
  await page.locator(".results .ritem").filter({ hasText: "Oslofjord" }).first().click();
  const panel = page.locator(".ctx");
  await expect(panel.locator(".ctx-title")).toHaveText("Oslofjord");
  await expect(panel.getByText("Common eider")).toBeVisible();

  const firstRead = await panel.evaluate((el) => { const copy = el.cloneNode(true) as HTMLElement; copy.querySelector(".evidence")?.remove(); return copy.innerText; });
  expect(firstRead).not.toMatch(/place:4p|SEEDED|BOUNDING BOX|bounding box|°[NS]/);

  const follow = await boxOf(panel.locator(".follow-btn"));
  expect(follow.y + follow.height).toBeLessThanOrEqual(page.viewportSize()!.height);

  // A real click on the native zoom control, with the sheet open.
  const before = await camera(page);
  await page.locator(".maplibregl-ctrl-zoom-in").click();
  await expect.poll(async () => Math.abs((await camera(page)).zoom - before.zoom)).toBeGreaterThan(0.1);
  await page.waitForFunction(() => !(window as any).__4planet_map.isMoving());
  const owned = await camera(page);
  await page.waitForTimeout(1_500);
  const later = await camera(page);
  expect(Math.abs(later.zoom - owned.zoom), "late data must not take the camera back").toBeLessThan(0.02);

  await panel.locator(".evidence > summary").click();
  const evidence = panel.locator(".evidence");
  await expect(evidence).toContainText("place:4p:oslofjord");
  await expect(evidence).toContainText("Bounding box");
  await expect(evidence).toContainText("not the boundary of the place");
  await expect(evidence).toContainText("GBIF");

  await panel.locator(".follow-btn").click();
  await expect(panel.locator(".follow-btn")).toHaveText(/Following/);
});

test("R1 D — a source failure is said as a failure, never shown as zero", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "mobile-390", "one project is enough for truth states");
  await offlineWorld(page, { fail: ["gbif", "eonet"] });
  await openAtlas(page);

  await page.locator(".search-line input").click();
  await page.locator(".search-line input").fill("Orca");
  await expect(page.locator(".results-note.bad")).toContainText("did not answer", { timeout: 20_000 });
  await expect(page.locator(".results")).not.toContainText("Nothing matched");

  await page.locator(".search-line input").fill("Oslofjord");
  await page.locator(".results .ritem").filter({ hasText: "Oslofjord" }).first().click();
  await expect(page.locator(".ctx")).toContainText("Species records are unavailable right now", { timeout: 20_000 });
  await expect(page.locator(".ctx")).toContainText("not an empty place");
  await page.locator(".ctx .ctx-close").click();

  await page.locator('[data-atlas-action="now"]').click();
  const now = page.locator(".lens-panel");
  await expect(now).toContainText("Magnitude 5.6 earthquake", { timeout: 20_000 });
  await expect(now).toContainText("did not answer");
  await expect(now.locator('.sec[data-status="SOURCE_UNAVAILABLE"]')).toHaveCount(1);
  await expect(now).not.toContainText("No records returned");
});

test("R1 E — a tap on Earth is named from open place data, with no geocoder", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  const requests: string[] = [];
  page.on("request", (request) => requests.push(request.url()));
  await openAtlas(page);

  // Larvik, Norway — named from the committed GeoNames + Natural Earth files.
  await page.evaluate(() => (window as any).__4planet_map.jumpTo({ center: [10.027, 59.053], zoom: 6 }));
  await page.waitForTimeout(400);
  const map = await boxOf(page.locator(".world-map"));
  await page.mouse.click(map.x + map.width / 2, map.y + map.height / 2);
  const panel = page.locator(".ctx");
  await expect(panel.locator(".ctx-title")).toHaveText("Larvik");
  await expect(panel.locator(".ctx-kind")).toHaveText("Town");
  await expect(panel.locator(".ctx-sub")).toContainText("Norway");
  await expect(panel.locator(".glance")).toContainText("Local time");
  await expect(panel.getByText("Living setting")).toBeVisible();
  await expect(panel.getByText("Recorded around here")).toBeVisible();
  await expect(panel.getByText("Common eider")).toBeVisible();
  expect(requests.some((url) => /\/atlas-data\/places\/v1\/cells\//.test(url))).toBe(true);
  expect(requests.some((url) => /bigdatacloud|nominatim|geocod/i.test(url))).toBe(false);
});

test("R1 E2 — when the place files cannot load, ATLAS says so and still answers", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page, { fail: ["place"] });
  await page.route("**/atlas-data/places/**", (route) => route.abort());
  await openAtlas(page);
  const map = await boxOf(page.locator(".world-map"));
  await page.mouse.click(map.x + map.width / 2, map.y + map.height * 0.42);
  const panel = page.locator(".ctx");
  await expect(panel.locator(".ctx-kind")).toHaveText("Here");
  await expect(panel.getByText("Recorded around here")).toBeVisible();
  await panel.locator(".evidence > summary").click();
  await expect(panel.locator(".evidence")).toContainText("The place files did not load");
});

test("R1 E3 — search reaches places worldwide and opens what is there", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page);
  await page.locator(".search-line input").fill("Bergamo");
  const hit = page.locator('[data-atlas-world-place="Bergamo"]').first();
  await expect(hit).toContainText("Italy");
  await hit.click();
  const panel = page.locator(".ctx");
  await expect(panel.locator(".ctx-title")).toHaveText("Bergamo", { timeout: 15_000 });
  await expect(panel.locator(".ctx-sub")).toContainText("Italy");
});

test("R1 F — layers: plain names, one switch, the legend keeps the meaning in reach", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page);

  await page.locator('[data-atlas-action="layers"]').click();
  const sheet = page.locator(".atlas-panel");
  await expect(sheet).toBeVisible();
  await expect(sheet).toContainText("Sea surface temperature");
  await expect(sheet).not.toContainText(/NDVI|OCE4N|WH4LES|QU4KES/);
  const quality = await craft(page);
  expect(quality.small).toEqual([]);
  expect(quality.overflowX).toBeLessThanOrEqual(1);

  await page.locator('[data-atlas-layer="sst"] .alyr').click();
  await expect.poll(() => surface(page), "turning a layer on hands the screen back to Earth").toBe("REST");
  const legend = page.locator(".atlas-legend");
  await expect(legend).toContainText("Sea surface temperature");
  expect(decodeURIComponent(page.url())).toMatch(/l=[^&]*sst/);
  expect(overlaps(await boxOf(legend), await boxOf(page.locator(".atlas-dock")))).toBe(false);
  expect(overlaps(await boxOf(legend), await boxOf(page.locator(".maplibregl-ctrl-group").first()))).toBe(false);

  await legend.click();
  const detail = page.locator('[data-atlas-layer="sst"] .drawer');
  await expect(detail).toContainText("Analysis");
  await expect(detail).toContainText("GHRSST");
});

test("R1 G — Now: what happened, in plain words; tremors kept but not dumped", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  const world = await offlineWorld(page);
  await openAtlas(page);
  expect(world.seen, "NO INVISIBLE WORK: no event feed is loaded before it is asked for").not.toContain("usgs");

  await page.locator('[data-atlas-action="now"]').click();
  const now = page.locator(".lens-panel");
  await expect(now.getByText("Wildfire", { exact: true })).toBeVisible();
  await expect(now.getByText("Severe storm", { exact: true })).toBeVisible();
  await expect(now.getByText("Magnitude 5.6 earthquake")).toBeVisible();
  await expect(now.locator(".li")).toHaveCount(5); // 3 events + 2 felt earthquakes
  await expect(now.locator(".disclose")).toHaveText(/Show 40 smaller earthquakes/);
  await now.locator(".disclose").click();
  await expect(now.locator(".li")).toHaveCount(45);
  expect(world.seen).toContain("atlas-feed");
  expect(world.seen, "the CSP-blocked direct EONET call is not attempted when the bridge answers").not.toContain("eonet-direct");
});

test("R1 H/I — My Atlas works anonymously; repeated surface cycles leave a clean, movable map", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page);
  await page.evaluate(() => { const m = (window as any).__4planet_map; (window as any).__styleSwaps = 0; const original = m.setStyle.bind(m); m.setStyle = (...args: unknown[]) => { (window as any).__styleSwaps += 1; return original(...args); }; });

  await page.locator('[data-atlas-action="my-atlas"]').click();
  await expect(page.locator(".atlas-saved-views.open")).toBeVisible();
  await expect(page.locator(".atlas-dock")).toBeHidden();
  await page.getByRole("button", { name: "Save this view", exact: true }).click();
  await expect(page.locator(".atlas-saved-row")).toHaveCount(1);
  expect((await craft(page)).small).toEqual([]);
  await page.locator(".atlas-saved-close").click();
  await expect.poll(() => surface(page)).toBe("REST");

  const steps: Array<() => Promise<void>> = [
    async () => { await page.locator(".search-line input").click(); await page.locator(".search-exit").click(); },
    async () => { await page.locator('[data-atlas-action="layers"]').click(); await page.locator(".atlas-panel .sect").click(); },
    async () => { await page.locator(".search-line input").click(); await page.locator(".search-line input").fill("Oslofjord"); await page.locator(".results .ritem").first().click(); await page.locator(".ctx .ctx-close").click(); },
    async () => { await page.locator('[data-atlas-action="my-atlas"]').click(); await page.locator(".atlas-saved-close").click(); },
    async () => { await page.locator('[data-atlas-action="now"]').click(); await page.locator(".lens-panel .ctx-close").click(); },
  ];
  for (let cycle = 0; cycle < 3; cycle += 1) {
    for (const step of steps) {
      await step();
      await expect.poll(() => surface(page)).toBe("REST");
      const state = await page.evaluate(() => { const c = document.querySelector(".maplibregl-canvas")!.getBoundingClientRect(); return { dw: Math.abs(c.width - innerWidth), dh: Math.abs(c.height - innerHeight), overflowX: document.documentElement.scrollWidth - innerWidth }; });
      expect(state.dw).toBeLessThanOrEqual(1);
      expect(state.dh).toBeLessThanOrEqual(1);
      expect(state.overflowX).toBeLessThanOrEqual(1);
    }
  }

  expect(await page.evaluate(() => (window as any).__styleSwaps), "NO INVISIBLE WORK: surfaces never re-set the basemap style").toBe(0);

  const viewport = page.viewportSize()!;
  const before = await camera(page);
  await page.mouse.move(viewport.width / 2, viewport.height * 0.45);
  await page.mouse.down();
  await page.mouse.move(viewport.width / 2 - 90, viewport.height * 0.45 + 30, { steps: 6 });
  await page.mouse.up();
  await expect.poll(async () => { const now = await camera(page); return Math.abs(now.lng - before.lng) + Math.abs(now.lat - before.lat); }).toBeGreaterThan(0.0005);

  await page.locator('[data-atlas-action="now"]').click();
  await page.keyboard.press("Escape");
  await expect.poll(() => surface(page)).toBe("REST");
});

test("R1 — wide screens: one identity, one column beside Earth, one surface", async ({ page }, testInfo) => {
  test.skip(!["desktop-1440", "desktop-1280"].includes(testInfo.project.name), "wide-screen proof");
  await offlineWorld(page);
  await openAtlas(page);

  await expect(page.locator(".atlas-product-identity")).toBeHidden();
  const switcher = await boxOf(page.locator(".atlas-product-switcher"));
  const search = await boxOf(page.locator(".search-line"));
  const dock = await boxOf(page.locator(".atlas-dock"));
  expect(overlaps(switcher, search)).toBe(false);
  expect(overlaps(search, dock)).toBe(false);

  await page.locator(".search-line input").fill("Oslofjord");
  await page.locator(".results .ritem").filter({ hasText: "Oslofjord" }).first().click();
  const panel = await boxOf(page.locator(".ctx"));
  const viewport = page.viewportSize()!;
  expect(panel.y + panel.height).toBeLessThanOrEqual(viewport.height + 0.5);
  expect(panel.width).toBeLessThanOrEqual(400);
  expect(overlaps(panel, search)).toBe(false);
  expect(overlaps(panel, dock)).toBe(false);
  expect(overlaps(panel, await boxOf(page.locator(".maplibregl-ctrl-group").first()))).toBe(false);

  await page.locator('[data-atlas-action="layers"]').click();
  await expect(page.locator(".ctx")).toHaveCount(0);
  await expect(page.locator(".atlas-panel")).toBeVisible();
  expect((await craft(page)).overflowX).toBeLessThanOrEqual(1);
});

test("R1 — a time-aware layer offers Time even when its provider's tiles fail", async ({ page }) => {
  // The offline world aborts provider tiles. MapLibre then never reports `idle`,
  // which used to leave the Time control hidden for a layer that IS on the map.
  await offlineWorld(page);
  await openAtlas(page, "l=bluemarble,emodnet-fishing-vessel-density&z=4&c=5,58");

  const toggle = page.getByRole("button", { name: /^Time/ });
  await expect(toggle).toBeVisible();
  expect(overlaps(await boxOf(toggle), await boxOf(page.locator(".atlas-dock")))).toBe(false);
  expect(overlaps(await boxOf(toggle), await boxOf(page.locator(".search-line")))).toBe(false);
  const legend = page.locator(".atlas-legend");
  if (await legend.count()) expect(overlaps(await boxOf(toggle), await boxOf(legend))).toBe(false);

  await toggle.click();
  const body = page.locator(".atlas-leading-time-body");
  await expect(body).toContainText("Fishing activity");
  await expect(body).toContainText("Historical");
  await body.getByRole("button", { name: "2021" }).click();
  await expect(page).toHaveURL(/atlasTime=emodnet-fishing-vessel-density%3A2021/);
  expect((await craft(page)).overflowX).toBeLessThanOrEqual(1);
});

test("v43 — the address bar is never rewritten fast enough to break Safari", async ({ page }) => {
  await page.addInitScript(() => {
    const original = history.replaceState.bind(history);
    (window as any).__replaceCalls = [];
    history.replaceState = (...args: Parameters<History["replaceState"]>) => { (window as any).__replaceCalls.push(Date.now()); return original(...args); };
  });
  await offlineWorld(page);
  await openAtlas(page, "l=bluemarble,emodnet-fishing-vessel-density,sst,truecolor");
  // Every provider tile fails in the offline world: the old failure-repaint loop
  // drove idle → URL writes past 100 per 10 s on a real iPhone.
  for (let i = 0; i < 12; i += 1) {
    await page.evaluate((n) => (window as any).__4planet_map.easeTo({ center: [n * 7 - 40, 20], zoom: 2 + (n % 3), duration: 250 }), i);
    await page.waitForTimeout(300);
  }
  await page.waitForTimeout(1500);
  const calls: number[] = await page.evaluate(() => (window as any).__replaceCalls);
  const now = Date.now();
  const lastTen = calls.filter((t) => now - t <= 10_000).length;
  expect(lastTen, `replaceState calls in the last 10 s: ${lastTen}`).toBeLessThanOrEqual(45);
  await expect(page.locator(".world")).toBeVisible();
});

test("v43 — dark ATLAS is Ink + E4RTH green, light ATLAS is Paper + 4PLANET Blue", async ({ page }) => {
  await offlineWorld(page);
  await openAtlas(page);
  const paint = () => page.evaluate(() => {
    const dock = document.querySelector(".atlas-dock")!;
    const word = document.querySelector(".atlas-product-identity .wordmark, .status-strip .wordmark");
    return { dock: getComputedStyle(dock).backgroundColor, accent: getComputedStyle(document.documentElement).getPropertyValue("--atlas-accent").trim(), word: word ? getComputedStyle(word).color : "" };
  });
  const dark = await paint();
  expect(dark.dock).toBe("rgb(20, 21, 24)");
  expect(dark.word).toBe("rgb(58, 232, 111)");
  await page.goto("/atlas?atlasCiWebgl=1&t=light");
  await page.waitForFunction(() => Boolean((window as any).__4planet_map?.isStyleLoaded?.()), undefined, { timeout: 30_000 });
  await page.waitForTimeout(500);
  const light = await paint();
  expect(light.dock).toBe("rgb(255, 255, 255)");
  expect(light.word).toBe("rgb(46, 46, 255)");
});

test("v43 — Time opens as a sheet on a phone, not a box over the controls", async ({ page }, testInfo) => {
  compactOnly(testInfo.project.name);
  await offlineWorld(page);
  await openAtlas(page, "l=bluemarble,emodnet-dissolved-oxygen-climatology&z=4&c=5,58");
  await page.getByRole("button", { name: /^Time/ }).click();
  const body = page.locator(".atlas-leading-time-body");
  await expect(body).toBeVisible();
  const box = await boxOf(body);
  const viewport = page.viewportSize()!;
  expect(Math.round(box.x)).toBe(0);
  expect(Math.round(box.width)).toBe(viewport.width);
  expect(Math.round(box.y + box.height)).toBeGreaterThanOrEqual(viewport.height - 1);
  await expect(page.locator(".atlas-dock")).toBeHidden();
  await body.getByRole("button", { name: "Close Time" }).click();
  await expect(body).toHaveCount(0);
  await expect(page.locator(".atlas-dock")).toBeVisible();
});
