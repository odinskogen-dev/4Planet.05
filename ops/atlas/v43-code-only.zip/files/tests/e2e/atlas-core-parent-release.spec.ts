import { test, expect, type Locator, type Page } from "@playwright/test";

async function waitForAtlas(page: Page) {
  await page.waitForFunction(() => {
    const map = (window as any).__4planet_map;
    return Boolean(map?.isStyleLoaded?.());
  }, undefined, { timeout: 25_000 });
}

async function visibleBox(locator: Locator) {
  await expect(locator).toBeVisible();
  const box = await locator.boundingBox();
  expect(box).not.toBeNull();
  return box!;
}

function overlaps(a: { x: number; y: number; width: number; height: number }, b: { x: number; y: number; width: number; height: number }) {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

async function expectNoOverlap(a: Locator, b: Locator) {
  const [boxA, boxB] = await Promise.all([visibleBox(a), visibleBox(b)]);
  expect(overlaps(boxA, boxB)).toBe(false);
}

test("CORE PARENT — ATLAS carries explicit 4PLANET identity", async ({ page }, testInfo) => {
  await page.goto("/atlas");
  await waitForAtlas(page);
  // R1: one identity per screen. Compact screens carry the ATLAS wordmark; wide
  // screens carry the shared typographic product switcher instead of a second mark.
  const compact = ["mobile-390", "mobile-430", "webkit-390", "webkit-430"].includes(testInfo.project.name);
  if (compact) {
    const identity = page.locator(".atlas-product-identity");
    await expect(identity).toBeVisible();
    await expect(identity).toContainText("4PLANET_");
    await expect(identity).toContainText("ATLAS");
    await expect(identity.getByRole("link")).toHaveAttribute("href", "/");
  } else {
    await expect(page.locator(".atlas-product-switcher")).toBeVisible();
    await expect(page.locator(".atlas-product-switcher")).toContainText("ATLAS");
    await expect(page.locator(".atlas-product-identity")).toBeHidden();
  }
});

test("CORE PARENT — mobile ATLAS primary controls do not collide", async ({ page }, testInfo) => {
  test.skip(!["mobile-390", "mobile-430", "webkit-390", "webkit-430"].includes(testInfo.project.name), "mobile geometry proof only");
  await page.goto("/atlas");
  await waitForAtlas(page);

  // R1: the resting state is Earth, one search line and one dock. Layers, Watch,
  // Now and My Atlas are doors in that dock rather than separate floating controls.
  const identity = page.locator(".atlas-product-identity");
  const search = page.locator(".search-line");
  const dock = page.locator(".atlas-dock");
  const mapControls = page.locator(".maplibregl-ctrl-group").first();

  for (const locator of [identity, search, dock, mapControls]) {
    await expect(locator).toBeVisible();
  }
  for (const action of ["now", "layers", "watch", "my-atlas"]) {
    await expect(page.locator(`[data-atlas-action="${action}"]`)).toBeVisible();
  }
  await expect(page.locator(".atlas-panel")).toBeHidden();
  await expect(page.locator(".atlas-saved-views")).toBeHidden();

  await expectNoOverlap(identity, search);
  await expectNoOverlap(search, dock);
  await expectNoOverlap(dock, mapControls);
  await expectNoOverlap(search, mapControls);

  const time = page.locator(".atlas-leading-time");
  if (await time.isVisible().catch(() => false)) {
    await expectNoOverlap(dock, time);
    await expectNoOverlap(search, time);
  }

  const viewport = page.viewportSize()!;
  for (const locator of [identity, search, dock, mapControls]) {
    const box = await locator.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.x).toBeGreaterThanOrEqual(-0.5);
    expect(box!.x + box!.width).toBeLessThanOrEqual(viewport.width + 0.5);
    expect(box!.y).toBeGreaterThanOrEqual(-0.5);
    expect(box!.y + box!.height).toBeLessThanOrEqual(viewport.height + 0.5);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
});

test("CORE PARENT — returned mobile camera remains the user-created camera after responsive settling", async ({ page }, testInfo) => {
  test.skip(!["mobile-390", "mobile-430", "webkit-390", "webkit-430"].includes(testInfo.project.name), "mobile return-camera proof only");

  const target = { zoom: 7.35, lng: -6.25, lat: 46.4 };
  await page.goto(`/atlas?record=orca-bundled&z=${target.zoom}&c=${target.lng},${target.lat}`);
  await waitForAtlas(page);
  await page.getByText("BUNDLED SOURCE SNAPSHOT", { exact: false }).waitFor({ state: "visible", timeout: 20_000 });

  await page.waitForTimeout(4_200);
  const settled = await page.evaluate(() => {
    const map = (window as any).__4planet_map;
    const center = map.getCenter();
    return { zoom: map.getZoom(), lng: center.lng, lat: center.lat };
  });

  expect(Math.abs(settled.zoom - target.zoom)).toBeLessThanOrEqual(0.05);
  expect(Math.abs(settled.lng - target.lng)).toBeLessThanOrEqual(0.05);
  expect(Math.abs(settled.lat - target.lat)).toBeLessThanOrEqual(0.05);

  // Prove user ownership with an actual browser click on ATLAS' visible map control.
  // Mobile projects emulate touch-capable devices, where synthetic mouse-wheel input can
  // be ignored; the zoom control is a real user-facing input and crosses the same
  // MapLibre user-release boundary deterministically.
  const zoomIn = page.locator(".maplibregl-ctrl-zoom-in");
  await expect(zoomIn).toBeVisible();
  await zoomIn.click();
  await page.waitForFunction((baselineZoom) => {
    const map = (window as any).__4planet_map;
    return map && Math.abs(map.getZoom() - Number(baselineZoom)) > 0.1 && !map.isMoving() && !map.isZooming() && !(typeof map.isEasing === "function" && map.isEasing());
  }, target.zoom, { timeout: 8_000 });

  const userOwned = await page.evaluate(() => {
    const map = (window as any).__4planet_map;
    const center = map.getCenter();
    return { zoom: map.getZoom(), lng: center.lng, lat: center.lat };
  });
  expect(Math.abs(userOwned.zoom - target.zoom)).toBeGreaterThan(0.1);

  // Responsive/style settling must not reclaim the original return camera once
  // a genuine user gesture has taken ownership.
  await page.waitForTimeout(1_200);
  const afterSettle = await page.evaluate(() => {
    const map = (window as any).__4planet_map;
    const center = map.getCenter();
    return { zoom: map.getZoom(), lng: center.lng, lat: center.lat };
  });
  expect(Math.abs(afterSettle.zoom - userOwned.zoom)).toBeLessThanOrEqual(0.05);
  expect(Math.abs(afterSettle.lng - userOwned.lng)).toBeLessThanOrEqual(0.05);
  expect(Math.abs(afterSettle.lat - userOwned.lat)).toBeLessThanOrEqual(0.05);
});
