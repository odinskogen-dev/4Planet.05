/**
 * Founder decision 08 Oct 2026: ATLAS shows only images under fully open
 * licences — free to reuse, commercially too, with attribution at most.
 *
 *   accepted: CC0 · Public Domain Mark · CC BY · CC BY-SA
 *   refused:  anything NonCommercial (NC) or NoDerivatives (ND),
 *             "all rights reserved", unknown or missing licences.
 *
 * Returns a short human label for the accepted licence, or null. A null means
 * the image is not shown — never shown with a weaker caption.
 */
export function openLicence(raw: unknown): string | null {
  const text = String(raw ?? "").trim().toLowerCase();
  if (!text) return null;
  if (/all rights reserved|\(c\)|©|copyright/.test(text) && !/creativecommons|cc[\s-]?(0|by)/.test(text)) return null;
  // Normalise both codes ("cc-by-sa", "CC_BY_4_0") and URLs (creativecommons.org/licenses/by-sa/4.0/).
  const t = text.replace(/_/g, "-").replace(/\s+/g, "-");
  if (/(^|[^a-z])(nc|nd)([^a-z]|$)|noncommercial|non-commercial|noderiv/.test(t)) return null;
  if (/publicdomain\/zero|(^|[^a-z])cc-?0([^0-9]|$)|cc0/.test(t)) return "CC0";
  if (/publicdomain\/mark|public-domain|^pd$|^pdm$/.test(t)) return "Public domain";
  const version = (t.match(/(\d\.\d)/) || [])[1];
  const v = version ? ` ${version}` : "";
  if (/licenses\/by-sa|(^|[^a-z])cc-by-sa/.test(t)) return `CC BY-SA${v}`;
  if (/licenses\/by\/|(^|[^a-z])cc-by($|[^a-z-])|(^|[^a-z])cc-by-\d/.test(t)) return `CC BY${v}`;
  return null;
}
