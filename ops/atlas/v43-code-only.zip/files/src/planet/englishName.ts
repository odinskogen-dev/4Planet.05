/**
 * The English name a person would recognise, chosen from GBIF's vernacular
 * names. Taking the first "eng" entry gave "Renard Roux" for the red fox and
 * "Native Scots Pinewood" for Scots pine: some publishing datasets label other
 * languages, habitats or local terms as English. So the names are voted on —
 * the same name from several independent sources wins, names flagged
 * `preferred` and names from curated checklists count more, and anything that
 * is not plausibly an English species name is set aside. No vote → no name
 * (the scientific name is then the title; nothing is invented).
 */
const CURATED_NAME_SOURCE = /catalogue of life|integrated taxonomic|itis|iucn|world register of marine|worms|ncbi|wikipedia|avibase|ioc world bird|clements|mammal diversity|artsdatabanken|eunis|fishbase|reptile database/i;
const NOT_A_SPECIES_NAME = /\b(pinewood|woodland|forest|population|stock|habitat|community|plantation|native|introduced|assemblage)\b/i;
const NON_ENGLISH_HINT = /\b(le|la|les|de|du|des|der|die|das|und|el|los|las|del|och|og|il|lo)\b|[àâäçéèêëîïôöùûüÿñßåøæ]/i;

export function bestEnglishName(rows: any[] | undefined, scientificName = ""): string | undefined {
  const sci = String(scientificName).trim().toLowerCase();
  const votes = new Map<string, { name: string; score: number }>();
  for (const v of rows ?? []) {
    if (!v || v.language !== "eng") continue;
    const name = String(v.vernacularName ?? "").trim().replace(/\s+/g, " ");
    if (!name || name.length > 48 || name.toLowerCase() === sci) continue;
    if (NOT_A_SPECIES_NAME.test(name) || NON_ENGLISH_HINT.test(name)) continue;
    const key = name.toLowerCase();
    const entry = votes.get(key) ?? { name, score: 0 };
    entry.score += 1 + (v.preferred ? 2 : 0) + (CURATED_NAME_SOURCE.test(String(v.source ?? "")) ? 2 : 0);
    votes.set(key, entry);
  }
  const best = [...votes.values()].sort((a, b) => b.score - a.score || a.name.length - b.name.length)[0];
  if (!best) return undefined;
  const t = best.name;
  return t.charAt(0).toUpperCase() + t.slice(1);
}
