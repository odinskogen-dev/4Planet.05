/* ═══════════════════════════════════════════════════════════════════════════
   4PLANET_ — ADAPTATION LAYER — CONNECTORS
   STATUS: ADAPTATION. NOT THE CANONICAL CONNECTOR CONTRACT. (Brief §80)

   Every function here does exactly one thing: take a real external feed and
   return a 4PLANET-shaped record with its provenance attached. Nothing in this
   file interprets, ranks, promotes or infers. That is deliberate.

   Rules observed:
     - No source-specific field escapes this file. (Brief §85: "SOURCE-SPECIFIC
       FIELDS LEAKING THROUGH THE ENTIRE CORE MODEL" is a named anti-pattern.
       V36 leaked GBIF's `speciesKey` and OBIS's `aphiaID` straight into map
       feature properties and into popup HTML strings. Stops here.)
     - A failure returns an empty result AND a status. It never returns a lie.
     - checkedAt is stamped on every record, because "when did 4PLANET ask" is
       a different time from "when did it happen". (Brief §27.)
   ═══════════════════════════════════════════════════════════════════════════ */

import { openLicence } from "./openLicence";
import { bestEnglishName } from "./englishName";
export { bestEnglishName };
import type { Occurrence, Signal } from "./types";
import { signalId, taxonId } from "./ids";

const now = () => new Date().toISOString();
const titleCase = (s: string) =>
  String(s ?? "").replace(/\w\S*/g, (t) => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase());

/** Every network call goes through here, so failure is uniform and honest. */
export type Result<T> = { ok: true; data: T } | { ok: false; error: string };

const getJson = async (url: string, ms = 12000): Promise<Result<any>> => {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { signal: ctl.signal });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    return { ok: true, data: await r.json() };
  } catch (e: any) {
    return { ok: false, error: e?.name === "AbortError" ? "TIMEOUT" : "NETWORK" };
  } finally {
    clearTimeout(t);
  }
};

/* ── GBIF ────────────────────────────────────────────────────────────────── */

export interface TaxonHit {
  id: string; // canonical: taxon:gbif:<key>
  gbifKey: number;
  scientificName: string;
  commonName?: string;
  rank?: string;
  kingdom?: string;
}

type TaxonQueryAlias = { scientificName: string; commonName: string };

/*
 * Search aliases are query-expansion only. They do not create taxon identity.
 * GBIF still resolves the canonical key and accepted scientific name. These few
 * high-intent public terms prevent the most important 4PLANET journeys from
 * depending on whether a provider happened to include one English vernacular
 * name in a particular autocomplete payload.
 */
const TAXON_QUERY_ALIASES: Record<string, TaxonQueryAlias> = {
  orca: { scientificName: "Orcinus orca", commonName: "Orca" },
  "killer whale": { scientificName: "Orcinus orca", commonName: "Killer Whale" },
  "humpback": { scientificName: "Megaptera novaeangliae", commonName: "Humpback Whale" },
  "humpback whale": { scientificName: "Megaptera novaeangliae", commonName: "Humpback Whale" },
  jaguar: { scientificName: "Panthera onca", commonName: "Jaguar" },
  "sperm whale": { scientificName: "Physeter macrocephalus", commonName: "Sperm Whale" },
  "fin whale": { scientificName: "Balaenoptera physalus", commonName: "Fin Whale" },
  "blue whale": { scientificName: "Balaenoptera musculus", commonName: "Blue Whale" },
};

const normaliseTaxonQuery = (value: string) => value.trim().toLowerCase().replace(/\s+/g, " ");

export function expandTaxonQuery(q: string): { raw: string; search: string; preferredCommonName?: string } {
  const raw = q.trim();
  const alias = TAXON_QUERY_ALIASES[normaliseTaxonQuery(raw)];
  return {
    raw,
    search: alias?.scientificName ?? raw,
    preferredCommonName: alias?.commonName,
  };
}

/** GBIF Backbone Taxonomy — the only checklist whose keys occurrence search resolves. */
export const GBIF_BACKBONE_DATASET = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c";

/** "Orcinus orca (Linnaeus, 1758)" → "Orcinus orca". Display only; identity stays the key. */
export const binomialOf = (scientificName: string): string => {
  const clean = String(scientificName ?? "").trim();
  const m = /^([A-Z][a-z-]+(?:\s[a-z][a-z-]+){1,2})\b/.exec(clean);
  return m ? m[1] : clean;
};

const taxonSearchCache = new Map<string, { at: number; result: Result<TaxonHit[]> }>();
const TAXON_SEARCH_CACHE_MS = 5 * 60 * 1000;

/**
 * Species suggest. The original V36 insight remains: one broad GBIF query can
 * bury the animal a normal person means. This version keeps the broad +
 * vertebrate merge, adds canonical query expansion for high-intent journeys,
 * and caches short-lived results so reopening the same species does not feel
 * like a fresh network round trip every time.
 */
export const searchTaxa = async (q: string): Promise<Result<TaxonHit[]>> => {
  const expanded = expandTaxonQuery(q);
  if (expanded.raw.length < 3) return { ok: true, data: [] };

  const cacheKey = normaliseTaxonQuery(expanded.raw);
  const cached = taxonSearchCache.get(cacheKey);
  if (cached && Date.now() - cached.at < TAXON_SEARCH_CACHE_MS) return cached.result;

  const rawLower = expanded.raw.toLowerCase();
  const searchLower = expanded.search.toLowerCase();
  // species/search spans EVERY checklist GBIF hosts. Without datasetKey it returns
  // one name usage per checklist (three visually identical "Orca" rows) whose keys
  // are NOT backbone keys — and occurrence/search?taxonKey= only understands
  // backbone keys, so opening one of those rows truthfully-but-wrongly reported
  // NO RECORDS for a species GBIF holds thousands of records for. Restrict the
  // suggest to the GBIF Backbone Taxonomy so every key is occurrence-resolvable.
  const url = (query: string, extra = "") =>
    `https://api.gbif.org/v1/species/search?q=${encodeURIComponent(
      query,
    )}&rank=SPECIES&status=ACCEPTED&datasetKey=${GBIF_BACKBONE_DATASET}${extra}&limit=20`;

  const requests: Array<Promise<Result<any>>> = [
    getJson(url(expanded.raw)),
    getJson(url(expanded.search, "&highertaxonKey=44")),
  ];
  if (normaliseTaxonQuery(expanded.search) !== cacheKey) requests.push(getJson(url(expanded.search)));
  if (expanded.preferredCommonName) {
    requests.push(getJson(`https://api.gbif.org/v1/species/match?name=${encodeURIComponent(expanded.search)}&strict=true`));
  }

  const responses = await Promise.all(requests);
  const successful = responses.filter((result): result is { ok: true; data: any } => result.ok);
  if (!successful.length) return { ok: false, error: "GBIF unreachable" };

  const rows: any[] = [];
  for (const result of successful) {
    if (Array.isArray(result.data?.results)) rows.push(...result.data.results);
    else if (result.data?.usageKey && result.data?.scientificName) {
      rows.unshift({
        ...result.data,
        key: result.data.usageKey,
        vernacularNames: expanded.preferredCommonName
          ? [{ language: "eng", vernacularName: expanded.preferredCommonName }]
          : [],
      });
    }
  }

  const seen = new Set<number>();
  const seenNames = new Set<string>();
  const aliasScientific = expanded.preferredCommonName ? searchLower : "";
  const hits = rows
    .map((h: any) => {
      // Always carry the backbone key. A row from another checklist is only
      // usable through its nubKey; without one it cannot resolve occurrences.
      const backboneKey = h.datasetKey && h.datasetKey !== GBIF_BACKBONE_DATASET ? h.nubKey : (h.nubKey ?? h.key);
      const display = h.canonicalName || binomialOf(h.scientificName || "");
      return { ...h, key: backboneKey, scientificName: display };
    })
    .filter((h: any) => {
      if (!h.key || !h.scientificName) return false;
      const nameKey = String(h.scientificName).toLowerCase();
      if (seen.has(h.key) || seenNames.has(nameKey)) return false;
      seen.add(h.key); seenNames.add(nameKey);
      return true;
    })
    .map((h: any) => {
      const sci = String(h.scientificName).toLowerCase();
      const vn = bestEnglishName(h.vernacularNames, h.scientificName);
      const providerCommon = vn ? titleCase(vn) : undefined;
      const preferredCommon = aliasScientific && sci === aliasScientific ? expanded.preferredCommonName : undefined;
      const commonName = preferredCommon ?? providerCommon;
      const common = (commonName ?? "").toLowerCase();

      let score = 50;
      if (aliasScientific && sci === aliasScientific) score = -20;
      else if (common === rawLower) score = -12;
      else if (sci === rawLower) score = -10;
      else if (common.startsWith(rawLower)) score = 0;
      else if (common.includes(rawLower)) score = 2;
      else if (sci.startsWith(rawLower)) score = 4;
      else if (sci.includes(rawLower)) score = 6;
      else if (sci.startsWith(searchLower)) score = 8;
      else if (sci.includes(searchLower)) score = 10;

      return {
        hit: {
          id: taxonId(h.key),
          gbifKey: h.key,
          scientificName: h.scientificName,
          commonName,
          rank: h.rank,
          kingdom: h.kingdom,
        } as TaxonHit,
        score,
      };
    })
    .sort((a, b) => a.score - b.score || a.hit.scientificName.localeCompare(b.hit.scientificName))
    .slice(0, 7)
    .map((x) => x.hit);

  const result: Result<TaxonHit[]> = { ok: true, data: hits };
  taxonSearchCache.set(cacheKey, { at: Date.now(), result });
  return result;
};

export const taxonVernacular = async (gbifKey: number | string): Promise<string | undefined> => {
  const r = await getJson(`https://api.gbif.org/v1/species/${gbifKey}/vernacularNames?limit=60`);
  if (!r.ok) return undefined;
  const en = bestEnglishName(r.data.results);
  return en ? titleCase(en) : undefined;
};

const toOccurrence = (o: any): Occurrence | null => {
  if (typeof o.decimalLatitude !== "number" || typeof o.decimalLongitude !== "number") return null;
  // Only accept a media image when the record also carries a licence, so the
  // observation panel never shows an image without rights (ORCA-05, §13E).
  // Founder decision 08 Oct 2026: fully open licences only (openLicence.ts).
  const media = Array.isArray(o.media)
    ? o.media.find((m: any) => m?.type === "StillImage" && m?.identifier && openLicence(m?.license || m?.rights))
    : undefined;
  return {
    lat: o.decimalLatitude,
    lng: o.decimalLongitude,
    // `species` is the canonical binomial; `scientificName` carries authorship
    // ("Mirounga angustirostris (Gill, 1866)"), which is citation depth, not a name.
    scientificName: o.species || binomialOf(o.scientificName ?? "") || "Unidentified",
    commonName: o.vernacularName || undefined,
    eventDate: o.eventDate ? String(o.eventDate).slice(0, 10) : undefined,
    sourceRecordId: o.key ? String(o.key) : undefined,
    sourceUrl: o.key ? `https://www.gbif.org/occurrence/${o.key}` : undefined,
    taxonKey: typeof o.taxonKey === "number" ? o.taxonKey : undefined,
    coordinateUncertaintyM:
      typeof o.coordinateUncertaintyInMeters === "number" ? o.coordinateUncertaintyInMeters : undefined,
    mediaUrl: media?.identifier,
    mediaLicence: media ? openLicence(media.license || media.rights) || undefined : undefined,
    mediaAttribution: media?.rightsHolder || media?.creator || "GBIF contributor",
  };
};

/** Where has this taxon been recorded? Brief: records are records, not range. */
export const taxonOccurrences = async (
  gbifKey: number | string,
  limit = 300,
): Promise<Result<{ rows: Occurrence[]; total: number }>> => {
  // GBIF caps occurrence page size at 300; asking for more is not honoured.
  const r = await getJson(
    `https://api.gbif.org/v1/occurrence/search?taxonKey=${gbifKey}&hasCoordinate=true&limit=${Math.min(300, Math.max(1, limit))}`,
  );
  if (!r.ok) return { ok: false, error: r.error };
  const rows = (r.data.results ?? []).map(toOccurrence).filter(Boolean) as Occurrence[];
  return { ok: true, data: { rows, total: r.data.count ?? rows.length } };
};

/** Recent records of a taxon, anywhere. Used by WATCH — see watch.ts for the caveat. */
export const taxonOccurrencesSince = async (
  gbifKey: number | string,
  sinceIso: string,
  limit = 60,
): Promise<Result<{ rows: Occurrence[]; total: number }>> => {
  const today = new Date().toISOString().slice(0, 10);
  const r = await getJson(
    `https://api.gbif.org/v1/occurrence/search?taxonKey=${gbifKey}&hasCoordinate=true` +
      `&eventDate=${sinceIso},${today}&limit=${limit}`,
  );
  if (!r.ok) return { ok: false, error: r.error };
  const rows = (r.data.results ?? []).map(toOccurrence).filter(Boolean) as Occurrence[];
  return { ok: true, data: { rows, total: r.data.count ?? rows.length } };
};

/** What life has been recorded inside this polygon? Powers PLACE. */
export const occurrencesInWkt = async (
  wkt: string,
  opts: { taxonKey?: number | string; limit?: number; sinceIso?: string } = {},
): Promise<Result<{ rows: Occurrence[]; total: number; names: string[] }>> => {
  const q = new URLSearchParams();
  q.set("hasCoordinate", "true");
  q.set("geometry", wkt);
  q.set("limit", String(opts.limit ?? 300));
  if (opts.taxonKey) q.set("taxonKey", String(opts.taxonKey));
  if (opts.sinceIso) q.set("eventDate", `${opts.sinceIso},${new Date().toISOString().slice(0, 10)}`);

  const r = await getJson(`https://api.gbif.org/v1/occurrence/search?${q.toString()}`);
  if (!r.ok) return { ok: false, error: r.error };
  const rows = (r.data.results ?? []).map(toOccurrence).filter(Boolean) as Occurrence[];
  const names = [...new Set(rows.map((o) => o.scientificName))].filter(Boolean);
  return { ok: true, data: { rows, total: r.data.count ?? rows.length, names } };
};

/**
 * WHAT HAS BEEN RECORDED HERE, IN WORDS A PERSON USES.
 *
 * One facet query asks GBIF which species have the most records inside the query
 * geometry; each is then resolved to its backbone name and English vernacular.
 * This is a statement about RECORDS in a QUERY AREA: it is not a species list for
 * a place, not abundance and not presence today. The caller must keep saying so.
 * Earned only by an explicit place/point question, cached per session, bounded.
 */
export interface AreaSpecies {
  gbifKey: number;
  id: string; // taxon:gbif:<key>
  scientificName: string;
  commonName?: string;
  records: number;
  /** Class-level group from the backbone ("Aves", "Mammalia") — for plain grouping only. */
  group?: string;
}

const speciesNameCache = new Map<number, { scientificName: string; commonName?: string; group?: string }>();
const areaSpeciesCache = new Map<string, { at: number; result: Result<{ species: AreaSpecies[]; total: number }> }>();
const AREA_SPECIES_CACHE_MS = 10 * 60 * 1000;

const resolveSpeciesName = async (key: number) => {
  const hit = speciesNameCache.get(key);
  if (hit) return hit;
  const [usage, names] = await Promise.all([
    getJson(`https://api.gbif.org/v1/species/${key}`, 8000),
    getJson(`https://api.gbif.org/v1/species/${key}/vernacularNames?limit=80`, 8000),
  ]);
  if (!usage.ok) return null;
  const en = names.ok ? bestEnglishName(names.data.results, usage.data.canonicalName) : undefined;
  // Capitalise the first letter only. Lower-casing the rest would damage proper
  // nouns inside a name ("Atlantic cod", "European herring gull").
  const capFirst = (name: string) => { const t = String(name).trim(); return t.charAt(0).toUpperCase() + t.slice(1); };
  const value = {
    scientificName: usage.data.canonicalName || binomialOf(usage.data.scientificName || ""),
    // English only. GBIF's top-level `vernacularName` can be any language.
    commonName: en ? capFirst(en) : undefined,
    group: usage.data.class || usage.data.phylum || usage.data.kingdom || undefined,
  };
  if (!value.scientificName) return null;
  speciesNameCache.set(key, value);
  return value;
};

export const topSpeciesInWkt = async (
  wkt: string,
  take = 6,
): Promise<Result<{ species: AreaSpecies[]; total: number }>> => {
  const cached = areaSpeciesCache.get(wkt);
  if (cached && Date.now() - cached.at < AREA_SPECIES_CACHE_MS) return cached.result;

  const q = new URLSearchParams();
  q.set("hasCoordinate", "true");
  q.set("geometry", wkt);
  q.set("limit", "0");
  q.set("facet", "speciesKey");
  q.set("facetLimit", String(Math.min(12, Math.max(1, take + 2))));
  const r = await getJson(`https://api.gbif.org/v1/occurrence/search?${q.toString()}`);
  if (!r.ok) return { ok: false, error: r.error };

  const counts: Array<{ name: string; count: number }> = r.data?.facets?.[0]?.counts ?? [];
  const keys = counts
    .map((c) => ({ key: Number(c.name), records: Number(c.count) }))
    .filter((c) => Number.isFinite(c.key) && c.key > 0)
    .slice(0, take + 2);
  const resolved = await Promise.all(keys.map(async (c) => {
    const name = await resolveSpeciesName(c.key);
    return name ? { gbifKey: c.key, id: taxonId(c.key), records: c.records, ...name } as AreaSpecies : null;
  }));
  const result: Result<{ species: AreaSpecies[]; total: number }> = {
    ok: true,
    data: { species: (resolved.filter(Boolean) as AreaSpecies[]).slice(0, take), total: Number(r.data?.count ?? 0) },
  };
  areaSpeciesCache.set(wkt, { at: Date.now(), result });
  return result;
};

/* ── OBIS ────────────────────────────────────────────────────────────────── */

export const cetaceanOccurrences = async (size = 800): Promise<Result<Occurrence[]>> => {
  const r = await getJson(
    `https://api.obis.org/v3/occurrence?scientificname=Cetacea&hascoordinate=true&size=${size}`,
  );
  if (!r.ok) return { ok: false, error: r.error };
  const rows: Occurrence[] = (r.data.results ?? [])
    .filter((o: any) => o.decimalLatitude && o.decimalLongitude)
    .map((o: any) => ({
      lat: o.decimalLatitude,
      lng: o.decimalLongitude,
      scientificName: o.scientificName ?? "Cetacea",
      commonName: o.vernacularName ? titleCase(o.vernacularName) : undefined,
      eventDate: o.eventDate ? String(o.eventDate).slice(0, 10) : undefined,
      // P0 (V38R): SOURCE ≠ SOURCE RECORD. An AphiaID is a WoRMS *taxon* identity,
      // not the identity of this OBIS occurrence. Use OBIS's own record id where
      // it exists; otherwise leave it undefined rather than substitute a taxon id.
      sourceRecordId: o.id ? String(o.id) : undefined,
      // Link to the OBIS occurrence record when OBIS gives us an id. We do NOT
      // link a concrete observation to a WoRMS taxon page and call it the record.
      sourceUrl: o.id ? `https://obis.org/occurrence/${o.id}` : undefined,
    }));
  return { ok: true, data: rows };
};

/* ── SIGNALS: NASA EONET ─────────────────────────────────────────────────── */

const eonetClass = (cat: string): "FIRE_ACTIVITY" | "NATURAL_EVENT" =>
  /fire|wildfire/i.test(cat) ? "FIRE_ACTIVITY" : "NATURAL_EVENT";

const eonetKind = (cat: string) =>
  /storm/i.test(cat)
    ? "SEVERE STORM"
    : /ice/i.test(cat)
      ? "ICEBERG / SEA ICE"
      : /volcano/i.test(cat)
        ? "VOLCANIC ACTIVITY"
        : /fire/i.test(cat)
          ? "ACTIVE WILDFIRE"
          : cat.toUpperCase();

/**
 * EONET is read through the existing same-origin, allowlisted /api/atlas-feed
 * bridge. The production Content-Security-Policy does not list
 * eonet.gsfc.nasa.gov in connect-src, so the direct browser call was refused
 * before it left the page — and that refusal used to render as "NO RECORDS".
 * The direct call remains only as a fallback where the bridge is absent
 * (local dev without Pages Functions).
 */
const eonetEvents = async (limit: number): Promise<Result<any[]>> => {
  const bridged = await getJson("/api/atlas-feed?source=eonet");
  if (bridged.ok && bridged.data?.ok === true && Array.isArray(bridged.data?.data?.events)) {
    return { ok: true, data: bridged.data.data.events };
  }
  const direct = await getJson(`https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=${limit}`);
  if (direct.ok && Array.isArray(direct.data?.events)) return { ok: true, data: direct.data.events };
  return { ok: false, error: bridged.ok ? "CONTRACT_MISMATCH" : bridged.error };
};

export const eonetSignals = async (limit = 300): Promise<Result<Signal[]>> => {
  const r = await eonetEvents(limit);
  if (!r.ok) return { ok: false, error: r.error };
  const checkedAt = now();

  const out: Signal[] = [];
  for (const e of r.data ?? []) {
    const g = (e.geometry ?? []).slice(-1)[0];
    if (!g || !Array.isArray(g.coordinates) || typeof g.coordinates[0] !== "number") continue;
    const cat = e.categories?.[0]?.title ?? "Event";
    out.push({
      id: signalId("eonet", String(e.id)),
      cls: eonetClass(cat),
      title: eonetKind(cat),
      summary: e.title ?? "",
      lng: g.coordinates[0],
      lat: g.coordinates[1],
      significance: "UNCLASSIFIED",
      provenance: {
        sourceId: "eonet",
        sourceRecordId: String(e.id),
        sourceUrl: e.link ?? e.sources?.[0]?.url,
        interpretation: "SOURCE_RECORD",
        // The event is open in NASA's feed. Its ecological meaning is not established.
        confidence: "MEDIUM",
        occurredAt: g.date ?? undefined,
        checkedAt,
      },
    });
  }
  return { ok: true, data: out };
};

/* ── SIGNALS: USGS ───────────────────────────────────────────────────────── */

export const usgsSignals = async (): Promise<Result<Signal[]>> => {
  const r = await getJson(
    "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson",
  );
  if (!r.ok) return { ok: false, error: r.error };
  const checkedAt = now();

  const out: Signal[] = (r.data.features ?? [])
    .filter((f: any) => f?.geometry?.coordinates)
    .map((f: any) => ({
      id: signalId("usgs", String(f.id)),
      cls: "SEISMIC" as const,
      title: `M ${f.properties.mag ?? "?"}`,
      magnitude: typeof f.properties.mag === "number" ? f.properties.mag : undefined,
      summary: f.properties.place ?? "",
      lng: f.geometry.coordinates[0],
      lat: f.geometry.coordinates[1],
      significance: "UNCLASSIFIED" as const,
      provenance: {
        sourceId: "usgs",
        sourceRecordId: String(f.id),
        sourceUrl: f.properties.url,
        interpretation: "SOURCE_RECORD" as const,
        confidence: "HIGH" as const,
        occurredAt: f.properties.time ? new Date(f.properties.time).toISOString() : undefined,
        checkedAt,
      },
    }));
  return { ok: true, data: out };
};

/* ── iNaturalist photo (reference imagery only) ──────────────────────────── */

export interface TaxonPhoto {
  url: string;
  attribution: string;
  /** Short label of the open licence the photo is published under (openLicence.ts). */
  licence: string;
}

const inatPhoto = (photo: any): TaxonPhoto | null => {
  const licence = openLicence(photo?.license_code);
  const url = photo?.medium_url ?? photo?.square_url ?? (photo?.url ? String(photo.url).replace("/square.", "/medium.") : undefined);
  if (!licence || !url) return null;
  return { url, licence, attribution: String(photo.attribution ?? "iNaturalist").replace(/<[^>]*>/g, "") };
};

/**
 * Preserved from V36, including its bug fix: iNat fuzzy-matches, and asking for
 * "Cetacea" once returned a deer. Only an exact scientific-name match is trusted.
 *
 * Founder decision 08 Oct 2026: only fully open licences (CC0, CC BY, CC BY-SA).
 * When the default photo is "all rights reserved" or NonCommercial, the taxon's
 * other photos are checked for an open one; otherwise there is no photo.
 */
export const taxonPhoto = async (scientificName: string): Promise<TaxonPhoto | null> => {
  const q = String(scientificName ?? "").trim();
  if (!q) return null;
  const r = await getJson(
    `https://api.inaturalist.org/v1/taxa?q=${encodeURIComponent(q)}&per_page=5`,
    8000,
  );
  if (!r.ok) return null;
  const want = q.toLowerCase();
  const t = (r.data.results ?? []).find((x: any) => String(x.name ?? "").toLowerCase() === want);
  if (!t) return null;
  const first = inatPhoto(t.default_photo);
  if (first) return first;
  if (!t.id) return null;
  const full = await getJson(`https://api.inaturalist.org/v1/taxa/${encodeURIComponent(String(t.id))}`, 8000);
  if (!full.ok) return null;
  const photos = (full.data.results?.[0]?.taxon_photos ?? []).map((tp: any) => tp?.photo);
  for (const photo of photos) {
    const open = inatPhoto(photo);
    if (open) return open;
  }
  return null;
};