/**
 * 4PLANET — CANONICAL URL OWNERSHIP (runtime side)
 *
 * Mirror of scripts/seo-ownership.mjs. One repository renders several public
 * hosts; which host owns a route in search is a product decision:
 *
 *   ATLAS  https://4planetatlas.com   →  /  ·  /atlas  ·  /atlas/*  ·  /places  ·  /place/*
 *   MAIN   the origin serving the page →  everything else
 *
 * SPECIES and LIVING SYSTEMS ownership is deliberately untouched.
 */
export const ATLAS_ORIGIN = "https://4planetatlas.com";
export const DEFAULT_MAIN_ORIGIN = "https://4planet.org";

const ATLAS_HOSTS = new Set(["4planetatlas.com", "www.4planetatlas.com", "4planet-atlas.pages.dev"]);

export function isAtlasHost(hostname?: string): boolean {
  const host = String(hostname ?? (typeof window === "undefined" ? "" : window.location.hostname)).toLowerCase();
  return ATLAS_HOSTS.has(host) || host.endsWith(".4planet-atlas.pages.dev");
}

const pathOnly = (value: string): string => {
  const path = String(value || "/").split("#")[0].split("?")[0] || "/";
  return path.length > 1 ? path.replace(/\/+$/, "") : "/";
};

export function isAtlasOwnedPath(value: string): boolean {
  const path = pathOnly(value);
  return path === "/atlas" || path.startsWith("/atlas/") || path === "/places" || path.startsWith("/place/");
}

/** ATLAS lives at the root of its own host; /atlas is the compatibility route. */
export function canonicalPath(value: string): string {
  const path = pathOnly(value);
  return path === "/atlas" ? "/" : path;
}

/**
 * Canonical absolute URL for a route.
 * `servingOrigin` is the configured public origin, else the page's own origin.
 * A page served from the ATLAS host never claims a non-ATLAS route for itself.
 */
export function canonicalUrlFor(path: string, servingOrigin: string): string {
  if (isAtlasOwnedPath(path)) return ATLAS_ORIGIN + canonicalPath(path);
  let host = "";
  try { host = new URL(servingOrigin).hostname; } catch { /* malformed origin → treat as main */ }
  const main = isAtlasHost(host) ? DEFAULT_MAIN_ORIGIN : servingOrigin.replace(/\/+$/, "");
  return main + pathOnly(path);
}

/**
 * Where a link to a 4PLANET family page should point from the page you are on.
 * On the standalone ATLAS host, pages ATLAS does not own live at 4planet.org, so
 * the visitor reaches the real page (and its canonical) instead of a copy served
 * from 4planetatlas.com. Everywhere else the route stays in-app.
 */
export function familyHref(path: string, hostname?: string): string {
  const host = hostname ?? (typeof window === "undefined" ? "" : window.location.hostname);
  if (!isAtlasHost(host) || isAtlasOwnedPath(path)) return path;
  return `${DEFAULT_MAIN_ORIGIN}${path === "/" ? "/" : path}`;
}
