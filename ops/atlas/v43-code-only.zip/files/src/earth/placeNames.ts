/* ═══════════════════════════════════════════════════════════════════════════
   4PLANET_ — ATLAS — WHERE IS THIS POINT?
   ───────────────────────────────────────────────────────────────────────────
   Names a tapped point from the basemap ATLAS has ALREADY loaded. No request is
   sent anywhere: the vector tiles in memory carry OpenStreetMap place and water
   labels, and those are read directly from the tile source.

   Why the source and not the rendered labels: on the globe ATLAS hides basemap
   symbol layers (rear-hemisphere glyph bleed), so a rendered-feature query finds
   no labels at exactly the zoom where most people tap. The label DATA is still in
   the loaded tiles.

   Truth rules:
     · A name is the NEAREST LABEL, and the result always carries the distance.
       It is never presented as "this point is inside X".
     · Too far for the current zoom → no name. The caller says so plainly.
     · This replaces a window.fetch monkey-patch that intercepted a third-party
       reverse-geocoder request. Nothing here leaves the device.
   ═══════════════════════════════════════════════════════════════════════════ */

export interface PointDescription {
  /** Nearest named place label, if one is close enough to be meaningful. */
  name?: string;
  /** Great-circle distance from the point to that label, km. */
  distanceKm?: number;
  /** OpenMapTiles class of the label: city, town, village, island, country… */
  placeClass?: string;
  /** True when the point lies on a rendered water polygon; undefined if unknown. */
  onWater?: boolean;
  /** Nearest named sea / ocean / lake label when the point is on water. */
  waterName?: string;
  waterDistanceKm?: number;
}

type LngLat = { lng: number; lat: number };

const toRad = (deg: number) => (deg * Math.PI) / 180;
export const kmBetween = (a: LngLat, b: LngLat): number => {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(h)));
};

const nameOf = (properties: Record<string, unknown> | undefined): string => {
  const p = properties ?? {};
  for (const key of ["name:en", "name_en", "name:latin", "name", "name_int"]) {
    const value = p[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return "";
};

/** A label is only a fair answer within a distance that fits what the user can see. */
export const nameRadiusKm = (zoom: number): number => {
  if (zoom >= 11) return 6;
  if (zoom >= 9) return 15;
  if (zoom >= 7) return 40;
  if (zoom >= 5) return 120;
  if (zoom >= 3) return 350;
  return 700;
};

/** Settlements and islands describe a point; continents and countries do not. */
const LOCAL_CLASSES = new Set([
  "city", "town", "village", "hamlet", "suburb", "quarter", "neighbourhood", "isolated_dwelling", "island", "islet", "locality",
]);
const REGION_CLASSES = new Set(["state", "province", "region", "country"]);

const pointOf = (feature: any): LngLat | null => {
  const g = feature?.geometry;
  if (!g) return null;
  if (g.type === "Point" && Array.isArray(g.coordinates)) return { lng: g.coordinates[0], lat: g.coordinates[1] };
  if (g.type === "MultiPoint" && Array.isArray(g.coordinates?.[0])) return { lng: g.coordinates[0][0], lat: g.coordinates[0][1] };
  if (g.type === "LineString" && Array.isArray(g.coordinates?.[0])) {
    const mid = g.coordinates[Math.floor(g.coordinates.length / 2)];
    return { lng: mid[0], lat: mid[1] };
  }
  return null;
};

const vectorSourceIds = (map: any): string[] => {
  try {
    const sources = map.getStyle?.()?.sources ?? {};
    return Object.keys(sources).filter((id) => sources[id]?.type === "vector");
  } catch { return []; }
};

const sourceFeatures = (map: any, sourceLayer: string): any[] => {
  const out: any[] = [];
  for (const id of vectorSourceIds(map)) {
    try { out.push(...(map.querySourceFeatures?.(id, { sourceLayer }) ?? [])); }
    catch { /* a source may be mid-reload during a style change */ }
  }
  return out;
};

const nearest = (features: any[], at: LngLat, accept: (cls: string) => boolean) => {
  let best: { name: string; distanceKm: number; cls: string } | null = null;
  for (const feature of features) {
    const name = nameOf(feature?.properties);
    const where = pointOf(feature);
    if (!name || !where) continue;
    const cls = String(feature.properties?.class ?? feature.properties?.type ?? "").toLowerCase();
    if (!accept(cls)) continue;
    const distanceKm = kmBetween(at, where);
    if (!best || distanceKm < best.distanceKm) best = { name, distanceKm, cls };
  }
  return best;
};

const isOnWater = (map: any, at: LngLat): boolean | undefined => {
  try {
    const point = map.project([at.lng, at.lat]);
    const hits = map.queryRenderedFeatures?.(point) ?? [];
    if (!hits.length) return undefined;
    return hits.some((f: any) => String(f?.sourceLayer ?? f?.layer?.["source-layer"] ?? "") === "water");
  } catch { return undefined; }
};

/** Describe a point from loaded basemap data only. Returns {} when nothing is known. */
export function describePoint(map: any, lng: number, lat: number): PointDescription {
  if (!map?.querySourceFeatures) return {};
  const at = { lng, lat };
  const zoom = Number(map.getZoom?.() ?? 3);
  const radius = nameRadiusKm(zoom);
  const result: PointDescription = {};

  const onWater = isOnWater(map, at);
  if (onWater !== undefined) result.onWater = onWater;

  const places = sourceFeatures(map, "place");
  const local = nearest(places, at, (cls) => LOCAL_CLASSES.has(cls));
  if (local && local.distanceKm <= radius) {
    result.name = local.name; result.distanceKm = local.distanceKm; result.placeClass = local.cls;
  } else if (!onWater) {
    // No settlement in range: a region label is a fair answer only when the view
    // is wide enough that the user is plainly asking about a region.
    const region = zoom < 6 ? nearest(places, at, (cls) => REGION_CLASSES.has(cls)) : null;
    if (region && region.distanceKm <= radius * 1.5) {
      result.name = region.name; result.distanceKm = region.distanceKm; result.placeClass = region.cls;
    }
  }

  if (onWater) {
    const water = nearest(sourceFeatures(map, "water_name"), at, () => true);
    if (water && water.distanceKm <= Math.max(radius * 2, 400)) {
      result.waterName = water.name; result.waterDistanceKm = water.distanceKm;
    }
  }
  return result;
}

/** One human line for the header. Never claims membership; says "near" when it is near. */
export function pointTitle(d: PointDescription): string {
  if (d.onWater) {
    if (d.waterName) return d.waterName;
    if (d.name && (d.distanceKm ?? 0) <= 25) return `Sea near ${d.name}`;
    return "Open water";
  }
  if (d.name) {
    const km = d.distanceKm ?? 0;
    if (REGION_CLASSES.has(d.placeClass ?? "")) return d.name;
    return km <= 2 ? d.name : `Near ${d.name}`;
  }
  return "This point";
}

export interface LoadedPlaceHit {
  name: string;
  placeClass: string;
  lng: number;
  lat: number;
}

/**
 * Place names that match a query among the basemap tiles ALREADY loaded.
 * This is not a geocoder and never claims to be: it sees only the part of the
 * world the map is currently showing, at the detail of the current zoom. The
 * caller labels the group accordingly. No request is made.
 */
export function searchLoadedPlaces(map: any, query: string, limit = 5): LoadedPlaceHit[] {
  const q = String(query || "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  if (q.length < 3 || !map?.querySourceFeatures) return [];
  const rank: Record<string, number> = { city: 0, town: 1, island: 2, village: 3, suburb: 4, hamlet: 5 };
  const seen = new Set<string>();
  const hits: Array<LoadedPlaceHit & { score: number }> = [];
  for (const feature of sourceFeatures(map, "place")) {
    const name = nameOf(feature?.properties);
    const where = pointOf(feature);
    if (!name || !where) continue;
    const cls = String(feature.properties?.class ?? "").toLowerCase();
    if (!(cls in rank)) continue;
    const plain = name.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
    const match = plain === q ? 0 : plain.startsWith(q) ? 1 : -1;
    if (match < 0) continue;
    const key = `${plain}|${where.lng.toFixed(1)}|${where.lat.toFixed(1)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    hits.push({ name, placeClass: cls, lng: where.lng, lat: where.lat, score: match * 10 + rank[cls] });
  }
  return hits.sort((a, b) => a.score - b.score || a.name.localeCompare(b.name)).slice(0, limit)
    .map(({ score: _score, ...hit }) => hit);
}
