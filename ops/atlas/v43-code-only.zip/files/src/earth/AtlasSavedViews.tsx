import { useEffect, useRef, useState } from "react";
import { addCurrentAtlasView, readAtlasSavedViews, removeAtlasView, writeAtlasSavedViews } from "@/planet/atlasViews";
import { getFollows, replaceFollows } from "@/planet/follow";
import type { Follow } from "@/planet/types";
import { getIdentityClient, hasStoredIdentitySession, identityAccountUrl, identityLoginUrl, type FourPlanetSession } from "@/identity/identityClient";
import { readAtlasAccountState, writeAtlasAccountState } from "./atlasAccountState";
import AtlasTimeControls from "./AtlasTimeControls";
import AtlasZoomStack from "./AtlasZoomStack";
import { installAtlasLeadingExtensions } from "./atlasLeadingExtensions";
import "./atlas-leading.css";

// Install selectively recovered donor layers before the lazy World runtime reads
// the shared registry. One canonical ATLAS engine remains authoritative.
installAtlasLeadingExtensions();

function mergeFollows(local: Follow[], remote: Follow[]) {
  const rows = new Map<string, Follow>();
  for (const item of [...remote, ...local]) {
    if (!item?.id) continue;
    const current = rows.get(item.id);
    const currentAt = current?.addedAt ? Date.parse(current.addedAt) : 0;
    const nextAt = item.addedAt ? Date.parse(item.addedAt) : 0;
    if (!current || nextAt >= currentAt) rows.set(item.id, item);
  }
  return [...rows.values()]
    .sort((a, b) => Date.parse(b.addedAt || "1970-01-01") - Date.parse(a.addedAt || "1970-01-01"))
    .slice(0, 200);
}

function mergeViews(local: ReturnType<typeof readAtlasSavedViews>["views"], remote: ReturnType<typeof readAtlasSavedViews>["views"]) {
  const rows = new Map<string, (typeof local)[number]>();
  for (const item of [...remote, ...local]) {
    if (!item?.href) continue;
    const current = rows.get(item.href);
    const currentAt = current?.savedAt ? Date.parse(current.savedAt) : 0;
    const nextAt = item.savedAt ? Date.parse(item.savedAt) : 0;
    if (!current || nextAt >= currentAt) rows.set(item.href, item);
  }
  return [...rows.values()]
    .sort((a, b) => Date.parse(b.savedAt || "1970-01-01") - Date.parse(a.savedAt || "1970-01-01"))
    .slice(0, 30);
}

export function AtlasSavedViews() {
  const [state, setState] = useState(readAtlasSavedViews);
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [session, setSession] = useState<FourPlanetSession | null>(null);
  const [syncState, setSyncState] = useState<"LOCAL" | "SYNCING" | "SYNCED" | "OFFLINE">("LOCAL");
  const sessionRef = useRef<FourPlanetSession | null>(null);
  const hydrating = useRef(false);
  const syncTimer = useRef<number | null>(null);

  useEffect(() => {
    let alive = true;
    let unsubscribe = () => {};
    (async () => {
      // Anonymous visitors never load the auth SDK. A stored session (from an
      // earlier sign-in here, or one carried across from another 4PLANET site)
      // is picked up and kept fresh.
      if (!hasStoredIdentitySession()) return;
      try {
        const client = await getIdentityClient();
        const current = await client.auth.getSession();
        if (!alive) return;
        sessionRef.current = current.data.session;
        setSession(current.data.session);
        const listener = client.auth.onAuthStateChange((_event, next) => {
          if (!alive) return;
          sessionRef.current = next;
          setSession(next);
          setSyncState(next ? "SYNCING" : "LOCAL");
        });
        unsubscribe = () => listener.data.subscription.unsubscribe();
      } catch {
        if (alive) setSyncState("OFFLINE");
      }
    })();
    return () => {
      alive = false;
      unsubscribe();
      if (syncTimer.current) window.clearTimeout(syncTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    hydrating.current = true;
    setSyncState("SYNCING");
    (async () => {
      try {
        const remote = await readAtlasAccountState(session);
        if (cancelled) return;
        const mergedFollows = mergeFollows(getFollows(), remote?.follows || []);
        const mergedViews = mergeViews(readAtlasSavedViews().views, remote?.savedViews || []);
        replaceFollows(mergedFollows);
        writeAtlasSavedViews({ version: 1, views: mergedViews });
        setState({ version: 1, views: mergedViews });
        await writeAtlasAccountState(session, { follows: mergedFollows, savedViews: mergedViews });
        if (!cancelled) setSyncState("SYNCED");
      } catch {
        if (!cancelled) setSyncState("OFFLINE");
      } finally {
        hydrating.current = false;
      }
    })();
    return () => { cancelled = true; };
  }, [session?.user.id]);

  useEffect(() => {
    const closeForOtherSurface = (event: Event) => {
      const detail = (event as CustomEvent<string>).detail;
      if (detail && detail !== "MY_ATLAS") setOpen(false);
    };
    // The ATLAS dock owns the My Atlas door. It asks; this component still owns
    // the state, the data and the sync — one authority, no duplicate control.
    const toggleFromDock = () => setOpen((value) => !value);
    window.addEventListener("4p:atlas-surface-open", closeForOtherSurface as EventListener);
    window.addEventListener("4p:atlas-my-atlas-toggle", toggleFromDock);
    return () => {
      window.removeEventListener("4p:atlas-surface-open", closeForOtherSurface as EventListener);
      window.removeEventListener("4p:atlas-my-atlas-toggle", toggleFromDock);
    };
  }, []);

  // Announce open/close as an effect, never inside a state updater, so the dock
  // and the other surfaces hear exactly one event per real change.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent(open ? "4p:atlas-surface-open" : "4p:atlas-my-atlas-closed", open ? { detail: "MY_ATLAS" } : undefined));
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    const scheduleSync = () => {
      setState(readAtlasSavedViews());
      const active = sessionRef.current;
      if (!active || hydrating.current) return;
      if (syncTimer.current) window.clearTimeout(syncTimer.current);
      setSyncState("SYNCING");
      syncTimer.current = window.setTimeout(async () => {
        try {
          await writeAtlasAccountState(active, {
            follows: getFollows(),
            savedViews: readAtlasSavedViews().views,
          });
          setSyncState("SYNCED");
        } catch {
          setSyncState("OFFLINE");
        }
      }, 700);
    };
    window.addEventListener("4p:follows", scheduleSync);
    window.addEventListener("4p:atlas-views", scheduleSync);
    window.addEventListener("storage", scheduleSync);
    return () => {
      window.removeEventListener("4p:follows", scheduleSync);
      window.removeEventListener("4p:atlas-views", scheduleSync);
      window.removeEventListener("storage", scheduleSync);
    };
  }, []);

  const save = () => setState((current) => addCurrentAtlasView(current));
  const remove = (id: string) => setState((current) => removeAtlasView(current, id));

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: "4PLANET ATLAS", url });
        return;
      }
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch (error: any) {
      if (error?.name === "AbortError") return;
      try {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1800);
      } catch { /* sharing is optional; never block ATLAS */ }
    }
  };

  const follows = getFollows();
  const syncLine = !session
    ? ""
    : syncState === "SYNCED" ? "Saved to your 4PLANET ID"
    : syncState === "SYNCING" ? "Saving…"
    : "Kept on this device · will retry";

  return (
    <>
      <aside className={`atlas-saved-views ${open ? "open" : ""}`} aria-label="My Atlas" aria-hidden={!open}>
        {open && (
          <div className="atlas-saved-body">
            <header className="atlas-saved-head">
              <div>
                <div className="atlas-saved-kicker">{session ? "Saved with 4PLANET ID" : "Saved on this device"}</div>
                <h2>My Atlas</h2>
              </div>
              <button type="button" className="atlas-saved-close" onClick={() => setOpen(false)} aria-label="Close My Atlas">
                <span aria-hidden="true">×</span>
              </button>
            </header>

            <div className="atlas-saved-actions">
              <button type="button" onClick={save} className="atlas-action atlas-action-primary">
                Save this view
              </button>
              <button type="button" onClick={share} className="atlas-action">
                {copied ? "Link copied" : "Share this view"}
              </button>
            </div>

            <section className="atlas-saved-section">
              <h3>Saved views{state.views.length ? ` · ${state.views.length}` : ""}</h3>
              {state.views.length === 0 ? (
                <p className="atlas-saved-empty">
                  Save a view of the map to come back to it. Nothing is uploaded or shared unless you
                  choose to share a link.
                </p>
              ) : (
                <div className="atlas-saved-list">
                  {state.views.map((view) => (
                    <div key={view.id} className="atlas-saved-row">
                      <button type="button" onClick={() => window.location.assign(view.href)} title={view.href} className="atlas-saved-open">
                        <span>{view.label}</span>
                        <small>{view.savedAt ? new Date(view.savedAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" }) : "Saved"}</small>
                      </button>
                      <button type="button" aria-label={`Delete ${view.label}`} onClick={() => remove(view.id)} className="atlas-saved-delete">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="atlas-saved-section">
              <h3>Following{follows.length ? ` · ${follows.length}` : ""}</h3>
              <p className="atlas-saved-empty">
                {follows.length
                  ? "Species, places and living systems you follow are in Watch, with what the sources report about them."
                  : "Open a species, a place or a living system and choose Follow. It then appears in Watch."}
              </p>
            </section>

            <section className="atlas-saved-section atlas-saved-account">
              <p className="atlas-saved-sync">
                {session
                  ? <>{syncLine}<br /><span>{session.user.email || "4PLANET ID"}</span></>
                  : "Everything here works without an account. Sign in only if you want it on your other devices — already signed in on another 4PLANET site? One tap brings it here."}
              </p>
              <button
                type="button"
                className="atlas-account-action"
                onClick={() => window.location.assign(session ? identityAccountUrl(window.location.href) : identityLoginUrl(window.location.href))}
              >
                {session ? "4PLANET ID account" : "Sign in with 4PLANET ID"}
              </button>
            </section>
          </div>
        )}
      </aside>

      <AtlasTimeControls />
      <AtlasZoomStack />
    </>
  );
}
