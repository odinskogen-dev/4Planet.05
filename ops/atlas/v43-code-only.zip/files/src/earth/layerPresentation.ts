/* ═══════════════════════════════════════════════════════════════════════════
   4PLANET_ — ATLAS — LAYER PRESENTATION
   ───────────────────────────────────────────────────────────────────────────
   The layer registry (layers.ts + atlasLeadingExtensions.ts) is the technical
   truth: ids, tiles, sources, notes, legends. This file adds only what a person
   needs before they need any of that — a plain name, one line on what they are
   looking at, where it belongs, and which KIND OF TIME the picture represents.

   It owns no data and creates no second registry: every entry is keyed by an
   existing layer id, and an id without an entry falls back to the registry
   label. Source authority, legend, opacity and limitation stay in the registry
   and are shown at detail depth.

   TIME CLASSES (ATLAS canon). "LIVE" is reserved for a source that is genuinely
   live; a successful request does not make a record live.
   ═══════════════════════════════════════════════════════════════════════════ */

export type LayerTime =
  | "LIVE" | "OBSERVED" | "ANALYSIS" | "FORECAST" | "HISTORICAL"
  | "CLIMATOLOGY" | "COMPOSITE" | "CALCULATED" | "PLANNED";

export type LayerCategory = "Planet" | "Ocean" | "Land" | "Life" | "Air and climate" | "Sapiens" | "Events";

export interface LayerPresentation {
  /** Plain-language name. */
  name: string;
  /** One line: what the person is looking at. */
  what: string;
  category: LayerCategory;
  time: LayerTime;
  /** How current the picture is, in words. */
  when: string;
}

/** Display order of sections in the Layers sheet. */
export const LAYER_CATEGORIES: LayerCategory[] = [
  "Planet", "Ocean", "Land", "Life", "Air and climate", "Sapiens", "Events",
];

export const TIME_LABEL: Record<LayerTime, string> = {
  LIVE: "Live",
  OBSERVED: "Observed",
  ANALYSIS: "Analysis",
  FORECAST: "Forecast",
  HISTORICAL: "Historical",
  CLIMATOLOGY: "Typical conditions",
  COMPOSITE: "Composite",
  CALCULATED: "Calculated",
  PLANNED: "Not available yet",
};

const PRESENTATION: Record<string, LayerPresentation> = {
  bluemarble: { name: "Earth imagery", what: "A cloud-free picture of the whole planet", category: "Planet", time: "COMPOSITE", when: "A composite image, not a view of today" },
  truecolor: { name: "Satellite view by day", what: "What NASA's satellites saw on a chosen day", category: "Planet", time: "OBSERVED", when: "Daily. Dark wedges are areas not yet imaged" },
  shade: { name: "Day and night", what: "Where the sun is up right now", category: "Planet", time: "CALCULATED", when: "Calculated from the sun's position every minute" },
  iss: { name: "Space Station", what: "Where the International Space Station is now", category: "Planet", time: "LIVE", when: "Position refreshed every 5 seconds" },

  sst: { name: "Sea surface temperature", what: "How warm the surface of the ocean is", category: "Ocean", time: "ANALYSIS", when: "Daily analysis, about three days behind" },
  seaice: { name: "Sea ice", what: "Ice cover on the polar seas", category: "Ocean", time: "OBSERVED", when: "Daily, about two days behind" },
  coral: { name: "Coral heat stress", what: "Heat building up on coral reefs", category: "Ocean", time: "ANALYSIS", when: "Daily analysis, about two days behind" },
  "emodnet-bathymetry": { name: "Ocean depth", what: "The shape of the seabed in European seas", category: "Ocean", time: "HISTORICAL", when: "A survey compilation, not a current event" },
  "emodnet-seabed-habitats": { name: "Seabed habitats", what: "Predicted habitat types in European seas", category: "Ocean", time: "HISTORICAL", when: "A 2025 model, not direct observation" },
  "emodnet-dissolved-oxygen-climatology": { name: "Ocean oxygen", what: "Typical surface oxygen by month in European seas", category: "Ocean", time: "CLIMATOLOGY", when: "A long-term monthly average, not a current reading" },

  ndvi: { name: "Vegetation", what: "How green the land is", category: "Land", time: "OBSERVED", when: "Eight-day composite, about ten days behind" },
  forest: { name: "Forest loss", what: "Tree cover lost since 2001", category: "Land", time: "HISTORICAL", when: "Annual record, 2001 onwards" },
  fires: { name: "Active fires", what: "Heat detected by satellite — not always a wildfire", category: "Land", time: "OBSERVED", when: "Detections from the previous day" },
  protected: { name: "Protected areas", what: "Boundaries are not connected yet", category: "Land", time: "PLANNED", when: "Nothing is drawn rather than a guessed boundary" },

  biodiv: { name: "Where life has been recorded", what: "How many species records exist in each area", category: "Life", time: "HISTORICAL", when: "All records to date. Bright means well recorded, not most alive" },
  whales: { name: "Whales and dolphins", what: "Reported sightings and samples", category: "Life", time: "HISTORICAL", when: "Records of any date, not live positions" },
  species: { name: "Animal records", what: "A sample of reported vertebrate sightings", category: "Life", time: "HISTORICAL", when: "Records of any date. No dot does not mean no life" },

  aerosol: { name: "Smoke, dust and haze", what: "Particles hanging in the air", category: "Air and climate", time: "OBSERVED", when: "Daily, about two days behind" },
  precip: { name: "Rain and snow", what: "Precipitation measured from orbit", category: "Air and climate", time: "OBSERVED", when: "The previous day, not a live radar" },

  night: { name: "Night lights", what: "Human light seen from orbit", category: "Sapiens", time: "HISTORICAL", when: "A 2016 composite" },
  emissions: { name: "Emission sources", what: "Power, oil, gas and coal sites by reported emissions", category: "Sapiens", time: "HISTORICAL", when: "Annual estimates, not live plumes" },
  "emodnet-fishing-vessel-density": { name: "Fishing activity", what: "Where fishing vessels spend time in European seas", category: "Sapiens", time: "HISTORICAL", when: "2023 annual average, not live fishing" },

  events: { name: "Natural events", what: "Wildfires, storms, volcanoes and ice tracked by NASA", category: "Events", time: "OBSERVED", when: "Events NASA currently lists as open" },
  quakes: { name: "Earthquakes", what: "Earthquakes recorded in the past 24 hours", category: "Events", time: "OBSERVED", when: "Updated through the day" },
};

const sentenceCase = (label: string) => {
  const clean = String(label || "").replace(/\s*·\s*/g, " · ").replace(/_/g, " ").trim().toLowerCase();
  return clean.charAt(0).toUpperCase() + clean.slice(1);
};

/** Presentation for any registry layer. Never throws; never invents a source. */
export function layerPresentation(layer: { id: string; label?: string; group?: string; kind?: string }): LayerPresentation {
  const known = PRESENTATION[layer.id];
  if (known) return known;
  return {
    name: sentenceCase(layer.label || layer.id),
    what: "",
    category: layer.group === "LIFE" ? "Life" : layer.group === "SIGNALS" ? "Events" : "Planet",
    time: layer.kind === "planned" ? "PLANNED" : "HISTORICAL",
    when: "",
  };
}

/**
 * Where a layer comes from, said as a person would look it up: the provider's
 * own name and its public home page. Shown first in every layer's detail, and
 * one tap from the legend chip, so a renamed layer ("Emission sources") always
 * leads back to its source ("Climate TRACE").
 */
const SOURCE_HOMES: Array<[RegExp, string, string]> = [
  [/climate trace/i, "Climate TRACE", "https://climatetrace.org/"],
  [/global forest watch|umd/i, "Global Forest Watch · University of Maryland", "https://www.globalforestwatch.org/"],
  [/coral reef watch/i, "NOAA Coral Reef Watch", "https://coralreefwatch.noaa.gov/"],
  [/protected planet|wdpa/i, "Protected Planet (WDPA)", "https://www.protectedplanet.net/"],
  [/eonet/i, "NASA EONET", "https://eonet.gsfc.nasa.gov/"],
  [/usgs/i, "USGS Earthquake Hazards Program", "https://earthquake.usgs.gov/earthquakes/feed/"],
  [/obis/i, "OBIS — Ocean Biodiversity Information System", "https://obis.org/"],
  [/gbif/i, "GBIF — Global Biodiversity Information Facility", "https://www.gbif.org/"],
  [/emodnet/i, "EMODnet — European Marine Observation and Data Network", "https://emodnet.ec.europa.eu/"],
  [/wheretheiss/i, "Where the ISS at?", "https://wheretheiss.at/"],
  [/gibs|nasa/i, "NASA GIBS — Global Imagery Browse Services", "https://nasa-gibs.github.io/gibs-api-docs/"],
];

export function layerSource(src: string | undefined): { name: string; detail: string; url?: string } {
  const raw = String(src || "").trim();
  if (!raw || /^computed$/i.test(raw)) return { name: "Calculated by 4PLANET", detail: raw && raw !== "Computed" ? raw : "" };
  const hit = SOURCE_HOMES.find(([re]) => re.test(raw));
  return hit ? { name: hit[1], detail: raw, url: hit[2] } : { name: raw, detail: "" };
}

/** Human status for a layer row. Source failure is never rendered as empty. */
export function layerStatusText(raw: string | undefined, kind?: string): string {
  const value = String(raw || "").trim();
  if (!value) return "";
  if (value === "UNAVAILABLE") return "Unavailable right now";
  if (value === "OFFLINE") return "Source did not respond";
  if (value === "PLANNED") return "Not available yet";
  if (/^·+$/.test(value.replace(/\s/g, ""))) return "Loading…";
  if (value === "ON" || value === "LIVE") return "";
  const count = /^(\d+)\s*·/.exec(value);
  if (count && kind !== "raster") return `${Number(count[1]).toLocaleString("en-GB")} on the map`;
  return "";
}
