import { useSyncExternalStore } from "react";

/**
 * ATLAS has two complete themes, chosen with the map (Founder decision 08 Oct 2026):
 *
 *   dark  — Ink surfaces on the dark planet; the accent is E4RTH green (#3AE86F),
 *           also used for the 4PLANET wordmark.
 *   light — Paper surfaces on the light map; the accent is 4PLANET Blue (#2E2EFF).
 *
 * World owns the choice (it is part of the shareable view, `t=light`). It is
 * published here once so the surfaces World does not render — the product
 * switcher, My Atlas, Time, record evidence — follow the same theme without
 * observing the DOM. CSS reads `html[data-atlas-theme]`.
 */
export type AtlasTheme = "dark" | "light";

let current: AtlasTheme = "dark";
const listeners = new Set<() => void>();

export function setAtlasTheme(theme: AtlasTheme | null) {
  if (typeof document !== "undefined") {
    if (theme) document.documentElement.dataset.atlasTheme = theme;
    else delete document.documentElement.dataset.atlasTheme;
  }
  const next = theme ?? "dark";
  if (next === current) return;
  current = next;
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

export function useAtlasTheme(): AtlasTheme {
  return useSyncExternalStore(subscribe, () => current, () => "dark");
}
