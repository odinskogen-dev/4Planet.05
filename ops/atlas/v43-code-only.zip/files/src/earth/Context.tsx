/* ═══════════════════════════════════════════════════════════════════════════
   4PLANET_ — EARTH — SHARED CONTEXT LAYER
   ───────────────────────────────────────────────────────────────────────────
   Mandate: "OPEN THE SAME WORLD DEEPER. Do not create five unrelated drawers or
   five unrelated microsites."

   One component. Every canonical object opens here, in the same place, with the
   same grammar. The information hierarchy changes per object; the container
   never does.

   READING ORDER (ATLAS R1 — Human Awe First)
   ─────────────────────────────────────────
       ORIENT → FEEL → UNDERSTAND → EXPLORE → VERIFY

   1. FIRST READ  what this is, in a person's words; what has been recorded
                  here; one obvious next step.
   2. MORE        relationships, pressures, events — opened on request.
   3. SOURCES AND LIMITS  the exact source, query geometry, counts, identifiers,
                  retrieval time and every caveat. Always one tap away.

   THE RULE THAT STILL HOLDS EVERYWHERE BELOW

       NO SECTION RENDERS WITHOUT A STATUS.

   What changed is how a status is spoken, not whether it is:
     · A GAP (source failed, nothing returned, not checked, no coverage, bundled
       snapshot) is stated in words, inline, on the first read. Uncertainty is
       never moved out of sight.
     · A section that is simply sound carries its origin as a quiet caption
       ("From GBIF", "4PLANET editorial summary") instead of a badge, and its
       full provenance in SOURCES AND LIMITS.
   Hide complexity. Never hide uncertainty.
   ═══════════════════════════════════════════════════════════════════════════ */

import React from "react";
import { Link, useNavigate } from "react-router-dom";
import discovery from "@/data/discoveryInventory.json";
import { SPECIES_PROFILES } from "@/data/species";
import { withReturnTo } from "@/product/productContext";
import type {
  DataStatus,
  EntityId,
  EntityRef,
  Field,
  LivingSystem,
  Mission,
  Occurrence,
  ObservationItem,
  Place,
  Pressure,
  Relation,
  Signal,
  Solution,
} from "@/planet/types";
import {
  MISSIONS,
  PRESSURES,
  SOLUTIONS,
  directDependents,
  missionById,
  nodeById,
  pressureById,
  pressuresOn,
  primaryChain,
  solutionById,
  systemById,
  systemsContaining,
} from "@/planet/livingSystems";
import {
  CLASS_CAVEAT, CLASS_NAME, OBSERVATION_CAVEAT, signalHeadline, timeAgoHuman,
} from "@/planet/signals";
import { placeById } from "@/planet/places";
import { src } from "@/planet/sources";
import { authorityOf, sourceKeyOf, typeOf } from "@/planet/ids";
import type { AreaSpecies, TaxonPhoto } from "@/planet/connectors";
import { pointTitle, type PointDescription } from "./placeNames";
import { describeKnowledge, townLine, type PlaceContext, type PlaceKnowledge } from "./placeKnowledge";

/* ── palette by entity type (map markers and small identity dots only) ───── */
export const TYPE_COLOR: Record<string, string> = {
  TAXON: "#3AE86F",
  PLACE: "#2E2EFF",
  LIVING_SYSTEM: "#3CD6CE",
  SIGNAL: "#FF7D50",
  OBSERVATION: "#3AE86F",
  PRESSURE: "#FF4D22",
  SOLUTION: "#2E2EFF",
  MISSION: "#FFFFFF",
  COORDINATE: "#FFFFFF",
  LEGACY_POINT: "#8A94A6",
  FUNCTION: "#3CD6CE",
  HUMAN_SYSTEM: "#FF4D22",
};

/** Plain-language kind, shown as the eyebrow above every title. */
const KIND_LABEL: Record<string, string> = {
  TAXON: "Species",
  PLACE: "Place",
  LIVING_SYSTEM: "Living system",
  SIGNAL: "Reported event",
  OBSERVATION: "Observation record",
  PRESSURE: "Pressure",
  SOLUTION: "Solution pathway",
  MISSION: "4PLANET mission",
  COORDINATE: "Here",
  LEGACY_POINT: "Map record",
  FUNCTION: "Ecological function",
  HUMAN_SYSTEM: "Human system",
};

const PLACE_KIND: Record<Place["kind"], string> = {
  CITY: "City",
  REGION: "Region",
  MARINE_AREA: "Marine area",
  FOREST: "Forest",
  PROTECTED_AREA: "Protected area",
  COUNTRY: "Country",
};

/* ── context state ───────────────────────────────────────────────────────── */

export type AreaSpeciesField = Field<{ species: AreaSpecies[]; total: number }>;

export type ContextState =
  | {
      kind: "TAXON";
      ref: EntityRef;
      photo: TaxonPhoto | null;
      occ: Field<{ rows: Occurrence[]; total: number }>;
    }
  | {
      kind: "PLACE";
      place: Place;
      life: Field<{ total: number; names: string[] }>;
      /** Most-recorded species in the query area, with common names. */
      species: AreaSpeciesField;
      signals: Field<Array<Signal & { distanceKm: number }>>;
    }
  | { kind: "LIVING_SYSTEM"; system: LivingSystem }
  | { kind: "SIGNAL"; signal: Signal }
  | { kind: "OBSERVATION"; observation: ObservationItem }
  | { kind: "PRESSURE"; pressure: Pressure }
  | { kind: "SOLUTION"; solution: Solution }
  | { kind: "MISSION"; mission: Mission }
  | {
      kind: "COORDINATE";
      lat: number;
      lng: number;
      /** Nearest basemap label and water context, read from loaded tiles only. */
      where?: PointDescription;
      /** @deprecated kept for older callers; `where` is the authority. */
      placeName?: string;
      /** The name the visitor searched for, when they arrived from search. */
      label?: { name: string; kind: string; wikidata?: string };
      /** Open geography for the point (GeoNames + Natural Earth), see placeKnowledge.ts. */
      known?: { status: "LOADING" | "OK" | "UNAVAILABLE"; value?: PlaceKnowledge };
      /** Ecoregion and Wikipedia lead from /api/atlas-place; null while loading. */
      context?: PlaceContext | null;
      life: Field<{ total: number; names: string[] }>;
      species: AreaSpeciesField;
      signals: Field<Array<Signal & { distanceKm: number }>>;
    }
  | {
      /**
       * V39.1 Scope 01 — a thin PRESENTATION envelope for a point from a legacy
       * V36 map layer that carries no canonical id. It routes that click into the
       * one Shared Context surface instead of a floating popup. It is display-only:
       * it does NOT create canonical identity, scientific meaning, evidence status
       * or place membership, and it says so plainly. No new domain record exists.
       */
      kind: "LEGACY_POINT";
      title: string;
      sub?: string;
      scientificName?: string;
      commonName?: string;
      observedDate?: string;
      lat: number;
      lng: number;
      sourceLabel: string;
      /** Source identity for the record (GBIF / OBIS / EONET / USGS / ISS). */
      sourceId?: string;
      /** Preserved source-rendered preview (parity with the old V36 popup). */
      previewHtml?: string;
      /** For source links only — not a canonical identity. */
      gbifKey?: string;
      aphiaId?: string;
      /** Classify planetary-context layers (ISS, seismic) explicitly. */
      planetaryContext?: boolean;
      accent?: string;
    };

/* ── status, spoken ──────────────────────────────────────────────────────── */

/** Short words for a status, used inline next to a section title when it is a gap. */
const STATUS_TEXT: Record<DataStatus, string> = {
  LIVE: "From the source",
  LOADING: "Loading…",
  NO_RECORDS: "No records returned",
  NOT_CHECKED: "Not checked",
  NO_COVERAGE: "No coverage yet",
  SOURCE_UNAVAILABLE: "Source unavailable",
  SEEDED: "4PLANET editorial",
  PLANNED: "Planned",
  BUNDLED: "Bundled · not live",
};

const STATUS_CLASS: Record<DataStatus, string> = {
  LIVE: "live",
  LOADING: "load",
  NO_RECORDS: "none",
  NOT_CHECKED: "none",
  NO_COVERAGE: "none",
  SOURCE_UNAVAILABLE: "bad",
  SEEDED: "seeded",
  PLANNED: "none",
  BUNDLED: "none",
};

/** Statuses that describe a gap. These are always visible on the first read. */
const GAP: ReadonlySet<DataStatus> = new Set<DataStatus>([
  "NO_RECORDS", "NOT_CHECKED", "NO_COVERAGE", "SOURCE_UNAVAILABLE", "PLANNED", "BUNDLED",
]);

/**
 * The sentence a person gets when a section is not sound.
 * Brief §29: "NO RECORDS ≠ ENTITY ABSENT. NOT CHECKED ≠ ZERO."
 * These strings are the product's whole credibility. Do not soften them.
 */
const STATUS_MEANING: Partial<Record<DataStatus, string>> = {
  NO_RECORDS:
    "The source answered and held nothing for this query. That is a statement about the records, not about the world.",
  NOT_CHECKED:
    "4PLANET did not ask. No connector for this question is wired yet. Do not read this as zero.",
  NO_COVERAGE:
    "No source in the system currently covers this question. Absence here is our gap, not the planet's.",
  SOURCE_UNAVAILABLE: "The source did not respond. We are showing nothing rather than guessing.",
  SEEDED:
    "4PLANET prototype content. This is our reasoning, not a source record, and it has not been reviewed by a domain expert.",
  PLANNED: "Designed, not yet built.",
  BUNDLED:
    "A real source record shipped with the app as a checked historical snapshot. It is not a live read and not the animal's current position.",
};

export const Stat = ({ s, label }: { s: DataStatus; label?: string }) => (
  <span className={`stat ${STATUS_CLASS[s]}`} data-status={s}>{label || STATUS_TEXT[s]}</span>
);

/**
 * A titled block. Its status is ALWAYS present:
 *   gap     → words next to the title + the meaning sentence in the body;
 *   loading → a quiet "Loading…";
 *   sound   → an origin caption at the foot (`origin`, or the default for the
 *             status), so no content is ever unmarked.
 */
const Section: React.FC<{
  title: string;
  status: DataStatus;
  children?: React.ReactNode;
  statusLabel?: string;
  /** Replace the default meaning sentence (pass " " to suppress when the body says it). */
  note?: string;
  /** Quiet origin caption for a sound section, e.g. "From GBIF". */
  origin?: React.ReactNode;
}> = ({ title, status, children, statusLabel, note, origin }) => {
  const gap = GAP.has(status);
  const meaning = (note ?? (gap ? STATUS_MEANING[status] : undefined))?.trim();
  const caption = origin ?? (status === "SEEDED" ? "4PLANET editorial — not a source record, not expert-reviewed." : undefined);
  return (
    <section className="sec" data-status={status}>
      <div className="sec-h">
        <h3>{title}</h3>
        {(gap || status === "LOADING") && <Stat s={status} label={statusLabel} />}
      </div>
      <div className="sec-body">
        {status === "LIVE" || status === "SEEDED" || status === "BUNDLED" ? children : null}
        {status === "LOADING" && <div className="skeleton" aria-hidden="true"><i /><i /><i /></div>}
        {meaning && <p className="note-box">{meaning}</p>}
        {!gap && status !== "LOADING" && caption && <p className="origin">{caption}</p>}
      </div>
    </section>
  );
};

const Source: React.FC<{ ids: string[] }> = ({ ids }) => (
  <div className="src-line">
    Source ·{" "}
    {ids.map((id, i) => {
      const s = src(id);
      return (
        <React.Fragment key={id}>
          {i > 0 && " · "}
          {s.home.startsWith("http") ? (
            <a href={s.home} target="_blank" rel="noopener noreferrer">
              {s.attribution}
            </a>
          ) : (
            s.attribution
          )}
        </React.Fragment>
      );
    })}
  </div>
);

/** SOURCES AND LIMITS — everything exact, one tap away, on every object. */
const Evidence: React.FC<{ children: React.ReactNode; label?: string }> = ({ children, label }) => (
  <details className="evidence">
    <summary>{label ?? "Sources and limits"}</summary>
    <div className="evidence-body">{children}</div>
  </details>
);

/** One line of "at a glance" geography: a quiet label and its value. */
const Glance: React.FC<{ k: string; v: string }> = ({ k, v }) => (
  <div className="glance-row"><span>{k}</span><strong>{v}</strong></div>
);

const Fact: React.FC<{ k: string; children: React.ReactNode; mono?: boolean }> = ({ k, children, mono }) => (
  <div className="hrow">
    <span>{k}</span>
    <span className={mono ? "mono" : undefined}>{children}</span>
  </div>
);

const coord = (lat: number, lng: number, digits = 3) =>
  `${Math.abs(lat).toFixed(digits)}°${lat >= 0 ? "N" : "S"} ${Math.abs(lng).toFixed(digits)}°${lng >= 0 ? "E" : "W"}`;

/* ── evidence envelope on a seeded relationship (Brief §25) ──────────────── */

const RelationEvidence: React.FC<{ r: Relation }> = ({ r }) => (
  <>
    <div className="ev">
      {/* V40 truth-axis correction: no generic CONFIDENCE badge. The canonical
          axes are Review Status (real here), Evidence Strength and Interpretation
          Status. The latter two have no assessed value on a seeded prototype
          relation, so they read NOT YET ASSESSED — never back-translated from the
          old confidence field. Origin is construction context, not a truth axis. */}
      <span>REVIEW · {r.reviewStatus.replace(/_/g, " ")}</span>
      <span>EVIDENCE STRENGTH · NOT YET ASSESSED</span>
      <span>INTERPRETATION · NOT YET ASSESSED</span>
      <span>ORIGIN · {r.origin.replace(/_/g, " ")}</span>
    </div>
    {r.evidence && <div className="ev-cite">{r.evidence}</div>}
  </>
);

/* ── the relationship chain ──────────────────────────────────────────────── */

const Chain: React.FC<{ rels: Relation[]; startId: EntityId; onOpen: (id: EntityId) => void }> = ({
  rels,
  startId,
  onOpen,
}) => {
  const ids = [startId, ...rels.map((r) => r.to)];
  return (
    <div className="chain">
      {ids.map((id, i) => {
        const n = nodeById(id);
        const rel = i > 0 ? rels[i - 1] : null;
        const last = i === ids.length - 1;
        const color = TYPE_COLOR[String(n?.type ?? typeOf(id))] ?? "#0A0A0A";
        return (
          <div
            key={id}
            className="chain-node"
            role="button"
            tabIndex={0}
            onClick={() => onOpen(id)}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpen(id); } }}
          >
            <div className="chain-rail" style={{ color }}>
              <span className="chain-dot" />
              {!last && <span className="chain-line" />}
            </div>
            <div className="chain-txt">
              <div className="chain-name">{n?.label ?? id}</div>
              <div className="chain-type">
                {KIND_LABEL[String(n?.type)] ?? String(n?.type ?? "")}
                {n?.sub ? ` · ${n.sub}` : ""}
              </div>
              {rel && <div className="chain-claim">{rel.claim}</div>}
              {rel && <RelationEvidence r={rel} />}
            </div>
          </div>
        );
      })}
    </div>
  );
};

/* ── list item ───────────────────────────────────────────────────────────── */

const Li: React.FC<{
  color?: string;
  name: string;
  sub?: React.ReactNode;
  why?: string;
  end?: string;
  onClick?: () => void;
}> = ({ color, name, sub, why, end, onClick }) => (
  <div
    className={`li ${onClick ? "tap" : ""}`}
    onClick={onClick}
    role={onClick ? "button" : undefined}
    tabIndex={onClick ? 0 : undefined}
    onKeyDown={
      onClick
        ? (e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onClick();
            }
          }
        : undefined
    }
  >
    {color && <span className="lidot" style={{ background: color }} />}
    <span className="limain">
      <span className="liname">{name}</span>
      {sub && <div className="lisub">{sub}</div>}
      {why && <div className="liwhy">{why}</div>}
    </span>
    {end && <span className="liend">{end}</span>}
  </div>
);

/* ── what has been recorded here ─────────────────────────────────────────── */

const records = (n: number) => `${n.toLocaleString("en-GB")} ${n === 1 ? "record" : "records"}`;

/**
 * The life preview shared by PLACE and HERE. It names species in the words a
 * person uses, and it is exact about what the list is: the species with the
 * most RECORDS in a QUERY AREA. Not a species list for the place, not abundance,
 * not presence today.
 */
const RecordedHere: React.FC<{
  title: string;
  species: AreaSpeciesField;
  take: number;
  caption: string;
  onOpen: (id: EntityId) => void;
}> = ({ title, species, take, caption, onOpen }) => {
  if (species.status === "SOURCE_UNAVAILABLE") {
    return (
      <Section
        title={title}
        status="SOURCE_UNAVAILABLE"
        note="Species records are unavailable right now. That is a connection problem, not an empty place."
      />
    );
  }
  if (species.status === "LIVE" && species.value && species.value.species.length === 0) {
    return <Section title={title} status="NO_RECORDS" />;
  }
  return (
    <Section title={title} status={species.status} origin={caption}>
      {species.value?.species.slice(0, take).map((s) => (
        <Li
          key={s.id}
          name={s.commonName || s.scientificName}
          sub={s.commonName ? <em>{s.scientificName}</em> : undefined}
          end={records(s.records)}
          onClick={() => onOpen(s.id)}
        />
      ))}
    </Section>
  );
};

/** Events near a place or point. Present on the first read only when there are some. */
const ReportedNearby: React.FC<{
  signals: Field<Array<Signal & { distanceKm: number }>>;
  take?: number;
  showDistance?: boolean;
  quietNote: string;
  onOpen: (id: EntityId) => void;
}> = ({ signals, take, showDistance, quietNote, onOpen }) => {
  const rows = signals.value ?? [];
  return (
    <Section
      title="Reported nearby"
      status={signals.status}
      note={signals.status === "NO_RECORDS" ? quietNote : undefined}
      origin={<>From NASA EONET and USGS. A record of an event, not an alert.</>}
    >
      {rows.slice(0, take ?? rows.length).map((s) => {
        const h = signalHeadline(s);
        return (
          <Li
            key={s.id}
            color={TYPE_COLOR.SIGNAL}
            name={h.title}
            sub={showDistance ? `${h.detail}${h.detail ? " · " : ""}${Math.round(s.distanceKm)} km away` : h.detail}
            end={timeAgoHuman(s.provenance.occurredAt)}
            onClick={() => onOpen(s.id)}
          />
        );
      })}
      {take && rows.length > take && <p className="origin">{rows.length - take} more under “More”.</p>}
    </Section>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   THE CONTEXT LAYER
   ═══════════════════════════════════════════════════════════════════════════ */

export interface ContextProps {
  ctx: ContextState;
  onClose: () => void;
  onOpen: (id: EntityId) => void;
  following: (id: string) => boolean;
  onFollow: (ref: EntityRef) => void;
  /** Tells the host that the reader asked for depth, so a sheet can grow. */
  onDepth?: (deep: boolean) => void;
}

const refOf = (ctx: ContextState): EntityRef | null => {
  switch (ctx.kind) {
    case "TAXON":
      return ctx.ref;
    case "PLACE":
      return { id: ctx.place.id, type: "PLACE", label: ctx.place.name, sub: ctx.place.kind };
    case "LIVING_SYSTEM":
      return {
        id: ctx.system.id,
        type: "LIVING_SYSTEM",
        label: ctx.system.name,
        sub: ctx.system.sub,
      };
    default:
      return null; // Brief §40/§51: v1 Follow targets are TAXON, PLACE, LIVING SYSTEM. Only.
  }
};

type InventoryPlace = (typeof discovery.places)[number];
const inventoryPlace = (placeId: string): InventoryPlace | undefined =>
  discovery.places.find((item) => item.placeId === placeId && item.indexable === true);

/** First sentence of a seeded blurb: the human line. The rest is scope caveat. */
const splitBlurb = (blurb?: string): { lead: string; rest: string } => {
  const text = String(blurb ?? "").trim();
  const cut = text.search(/[.!?](\s|$)/);
  if (cut < 0) return { lead: text, rest: "" };
  return { lead: text.slice(0, cut + 1), rest: text.slice(cut + 1).trim() };
};

export const ContextLayer: React.FC<ContextProps> = ({
  ctx,
  onClose,
  onOpen,
  following,
  onFollow,
  onDepth,
}) => {
  const navigate = useNavigate();
  const color = TYPE_COLOR[ctx.kind] ?? "#0A0A0A";
  const ref = refOf(ctx);
  const isOn = ref ? following(ref.id) : false;

  /* ── PROGRESSIVE CONTEXT ──────────────────────────────────────────────────
     Two reading depths plus an always-available evidence block. This is
     progressive DISCLOSURE, not removal: every section still exists, a gap is
     never hidden, and one tap reveals the next depth. */
  const [more, setMoreState] = React.useState(false);
  const setMore = (next: boolean) => { setMoreState(next); onDepth?.(next); };
  // Reset to the first read whenever the object being viewed changes identity.
  const identity =
    ref?.id ??
    (ctx.kind === "COORDINATE" ? `coord:${ctx.lat},${ctx.lng}` :
     ctx.kind === "OBSERVATION" ? ctx.observation.id :
     ctx.kind === "SIGNAL" ? ctx.signal.id : ctx.kind);
  React.useEffect(() => { setMoreState(false); }, [identity]);

  const head = (title: string, sub?: React.ReactNode, eyebrow?: string) => (
    <header className="ctx-head">
      <div className="ctx-kind" data-kind={ctx.kind}>{eyebrow ?? KIND_LABEL[ctx.kind]}</div>
      <h2 className="ctx-title">{title}</h2>
      {sub && <div className="ctx-sub">{sub}</div>}
      <button className="ctx-close" onClick={onClose} aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </header>
  );

  const followBtn = () =>
    ref ? (
      <button
        className={`follow-btn ${isOn ? "on" : ""}`}
        aria-pressed={isOn}
        onClick={() => onFollow(ref)}
      >
        <span>{isOn ? "Following" : "Follow"}</span>
      </button>
    ) : null;

  const moreBtn = (label: string) => (
    <button className="tier-btn" aria-expanded={more} onClick={() => setMore(!more)}>
      {more ? "Show less" : label}
    </button>
  );

  /* ── TAXON ─────────────────────────────────────────────────────────────── */
  if (ctx.kind === "TAXON") {
    const { ref: r, photo, occ } = ctx;
    const systems = systemsContaining(r.id);
    const performs = directDependents(r.id);
    const pressures = pressuresOn(r.id);
    const chain = primaryChain(r.id);
    const gbifKey = authorityOf(r.id) === "gbif" ? sourceKeyOf(r.id) : "";
    const profile = SPECIES_PROFILES.find((s) => s.id === r.id || (gbifKey && String(s.gbifKey) === String(gbifKey)));
    const hasMore = chain.length > 0 || systems.length > 0 || pressures.length > 0 || performs.length === 0;
    const scientific = r.sub && r.sub !== r.label ? <em>{r.sub}</em> : undefined;

    return (
      <aside className="ctx" aria-label={`${r.label} — species`}>
        {head(r.label, scientific)}
        <div className="ctx-body">
          {photo && (
            <figure className="ctx-figure">
              <img className="ctx-hero" src={photo.url} alt={`${r.label} — a photograph of the species, not of a record on this map`} />
              <figcaption className="src-line">Photo · {photo.attribution}{photo.licence ? ` · ${photo.licence}` : ""}</figcaption>
            </figure>
          )}

          {occ.status === "LIVE" && occ.value ? (
            <p className="lead-fact" data-status="LIVE">
              Recorded <strong>{occ.value.total.toLocaleString("en-GB")}</strong> times ·{" "}
              {occ.value.rows.length.toLocaleString("en-GB")} on the map
            </p>
          ) : (
            <Section
              title="Where it has been recorded"
              status={occ.status}
              note={occ.status === "NOT_CHECKED" ? occ.note : undefined}
            />
          )}

          <div className="actions">
            {followBtn()}
            {hasMore && moreBtn("More about this species")}
          </div>
          {occ.status === "LIVE" && (
            <p className="origin">
              Records held by GBIF. Dots show where people looked and reported. Few dots mean few
              observers, not absent life. This is not a range map.
            </p>
          )}
          {profile && (
            <Link
              className="text-link"
              to={`/species/${profile.slug}?entity=${encodeURIComponent(profile.id)}`}
              onClick={(e) => {
                // Encode returnTo from the LIVE ATLAS url at click time, so the
                // post-interaction camera is the one that returns.
                e.preventDefault();
                navigate(withReturnTo(`/species/${profile.slug}?entity=${encodeURIComponent(profile.id)}`, window.location.search));
              }}
            >
              Open {profile.commonName} in SPECIES →
            </Link>
          )}

          {more && (
            <>
              {chain.length > 0 && (
                <Section title="Why it may matter" status="SEEDED">
                  <Chain rels={chain} startId={r.id} onOpen={onOpen} />
                </Section>
              )}

              {performs.length === 0 && chain.length === 0 && (
                <Section title="Role in the living system" status="NOT_CHECKED" />
              )}

              {systems.length > 0 && (
                <Section title="Living systems" status="SEEDED">
                  {systems.map((s) => (
                    <Li key={s.id} color={TYPE_COLOR.LIVING_SYSTEM} name={s.name} sub={s.sub} onClick={() => onOpen(s.id)} />
                  ))}
                </Section>
              )}

              {pressures.length > 0 && (
                <Section title="Pressures" status="SEEDED">
                  {pressures.map((p) => {
                    const pr = pressureById(p.from);
                    return (
                      <div key={p.id} className="stack">
                        <Li color={TYPE_COLOR.PRESSURE} name={pr?.name ?? p.from} why={p.claim} onClick={() => onOpen(p.from)} />
                        <RelationEvidence r={p} />
                      </div>
                    );
                  })}
                </Section>
              )}
            </>
          )}

          <Evidence>
            <Fact k="Identity" mono>{r.id}</Fact>
            {occ.value && <Fact k="Records held by GBIF">{occ.value.total.toLocaleString("en-GB")}</Fact>}
            {occ.value && <Fact k="Plotted on the map">{occ.value.rows.length.toLocaleString("en-GB")}</Fact>}
            <Fact k="Record status">{STATUS_TEXT[occ.status]}</Fact>
            {gbifKey && (
              <div className="src-line">
                <a href={`https://www.gbif.org/species/${gbifKey}`} target="_blank" rel="noopener noreferrer">See this species at GBIF ↗</a>
              </div>
            )}
            <Source ids={["gbif"]} />
            <p className="note-box">
              Occurrence records are reported observations. They are not range, abundance, population
              trend or live tracking, and a missing record is not proof of absence.
            </p>
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── PLACE ─────────────────────────────────────────────────────────────── */
  if (ctx.kind === "PLACE") {
    const { place, life, species, signals } = ctx;
    const systems = (place.livingSystemIds ?? []).map(systemById).filter(Boolean) as LivingSystem[];
    const pressures = (place.pressureIds ?? []).map(pressureById).filter(Boolean) as Pressure[];
    const published = inventoryPlace(place.id);
    const blurb = splitBlurb(place.blurb);
    const lead = published?.summary || blurb.lead;
    const marine = place.kind === "MARINE_AREA";
    const signalRows = signals.value ?? [];
    const queryCaveat =
      `Species records are the ones GBIF returned for a rectangular area around ${place.name} — not records verified as belonging to it. A bounding box is a box on a map, not the boundary of the place.` +
      (marine
        ? " Because this is a marine area, the box unavoidably includes nearby coastline, so land-dwelling species can appear here. They are inside the query area; they are not marine life."
        : place.kind === "CITY"
          ? " The box also covers land around the city, so this is the wider area, not the streets."
          : "") +
      " 4PLANET does not yet hold a real polygon for this place.";

    return (
      <aside className="ctx" aria-label={`${place.name} — place`}>
        {head(place.name, undefined, PLACE_KIND[place.kind])}
        <div className="ctx-body">
          {lead && <p className="lead">{lead}</p>}

          <div className="actions">
            {followBtn()}
            {moreBtn(`More about ${place.name}`)}
          </div>

          <RecordedHere
            title="Most recorded here"
            species={species}
            take={more ? 6 : 4}
            caption={`Species with the most records in the wider area around ${place.name}${marine ? ", which includes nearby coast" : ""}. Records show where people looked, not everything that lives here.`}
            onOpen={onOpen}
          />

          {(signalRows.length > 0 || signals.status === "SOURCE_UNAVAILABLE") && !more && (
            <ReportedNearby
              signals={signals}
              take={2}
              quietNote=""
              onOpen={onOpen}
            />
          )}

          {published && (
            <Link className="text-link" to={`/place/${published.slug}`}>Read the full place page →</Link>
          )}

          {more && (
            <>
              <ReportedNearby
                signals={signals}
                quietNote="No fire, natural event or seismic record from NASA EONET or USGS falls within range of this area right now. Those are the only event feeds 4PLANET currently reads. Quiet feeds are not a quiet planet."
                onOpen={onOpen}
              />

              {systems.length > 0 && (
                <Section title="Living systems here" status="SEEDED">
                  {systems.map((s) => (
                    <Li key={s.id} color={TYPE_COLOR.LIVING_SYSTEM} name={s.name} sub={s.sub} onClick={() => onOpen(s.id)} />
                  ))}
                </Section>
              )}

              {pressures.length > 0 && (
                <Section title="Pressures" status="SEEDED">
                  {pressures.map((p) => (
                    <Li key={p.id} color={TYPE_COLOR.PRESSURE} name={p.name} onClick={() => onOpen(p.id)} />
                  ))}
                </Section>
              )}

              {/* Brief §29: these sections exist precisely BECAUSE we cannot answer them. */}
              <Section title="Protected areas" status="NOT_CHECKED" />
              <Section title="Public decisions" status="NO_COVERAGE" />
            </>
          )}

          <Evidence>
            <Fact k="Centre" mono>{coord(place.lat, place.lng, 2)}</Fact>
            <Fact k="Identity" mono>{place.id}</Fact>
            <Fact k="Area queried">Bounding box</Fact>
            {life.value && <Fact k="Records returned for the area">{life.value.total.toLocaleString("en-GB")}</Fact>}
            {species.value && !life.value && <Fact k="Records returned for the area">{species.value.total.toLocaleString("en-GB")}</Fact>}
            {life.value && <Fact k="Distinct names in the mapped sample">{life.value.names.length}</Fact>}
            <Fact k="Species records">{STATUS_TEXT[species.status]}</Fact>
            <Fact k="Event feeds">{STATUS_TEXT[signals.status]}</Fact>
            <p className="note-box">{queryCaveat}</p>
            <p className="note-box">
              {published
                ? "The description is 4PLANET's published place summary, written from the sources below."
                : "The description is a 4PLANET editorial line. It is our reasoning, not a source record, and it has not been reviewed by a domain expert."}
              {blurb.rest ? ` ${blurb.rest}` : ""}
            </p>
            {published?.truthBoundary && <p className="note-box">{published.truthBoundary}</p>}
            {published?.sources?.length ? (
              <div className="src-line">
                Description sources ·{" "}
                {published.sources.map((s, i) => (
                  <React.Fragment key={s.url}>
                    {i > 0 && " · "}
                    <a href={s.url} target="_blank" rel="noopener noreferrer">{s.label}</a>
                  </React.Fragment>
                ))}
              </div>
            ) : null}
            <Source ids={["gbif", "eonet", "usgs"]} />
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── LIVING SYSTEM ─────────────────────────────────────────────────────── */
  if (ctx.kind === "LIVING_SYSTEM") {
    const { system } = ctx;
    const chain = primaryChain(system.chain[0]);
    const pressures = system.pressureIds.map(pressureById).filter(Boolean) as Pressure[];
    const places = (system.placeIds ?? []).map(placeById).filter(Boolean) as Place[];

    return (
      <aside className="ctx" aria-label={`${system.name} — living system`}>
        {head(system.name, system.sub)}
        <div className="ctx-body">
          <p className="lead">{system.body}</p>

          <div className="actions">
            {followBtn()}
            {moreBtn("How this system connects")}
          </div>

          {more && (
            <>
              {chain.length > 0 && (
                <Section title="What supports what" status="SEEDED">
                  <Chain rels={chain} startId={system.chain[0]} onOpen={onOpen} />
                </Section>
              )}

              {pressures.length > 0 && (
                <Section title="Pressures on this system" status="SEEDED">
                  {pressures.map((p) => (
                    <Li key={p.id} color={TYPE_COLOR.PRESSURE} name={p.name} why={p.body} onClick={() => onOpen(p.id)} />
                  ))}
                </Section>
              )}

              {places.length > 0 && (
                <Section title="Represented in" status="SEEDED">
                  {places.map((p) => (
                    <Li key={p.id} color={TYPE_COLOR.PLACE} name={p.name} sub={PLACE_KIND[p.kind]} onClick={() => onOpen(p.id)} />
                  ))}
                </Section>
              )}

              {system.anchorTaxa.length > 0 && (
                <Section title="Life in this system" status="SEEDED">
                  {system.anchorTaxa.map((t) => {
                    const n = nodeById(t);
                    return (
                      <Li key={t} color={TYPE_COLOR.TAXON} name={n?.label ?? t} sub={n?.sub ? <em>{n.sub}</em> : undefined} onClick={() => onOpen(t)} />
                    );
                  })}
                </Section>
              )}
            </>
          )}

          <Evidence>
            <Fact k="Identity" mono>{system.id}</Fact>
            <Fact k="Status">{STATUS_TEXT.SEEDED}</Fact>
            <p className="note-box">
              4PLANET prototype relationship model. The chain is a comprehensible path
              through a system that is really a network. It is not a claim that ecological
              causality is linear, and it has not been reviewed by a domain expert.
            </p>
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── SIGNAL ────────────────────────────────────────────────────────────── */
  if (ctx.kind === "SIGNAL") {
    const s = ctx.signal;
    const d = src(s.provenance.sourceId);
    const h = signalHeadline(s);
    return (
      <aside className="ctx" aria-label={`${h.title} — reported event`}>
        {head(h.title, h.detail || undefined, CLASS_NAME[s.cls])}
        <div className="ctx-body">
          <p className="lead-fact">
            Reported <strong>{timeAgoHuman(s.provenance.occurredAt)}</strong> by {d.name}.
          </p>
          <p className="note-box">{CLASS_CAVEAT[s.cls]}</p>

          {s.provenance.sourceUrl && (
            <a className="text-link" href={s.provenance.sourceUrl} target="_blank" rel="noopener noreferrer">
              See this record at {d.name} ↗
            </a>
          )}

          {s.about && (
            <Section title="Recorded against" status="LIVE" origin={`From ${d.name}.`}>
              <Li color={TYPE_COLOR.TAXON} name={s.about.label} sub={s.about.sub} onClick={() => onOpen(s.about!.id)} />
            </Section>
          )}

          <Evidence>
            <Fact k="Identity" mono>{s.id}</Fact>
            <Fact k="Location" mono>{coord(s.lat, s.lng, 2)}</Fact>
            <Fact k="Occurred">{timeAgoHuman(s.provenance.occurredAt)}</Fact>
            <Fact k="4PLANET checked">{timeAgoHuman(s.provenance.checkedAt)}</Fact>
            <Fact k="Significance">{String(s.significance).toLowerCase()}</Fact>
            {/* Brief §39. We say this out loud rather than implying urgency by design. */}
            <p className="note-box">
              4PLANET has not promoted this record to an alert. It has no methodology for doing
              so, and will not manufacture one.
            </p>
            <Source ids={[s.provenance.sourceId]} />
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── OBSERVATION (first-class object — Brief §22, V38R integration finding) ─
     An observation is a record that somebody looked and reported. It is NOT a
     signal, and this panel keeps it distinct: what was recorded, which taxon,
     when, where, from which source, and a route from observation → taxon. It
     shows only fields GBIF actually returns; it invents nothing. */
  if (ctx.kind === "OBSERVATION") {
    const { observation: ob } = ctx;
    const o = ob.occurrence;
    const p = ob.provenance;
    // Route into SPECIES when this record's taxon matches the catalogue.
    const sciMatch = (o.scientificName || "").toLowerCase();
    const speciesMatch = SPECIES_PROFILES.find(
      (s) => (o.taxonKey && s.gbifKey === o.taxonKey) || s.scientificName.toLowerCase() === sciMatch,
    );
    // Source image shown ONLY when both URL and licence are present.
    const showImg = !!(o.mediaUrl && o.mediaLicence);
    const bundled = ob.provenance?.delivery === "BUNDLED_SNAPSHOT";
    const title = o.commonName || ob.taxon.label;
    return (
      <aside className="ctx" aria-label={`${title} — observation record`}>
        {head(title, o.scientificName && o.scientificName !== title ? <em>{o.scientificName}</em> : undefined)}
        <div className="ctx-body">
          {bundled && (
            <p className="note-box strong">
              BUNDLED SOURCE SNAPSHOT · NOT LIVE · {ob.provenance.sourceId?.toUpperCase() || "GBIF"} RECORD {o.sourceRecordId} · CHECKED {ob.provenance.checkedAt} — HISTORICAL OBSERVATION, NOT THE ANIMAL'S CURRENT POSITION
            </p>
          )}
          {showImg ? (
            <figure className="ctx-figure">
              <img className="ctx-hero" src={o.mediaUrl} alt={`${o.commonName || o.scientificName} — illustrative of the species, not this occurrence`} loading="lazy" />
              <span className="figure-flag">Illustrative of species — not this occurrence</span>
              <figcaption className="src-line">
                {o.mediaAttribution || "Illustration"} · {o.mediaLicence}
              </figcaption>
            </figure>
          ) : (
            <p className="origin">No licensed image on this record — showing the record without a photo.</p>
          )}

          <Section
            title="What was recorded"
            status={bundled ? "BUNDLED" : "LIVE"}
            origin="From GBIF and the publishing institution."
          >
            <Fact k="Species, as recorded"><em>{o.scientificName}</em></Fact>
            <Fact k="Observed">{o.eventDate || "Date not given"}</Fact>
          </Section>
          <p className="note-box">{OBSERVATION_CAVEAT}</p>

          {p.sourceUrl && (
            <a className="text-link" href={p.sourceUrl} target="_blank" rel="noopener noreferrer">
              See this record at GBIF ↗
            </a>
          )}
          {speciesMatch && <br />}
          {speciesMatch && (
            <Link
              className="text-link"
              to={`/species/${speciesMatch.slug}?entity=${encodeURIComponent(speciesMatch.id)}`}
              onClick={(e) => {
                // Encode returnTo from the LIVE ATLAS url at click time, so the
                // post-interaction camera (written by the last moveend) is the
                // one that returns — not a stale render-time snapshot.
                e.preventDefault();
                navigate(withReturnTo(`/species/${speciesMatch.slug}?entity=${encodeURIComponent(speciesMatch.id)}`, window.location.search));
              }}
            >
              Open {speciesMatch.commonName} in SPECIES →
            </Link>
          )}

          {/* observation → taxon → relationship context */}
          <Section title="This is a record of" status="LIVE" origin="The species named on the source record.">
            <Li
              color={TYPE_COLOR.TAXON}
              name={ob.taxon.label}
              sub={ob.taxon.sub ? <em>{ob.taxon.sub}</em> : undefined}
              onClick={() => onOpen(ob.taxon.id)}
            />
          </Section>

          <Evidence>
            <Fact k="Identity" mono>{ob.id}</Fact>
            <Fact k="Location" mono>{coord(o.lat, o.lng)}</Fact>
            {typeof o.coordinateUncertaintyM === "number" && (
              <Fact k="Coordinate uncertainty">±{Math.round(o.coordinateUncertaintyM).toLocaleString("en-GB")} m</Fact>
            )}
            <Fact k="4PLANET checked">{timeAgoHuman(p.checkedAt)}</Fact>
            <Source ids={["gbif"]} />
            {/* Honest about what we do NOT have from the source. Brief §29. */}
            <p className="note-box">
              {typeof o.coordinateUncertaintyM === "number" ? "" : "Coordinate uncertainty: not checked. "}
              Sensitivity and obfuscation: not checked. Sensitive locations are
              generalised. This point is where a record was reported, not where
              the animal is now.
            </p>
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── PRESSURE → SOLUTION → MISSION ─────────────────────────────────────── */
  if (ctx.kind === "PRESSURE") {
    const p = ctx.pressure;
    const sols = p.solutionIds.map(solutionById).filter(Boolean) as Solution[];
    return (
      <aside className="ctx" aria-label={`${p.name} — pressure`}>
        {head(p.name)}
        <div className="ctx-body">
          <p className="lead">{p.body}</p>

          <Section title="What it affects" status="SEEDED">
            {p.affects.map((id) => {
              const n = nodeById(id) ?? systemById(id);
              const label = (n as any)?.label ?? (n as any)?.name ?? id;
              return (
                <Li
                  key={id}
                  color={TYPE_COLOR[typeOf(id)] ?? "#0A0A0A"}
                  name={label}
                  sub={KIND_LABEL[typeOf(id)]}
                  onClick={() => onOpen(id)}
                />
              );
            })}
          </Section>

          <Section
            title="What may help"
            status={sols.length ? "SEEDED" : "NO_COVERAGE"}
            origin="Solution pathways 4PLANET has seeded against this pressure. A pathway is not a proven solution, and 4PLANET has not run an evidence assessment. Maturity, evidence strength and applicability are three separate axes and are shown separately."
          >
            {sols.map((s) => (
              <Li
                key={s.id}
                color={TYPE_COLOR.SOLUTION}
                name={s.name}
                sub={`${s.maturity} · EVIDENCE ${s.evidenceStrength}`}
                why={s.body}
                onClick={() => onOpen(s.id)}
              />
            ))}
          </Section>

          <Evidence>
            <Fact k="Identity" mono>{p.id}</Fact>
            <Fact k="Status">{STATUS_TEXT.SEEDED}</Fact>
            <p className="note-box">{STATUS_MEANING.SEEDED}</p>
          </Evidence>
        </div>
      </aside>
    );
  }

  if (ctx.kind === "SOLUTION") {
    const s = ctx.solution;
    const missions = (s.missionIds ?? []).map(missionById).filter(Boolean) as Mission[];
    return (
      <aside className="ctx" aria-label={`${s.name} — solution pathway`}>
        {head(s.name)}
        <div className="ctx-body">
          <p className="lead">{s.body}</p>

          <Section
            title="How far along it is"
            status="SEEDED"
            origin="These labels are 4PLANET's seeded assessment. They require a published methodology before they can carry authority, and they do not have one yet."
          >
            {/* Brief §43: never collapse three axes into one badge. */}
            <div className="axes">
              <div className="axis">
                <div className="ak">Maturity</div>
                <div className="av">{s.maturity}</div>
              </div>
              <div className="axis">
                <div className="ak">Evidence</div>
                <div className="av">{s.evidenceStrength}</div>
              </div>
              <div className="axis">
                <div className="ak">Applicability</div>
                <div className="av">{s.applicability.replace(/_/g, " ")}</div>
              </div>
            </div>
          </Section>

          <Section title="Known limitations" status="SEEDED">
            <p className="prose">{s.limitations}</p>
          </Section>

          {s.actors && s.actors.length > 0 && (
            <Section title="Who implements it" status="SEEDED">
              {s.actors.map((a) => (
                <Li key={a} name={a} />
              ))}
            </Section>
          )}

          {missions.length > 0 && (
            <Section
              title="4PLANET mission connection"
              status="SEEDED"
              origin="A MISSION IS NOT THE SOLUTION. 4PLANET does not implement this pathway. A mission exists to accelerate, fund, connect or make visible work that other actors do."
            >
              {missions.map((m) => (
                <Li
                  key={m.id}
                  name={m.name}
                  sub={`4PLANET mission · ${m.status}`}
                  why={m.accelerates}
                  onClick={() => onOpen(m.id)}
                />
              ))}
            </Section>
          )}

          <Evidence>
            <Fact k="Identity" mono>{s.id}</Fact>
            <Fact k="Status">{STATUS_TEXT.SEEDED}</Fact>
            <p className="note-box">{STATUS_MEANING.SEEDED}</p>
          </Evidence>
        </div>
      </aside>
    );
  }

  if (ctx.kind === "MISSION") {
    const m = ctx.mission;
    return (
      <aside className="ctx" aria-label={`${m.name} — 4PLANET mission`}>
        {head(m.name)}
        <div className="ctx-body">
          <p className="lead">{m.accelerates}</p>

          {/* Brief §57 + §58. This is the honest end of the chain, and it stops here. */}
          <Section title="Expected outcome" status="NOT_CHECKED" note={m.expectedOutcome} />
          <Section title="Proof path" status="NOT_CHECKED" note={m.proofPath} />

          <p className="note-box">
            No payment is available for this mission and none will be until an implementation
            partner and a proof pathway are real. The architecture from pressure to solution to
            mission exists. The outcome does not, and 4PLANET will not invent one to make the
            interface feel finished.
          </p>

          <div className="actions">
            <Link to={m.href} className="follow-btn link"><span>Open mission</span></Link>
          </div>

          <Evidence>
            <Fact k="Identity" mono>{m.id}</Fact>
            <Fact k="Mission status">{m.status}</Fact>
            <Fact k="Description">{STATUS_TEXT.SEEDED}</Fact>
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── LEGACY_POINT (V39.1 Scope 01 / V40 — legacy layer click, one surface) ─ */
  if (ctx.kind === "LEGACY_POINT") {
    return (
      <aside className="ctx" aria-label={`${ctx.title} — map record`}>
        {head(ctx.title, ctx.scientificName && ctx.scientificName !== ctx.title ? <em>{ctx.scientificName}</em> : undefined)}
        <div className="ctx-body">
          <p className="lead-fact">
            {ctx.observedDate
              ? <>Recorded <strong>{ctx.observedDate}</strong>.</>
              : <>The source does not say when this was recorded.</>}{" "}
            From {ctx.sourceLabel}.
          </p>

          {/* Legacy preview parity: preserve the source-rendered detail the old V36
              popup showed (dates, magnitude, altitude, velocity, links) — verbatim
              from the source layer, inventing nothing. */}
          {ctx.previewHtml && (
            <Section title="From the source" status="LIVE" origin={`As ${ctx.sourceLabel} describes it.`}>
              <div className="legacy-preview" dangerouslySetInnerHTML={{ __html: ctx.previewHtml }} />
            </Section>
          )}

          {(ctx.gbifKey || ctx.aphiaId) && (
            <div className="links">
              {ctx.gbifKey && (
                <a className="text-link" href={`https://www.gbif.org/species/${ctx.gbifKey}`} target="_blank" rel="noopener noreferrer">
                  GBIF species record ↗
                </a>
              )}
              {ctx.aphiaId && (
                <a
                  className="text-link"
                  href={`https://www.marinespecies.org/aphia.php?p=taxdetails&id=${ctx.aphiaId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  WoRMS / AphiaID authority ↗
                </a>
              )}
            </div>
          )}

          <Evidence>
            {ctx.commonName && <Fact k="Common name">{ctx.commonName}</Fact>}
            {ctx.scientificName && <Fact k="As recorded"><em>{ctx.scientificName}</em></Fact>}
            <Fact k="Location" mono>{coord(ctx.lat, ctx.lng)}</Fact>
            <Fact k="Layer">{ctx.sub ?? "—"}</Fact>
            <Fact k="Source">{ctx.sourceLabel}</Fact>
            {ctx.planetaryContext && <Fact k="Class">Planetary context</Fact>}
            {/* V40 temporal correction: source access, recorded time and retrieval
                are separate facts. None of them is "live". */}
            <Fact k="Source access">Request returned</Fact>
            <Fact k="Recorded / observed">{ctx.observedDate || "Unknown from source"}</Fact>
            <Fact k="Retrieved">This session</Fact>
            <p className="note-box">
              A successful network request does not make the underlying record live or
              recent. 4PLANET is showing what the source returned, when it happened
              (where the source says so), and that it was fetched this session — nothing more.
            </p>
            <p className="note-box">
              This is a point drawn from a source layer, shown here rather than in a
              floating popup so the whole product stays one surface. 4PLANET has not
              resolved it to a canonical entity — no reviewed identity, evidence status
              or place membership yet.
            </p>
          </Evidence>
        </div>
      </aside>
    );
  }

  /* ── COORDINATE — "HERE" (V36's "WHAT IS HAPPENING HERE", made human) ───── */
  if (ctx.kind === "COORDINATE") {
    const { lat, lng, life, species, signals } = ctx;
    const where: PointDescription = ctx.where ?? (ctx.placeName ? { name: ctx.placeName, distanceKm: 0 } : {});
    const known = ctx.known?.status === "OK" ? ctx.known.value : undefined;
    const knowing = ctx.known?.status === "LOADING";
    const described = known ? describeKnowledge(known) : undefined;
    const place: PlaceContext | null | undefined = ctx.context;

    // TITLE — the most specific true name. A searched name wins; on water the
    // basemap's own water label (e.g. "Oslofjorden") beats the broader sea.
    let eyebrow = "Here";
    let title = pointTitle(where);
    let sub: string | undefined;
    if (ctx.label) {
      eyebrow = ctx.label.kind;
      title = ctx.label.name;
      sub = described && described.title !== ctx.label.name ? [described.title, described.sub].filter(Boolean).join(" · ") : described?.sub;
    } else if (described) {
      eyebrow = described.kind;
      title = described.title;
      sub = described.sub;
      if (known && !known.onLand && where.waterName && where.waterName !== described.title) {
        eyebrow = "Water";
        title = where.waterName;
        sub = [`In the ${described.title}`, described.sub].filter(Boolean).join(" · ");
      }
    } else if (!knowing) {
      const far = where.name && !where.onWater && (where.distanceKm ?? 0) > 2;
      sub = far ? `About ${Math.max(1, Math.round(where.distanceKm ?? 0)).toLocaleString("en-GB")} km from ${where.name}` : undefined;
    }
    const named = Boolean(described || where.name || where.waterName || ctx.label);

    const about = place?.about;
    const eco = place?.ecoregion;
    const ecoAbout = place?.ecoregionAbout;
    const localTime = (() => {
      if (!known?.timezone) return undefined;
      try {
        return new Intl.DateTimeFormat("en-GB", { timeZone: known.timezone, hour: "2-digit", minute: "2-digit", weekday: "short" }).format(new Date());
      } catch { return undefined; }
    })();
    const signalRows = signals.value ?? [];

    return (
      <aside className="ctx" aria-label={`${title} — selected point`}>
        {head(title, sub, eyebrow)}
        <div className="ctx-body">
          {!named && !knowing && (
            <p className="lead">No named place is close enough to this point to describe it fairly.</p>
          )}

          {/* ABOUT — the Wikipedia lead for the most specific named area. Its title
              is always said, so a region's article is never passed off as a town's. */}
          {(place === null && (ctx.known?.status !== "UNAVAILABLE")) && (
            <div className="skeleton" aria-hidden="true"><i /><i /></div>
          )}
          {about?.status === "OK" && about.value && (
            <section className="about" aria-label={`About ${about.value.title}`}>
              <p className="lead">{about.value.extract}</p>
              <p className="origin">
                {about.value.title !== title ? <>About <strong>{about.value.title}</strong> · </> : null}
                From <a href={about.value.url} target="_blank" rel="noopener noreferrer">Wikipedia</a> · {about.value.licence}
              </p>
            </section>
          )}

          {/* AT A GLANCE — what the open geography says about this point. */}
          {known && (
            <div className="glance">
              {known.water && !known.onLand && described?.title !== known.water.name && <Glance k={known.water.type || "Water"} v={known.water.name} />}
              {known.land.slice(0, 2).filter((a) => a.name !== title).map((a) => <Glance key={a.name} k={a.type || "Landscape"} v={a.name} />)}
              {known.region && known.region.name !== title && <Glance k={known.region.type || "Region"} v={known.region.name} />}
              {known.country && known.country.name !== title && <Glance k="Country" v={known.country.name} />}
              {known.nearest && known.nearest.name !== title && <Glance k="Nearest town" v={townLine(known.nearest)} />}
              {known.notable && known.notable.name !== title && known.notable.name !== known.nearest?.name && <Glance k="Nearest city" v={townLine(known.notable)} />}
              {known.peak && <Glance k={known.peak.kind === "mountain" ? "Nearest named peak" : "Nearby"} v={`${known.peak.name}${known.peak.elevationM ? ` · ${known.peak.elevationM.toLocaleString("en-GB")} m` : ""} · ${Math.max(1, Math.round(known.peak.distanceKm))} km`} />}
              {localTime && <Glance k="Local time" v={localTime} />}
            </div>
          )}

          {/* LIVING SETTING — the ecoregion this point belongs to (land only). */}
          {known?.onLand && (
            <Section
              title="Living setting"
              status={!place ? "LOADING" : eco?.status === "OK" ? "LIVE" : eco?.status === "UNAVAILABLE" ? "SOURCE_UNAVAILABLE" : "NO_COVERAGE"}
              note={eco?.status === "NONE" ? "This point is not inside a mapped terrestrial ecoregion (ice, open water or a mapping gap)." : undefined}
              origin={<>RESOLVE Ecoregions 2017 · CC BY 4.0{ecoAbout?.status === "OK" && ecoAbout.value ? <> · <a href={ecoAbout.value.url} target="_blank" rel="noopener noreferrer">About this ecoregion on Wikipedia</a></> : null}</>}
            >
              {eco?.value && (
                <div className="eco">
                  <p className="eco-name">{eco.value.name}</p>
                  <p className="eco-sub">{[eco.value.biome, eco.value.realm ? `${eco.value.realm} realm` : null].filter(Boolean).join(" · ")}</p>
                  {ecoAbout?.status === "OK" && ecoAbout.value && <p className="prose eco-lead">{ecoAbout.value.extract}</p>}
                  {eco.value.nnhSentence && <p className="eco-nnh">{eco.value.nnhSentence}</p>}
                </div>
              )}
            </Section>
          )}

          <RecordedHere
            title="Recorded around here"
            species={species}
            take={5}
            caption="Species with the most records within roughly 40 km of this point. Records show where people looked, not everything that lives here."
            onOpen={onOpen}
          />

          {(signalRows.length > 0 || signals.status !== "NO_RECORDS") && (
            <ReportedNearby
              signals={signals}
              showDistance
              quietNote=""
              onOpen={onOpen}
            />
          )}

          <Evidence>
            <Fact k="Point" mono>{coord(lat, lng)}</Fact>
            <Fact k="Place names">
              {ctx.known?.status === "UNAVAILABLE"
                ? "The place files did not load — names come from the basemap only"
                : "GeoNames (towns, CC BY 4.0) and Natural Earth (countries, regions, seas, landscapes, lakes, public domain)"}
            </Fact>
            {known?.nearest && <Fact k="Nearest populated place">{`${known.nearest.name}, ${Math.round(known.nearest.distanceKm)} km`}</Fact>}
            {where.name && (
              <Fact k="Nearest basemap label">
                {`${where.name}, ${Math.round(where.distanceKm ?? 0).toLocaleString("en-GB")} km away`}
              </Fact>
            )}
            <Fact k="Ecoregion">
              {!known?.onLand ? "Not asked — terrestrial ecoregions only" : !place ? "Loading" : eco?.status === "OK" ? "RESOLVE Ecoregions 2017 via UNEP-WCMC" : eco?.status === "UNAVAILABLE" ? "Source did not respond" : "No ecoregion at this point"}
            </Fact>
            <Fact k="Description">
              {!place ? "Loading" : about?.status === "OK" ? "Wikipedia lead, matched by Wikidata id or by coordinates" : about?.status === "UNAVAILABLE" ? "Wikipedia did not respond" : "No article matched this place"}
            </Fact>
            <Fact k="Area queried for species">A square of roughly 40 km around the point</Fact>
            {(species.value || life.value) && (
              <Fact k="Records returned for the area">
                {(species.value?.total ?? life.value?.total ?? 0).toLocaleString("en-GB")}
              </Fact>
            )}
            <Fact k="Species records">{STATUS_TEXT[species.status]}</Fact>
            <Fact k="Event feeds">{STATUS_TEXT[signals.status]}</Fact>
            <p className="note-box">
              A name is the area this point falls inside, or the nearest town with its distance. Being
              near a town does not make the point part of it, and the square searched for species is
              not a place.
            </p>
            {signals.status === "NO_RECORDS" && (
              <p className="note-box">
                No open natural event or recorded earthquake fell inside the current nearby search
                window. Nothing here does not mean nothing is here — it means no source 4PLANET reads
                reported anything in this window.
              </p>
            )}
            <Source ids={["gbif", "eonet", "usgs"]} />
          </Evidence>
        </div>
      </aside>
    );
  }

  return null;
};

/* Re-exported so World can build lists without importing the whole graph. */
export { PRESSURES, SOLUTIONS, MISSIONS, KIND_LABEL };
