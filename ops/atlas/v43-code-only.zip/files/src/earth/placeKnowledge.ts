/**
 * ATLAS PLACE KNOWLEDGE — what is this point, in a person's words.
 *
 * Reads the static, open place files compiled by scripts/build-atlas-places.mjs
 * (GeoNames CC BY 4.0 + Natural Earth public domain) from this site — one small
 * file per 5° of the planet, fetched when a point there is asked about — and,
 * for what a static file cannot hold, the same-origin /api/atlas-place Function
 * (RESOLVE ecoregions, Wikipedia leads).
 *
 * Truth rules kept here:
 *  · a name is only given with its distance when the point is not in the place;
 *  · a failed fetch is reported as unavailable, never as "nothing here";
 *  · nothing is inferred beyond the sources (no invented descriptions).
 */

export const PLACE_DATA_BASE = "/atlas-data/places/v1";
const CELL = 5;

export interface PlaceArea { name: string; type?: string; wikidata?: string; countryCode?: string }
export interface PlaceTown { name: string; lat: number; lon: number; population: number; countryCode: string; timezone?: string; rank?: "C" | "A" | ""; distanceKm: number }
export interface PlacePeak { name: string; lat: number; lon: number; elevationM: number | null; wikidata?: string; kind: string; distanceKm: number }
export interface PlaceKnowledge {
  lat: number;
  lon: number;
  country?: PlaceArea & { continent?: string; subregion?: string };
  region?: PlaceArea;          // state / province / county
  water?: PlaceArea;           // ocean, sea, gulf, bay, strait, fjord …
  lake?: PlaceArea;
  land: PlaceArea[];           // physical regions: island, range, desert …
  nearest?: PlaceTown;         // nearest populated place
  notable?: PlaceTown;         // nearest place of 50,000+ people
  peak?: PlacePeak;            // nearest named elevation point within 40 km
  timezone?: string;
  onLand: boolean;
}

export type PlaceResult =
  | { status: "OK"; value: PlaceKnowledge }
  | { status: "UNAVAILABLE"; error: string };

type CellFile = {
  v: number;
  areas: Array<{ k: string; n: string; t?: string; q?: string; cc?: string; c?: string; s?: string; r: number[][] }>;
  towns: Array<[string, number, number, number, string, number, ("C" | "A")?]>;
  peaks: Array<[string, number, number, number | null, string | null, string]>;
  tz: string[];
};

const cellCache = new Map<string, Promise<CellFile | null>>();
const cellKey = (lon: number, lat: number) => {
  const cx = Math.min(360 / CELL - 1, Math.max(0, Math.floor((lon + 180) / CELL)));
  const cy = Math.min(180 / CELL - 1, Math.max(0, Math.floor((lat + 90) / CELL)));
  return `${cx}_${cy}`;
};

function loadCell(key: string): Promise<CellFile | null> {
  const hit = cellCache.get(key);
  if (hit) return hit;
  const pending = fetch(`${PLACE_DATA_BASE}/cells/${key}.json`)
    .then(async (response) => {
      if (response.status === 404) return { v: 1, areas: [], towns: [], peaks: [], tz: [] } as CellFile; // open ocean with nothing named
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return (await response.json()) as CellFile;
    })
    .catch((error) => { cellCache.delete(key); throw error; });
  cellCache.set(key, pending);
  return pending;
}

export function kmBetween(aLat: number, aLon: number, bLat: number, bLon: number) {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLon = ((bLon - aLon) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export function pointInFlatRings(lon: number, lat: number, rings: number[][]) {
  let inside = false;
  for (const ring of rings) {
    const n = ring.length / 2;
    for (let i = 0, j = n - 1; i < n; j = i++) {
      const xi = ring[i * 2], yi = ring[i * 2 + 1], xj = ring[j * 2], yj = ring[j * 2 + 1];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
    }
  }
  return inside;
}

/** The cell a point is in, plus its neighbours when the point is near an edge. */
function cellsAround(lat: number, lon: number, marginDeg = 0.6) {
  const keys = new Set([cellKey(lon, lat)]);
  for (const dx of [-marginDeg, 0, marginDeg]) for (const dy of [-marginDeg, 0, marginDeg]) {
    const x = ((lon + dx + 540) % 360) - 180;
    const y = Math.max(-89.999, Math.min(89.999, lat + dy));
    keys.add(cellKey(x, y));
  }
  return [...keys];
}

export async function knowPlace(lat: number, lon: number): Promise<PlaceResult> {
  let home: CellFile | null;
  let around: Array<CellFile | null>;
  try {
    const keys = cellsAround(lat, lon);
    const files = await Promise.all(keys.map(loadCell));
    home = files[0];
    around = files;
  } catch (error) {
    return { status: "UNAVAILABLE", error: String((error as Error)?.message || error) };
  }
  if (!home) return { status: "UNAVAILABLE", error: "NO_DATA" };

  const k: PlaceKnowledge = { lat, lon, land: [], onLand: false };
  for (const area of home.areas) {
    if (!pointInFlatRings(lon, lat, area.r)) continue;
    const value: PlaceArea = { name: area.n, type: area.t, wikidata: area.q, countryCode: area.cc };
    if (area.k === "country" && !k.country) k.country = { ...value, continent: area.c, subregion: area.s };
    else if (area.k === "admin1" && !k.region) k.region = value;
    else if (area.k === "marine" && !k.water) k.water = value;
    else if (area.k === "lake" && !k.lake) k.lake = value;
    else if (area.k === "region" && area.t !== "Continent") k.land.push(value);
  }
  k.onLand = Boolean(k.country || k.region) && !k.lake;
  // Natural Earth marine areas and coastlines overlap a little at the shore:
  // inside a country polygon the point is land.
  if (k.onLand && k.water) k.water = undefined;
  // Islands first, then the most specific physical regions.
  const rank = (t?: string) => ({ Island: 0, Delta: 1, Peninsula: 2, Desert: 3, "Mountain range": 4, Plateau: 5 } as Record<string, number>)[t || ""] ?? 9;
  k.land.sort((a, b) => rank(a.type) - rank(b.type));

  let nearest: PlaceTown | undefined;
  let notable: PlaceTown | undefined;
  let peak: PlacePeak | undefined;
  for (const file of around) {
    if (!file) continue;
    for (const t of file.towns) {
      const d = kmBetween(lat, lon, t[1], t[2]);
      const town: PlaceTown = { name: t[0], lat: t[1], lon: t[2], population: t[3], countryCode: t[4], timezone: file.tz?.[t[5]] || undefined, rank: t[6] || "", distanceKm: d };
      if (!nearest || d < nearest.distanceKm) nearest = town;
      if (t[3] >= 50_000 && (!notable || d < notable.distanceKm)) notable = town;
    }
    for (const p of file.peaks) {
      const d = kmBetween(lat, lon, p[1], p[2]);
      if (d <= 40 && (!peak || d < peak.distanceKm)) peak = { name: p[0], lat: p[1], lon: p[2], elevationM: p[3], wikidata: p[4] || undefined, kind: p[5], distanceKm: d };
    }
  }
  if (nearest && nearest.distanceKm <= 75) k.nearest = nearest;
  if (notable && notable.distanceKm <= 150 && notable.name !== nearest?.name) k.notable = notable;
  if (peak) k.peak = peak;
  k.timezone = k.nearest?.timezone;
  return { status: "OK", value: k };
}

const roundKm = (km: number) => (km < 10 ? Math.max(1, Math.round(km)) : Math.round(km / 5) * 5);
const plural = (n: number) => n.toLocaleString("en-GB");

/** Kind word, title and one orienting line for a point. Never claims more than the data. */
export function describeKnowledge(k: PlaceKnowledge): { kind: string; title: string; sub?: string; specificWikidata: string[]; town?: PlaceTown } {
  const parts = (...names: Array<string | undefined>) => {
    const out: string[] = [];
    for (const n of names) if (n && !out.includes(n)) out.push(n);
    return out;
  };
  const near = k.nearest ? `${roundKm(k.nearest.distanceKm)} km from ${k.nearest.name}` : undefined;
  const ids = (...areas: Array<PlaceArea | undefined>) => [...new Set(areas.map((a) => a?.wikidata).filter(Boolean) as string[])];
  // "Where" never repeats the title ("Svalbard · Svalbard, Norway").
  const whereFor = (title: string) => parts(k.region?.name, k.country?.name).filter((n) => n !== title).join(", ");

  if (k.lake) {
    return { kind: k.lake.type || "Lake", title: k.lake.name, sub: [whereFor(k.lake.name), near].filter(Boolean).join(" · ") || undefined, specificWikidata: ids(k.lake, k.region, k.country) };
  }
  if (!k.onLand && k.water) {
    const off = k.nearest && k.nearest.distanceKm <= 60
      ? `Off ${k.nearest.name} · ${roundKm(k.nearest.distanceKm)} km`
      : undefined;
    return { kind: k.water.type || "Sea", title: k.water.name, sub: off, specificWikidata: ids(k.water) };
  }
  // A town names the point when the point is in it. A large place a few km
  // away names it before a suburb next door ("Orlando", not "Holden Heights").
  const town = k.notable && k.notable.distanceKm <= 12 && (!k.nearest || k.nearest.population < 20_000 || k.nearest.distanceKm > 6)
    ? k.notable
    : k.nearest && k.nearest.distanceKm <= 6 ? k.nearest : undefined;
  if (town) {
    const kind = town.rank === "C" ? "Capital" : town.population >= 100_000 ? "City" : town.population >= 10_000 ? "Town" : "Village";
    const inSide = town.distanceKm > 6 ? `${roundKm(town.distanceKm)} km from the centre` : undefined;
    return { kind, title: town.name, sub: [whereFor(town.name), inSide].filter(Boolean).join(" · ") || undefined, specificWikidata: ids(k.land[0], k.region, k.country), town };
  }
  if (k.land[0]) {
    const within = k.land[1] && k.land[1].name !== k.land[0].name ? `In ${/^(the |)/i.test(k.land[1].name) && /desert|sahara|alps|andes|himalaya|amazon|plain|basin|plateau|mountains|islands/i.test(k.land[1].name) ? "the " : ""}${k.land[1].name}` : undefined;
    return { kind: k.land[0].type || "Region", title: k.land[0].name, sub: [within, whereFor(k.land[0].name), near].filter(Boolean).join(" · ") || undefined, specificWikidata: ids(k.land[0], k.land[1], k.region, k.country) };
  }
  if (k.region) {
    return { kind: k.region.type || "Region", title: k.region.name, sub: [k.country?.name !== k.region.name ? k.country?.name : undefined, near].filter(Boolean).join(" · ") || undefined, specificWikidata: ids(k.region, k.country) };
  }
  if (k.country) {
    return { kind: "Country", title: k.country.name, sub: near, specificWikidata: ids(k.country) };
  }
  return { kind: "Here", title: "Open water", sub: undefined, specificWikidata: [] };
}

export function townLine(t: PlaceTown) {
  return `${t.name} · ${roundKm(t.distanceKm)} km${t.population >= 1000 ? ` · ${plural(Math.round(t.population / 100) * 100)} people` : ""}`;
}

/* ── context from the server: ecoregion + Wikipedia ───────────────────────── */
export type Part<T> = { status: "OK" | "NONE" | "UNAVAILABLE" | "NOT_ASKED"; value: T | null };
export interface Ecoregion { name: string; biome: string | null; realm: string | null; nnh: string | null; nnhSentence: string | null; id: number | null; areaKm2: number | null }
export interface WikiLead { title: string; description: string | null; extract: string; url: string; licence: string; wikidata?: string }
export interface PlaceContext { ecoregion: Part<Ecoregion>; about: Part<WikiLead>; ecoregionAbout: Part<WikiLead> }

const contextCache = new Map<string, Promise<PlaceContext>>();
export function placeContext(k: PlaceKnowledge, wikidata: string[], town?: PlaceTown): Promise<PlaceContext> {
  const params = new URLSearchParams({ lat: k.lat.toFixed(2), lon: k.lon.toFixed(2) });
  if (wikidata.length) params.set("q", wikidata.slice(0, 3).join(","));
  if (town) { params.set("town", town.name); params.set("tlat", String(town.lat)); params.set("tlon", String(town.lon)); }
  if (k.onLand) params.set("land", "1");
  const key = params.toString();
  const hit = contextCache.get(key);
  if (hit) return hit;
  const unavailable: PlaceContext = {
    ecoregion: { status: k.onLand ? "UNAVAILABLE" : "NOT_ASKED", value: null },
    about: { status: wikidata.length || town ? "UNAVAILABLE" : "NOT_ASKED", value: null },
    ecoregionAbout: { status: "NOT_ASKED", value: null },
  };
  const pending = fetch(`/api/atlas-place?${key}`)
    .then(async (response) => {
      if (!response.ok) return unavailable;
      const data = await response.json();
      if (!data?.ok) return unavailable;
      return { ecoregion: data.ecoregion, about: data.about, ecoregionAbout: data.ecoregionAbout } as PlaceContext;
    })
    .catch(() => { contextCache.delete(key); return unavailable; });
  contextCache.set(key, pending);
  return pending;
}

/* ── worldwide search ─────────────────────────────────────────────────────── */
export interface PlaceHit { name: string; kind: string; lat: number; lon: number; context: string; countryCode?: string; wikidata?: string; weight: number }
type SearchFile = { rows: Array<[string, string, number, number, number, string | null, string, string | null]> };
const searchCache = new Map<string, Promise<SearchFile | null>>();
export const foldName = (s: string) => String(s || "").normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

function loadLetter(letter: string) {
  const hit = searchCache.get(letter);
  if (hit) return hit;
  const pending = fetch(`${PLACE_DATA_BASE}/search/${letter}.json`)
    .then((r) => (r.ok ? r.json() : null))
    .catch(() => { searchCache.delete(letter); return null; });
  searchCache.set(letter, pending);
  return pending;
}

const KIND_WEIGHT: Record<string, number> = { Country: 9, Capital: 8, Ocean: 8, Sea: 7, Desert: 6, "Mountain range": 6, City: 5, Island: 5, Gulf: 5, Lake: 4, State: 4, Province: 4, Region: 4, Bay: 4, Strait: 4, Fjord: 4, Mountain: 3, Town: 2 };

/** Places worldwide whose name starts with (or equals) the query. `null` when the index could not be read. */
export async function searchPlaces(query: string, limit = 6): Promise<PlaceHit[] | null> {
  const q = foldName(query);
  if (q.length < 2) return [];
  const c = q.charAt(0);
  const file = await loadLetter(c >= "a" && c <= "z" ? c : "0");
  if (!file) return null;
  const hits: PlaceHit[] = [];
  for (const [name, kind, lat, lon, size, cc, context, q2] of file.rows) {
    const f = foldName(name);
    if (!f.startsWith(q)) continue;
    const exact = f === q ? 100 : 0;
    const word = f.length === q.length || f.charAt(q.length) === " " ? 10 : 0;
    const big = kind === "Mountain" ? 0 : Math.log10(Math.max(1, size || 1));
    hits.push({ name, kind, lat, lon, context, countryCode: cc || undefined, wikidata: q2 || undefined, weight: exact + word + (KIND_WEIGHT[kind] ?? 2) + big });
  }
  hits.sort((a, b) => b.weight - a.weight);
  const seen = new Set<string>();
  return hits.filter((h) => {
    const key = `${foldName(h.name)}|${h.kind}|${h.context}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, limit);
}
