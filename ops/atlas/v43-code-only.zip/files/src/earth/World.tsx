/* ═══════════════════════════════════════════════════════════════════════════
   4PLANET_ v1 — THE WORLD
   ───────────────────────────────────────────────────────────────────────────
   Mandate: "THE WORLD IS THE INTERFACE."

   You open 4PLANET and you see Earth. Not a landing page with a globe on it —
   Earth, with a search line floating over it, and everything else arriving as
   an overlay on top of the world rather than a page instead of the world.

   WHAT THIS FILE IS
   ─────────────────
   It is V36's AtlasMap, kept alive and given a nervous system.

   PRESERVED FROM V36, UNCHANGED IN BEHAVIOUR:
     · MapLibre globe projection + mercator toggle
     · The entire 16-layer console: raster stacking order, opacity sliders,
       legend ramps, per-layer provenance notes, ISOLATE, DOMAINS grouping,
       MODES (PLANET / OCE4N / E4RTH / S4PIENS), day/night terminator
     · URL state (?m=&l=&t=&p=&z=&c=), share-link copy, NEAR ME geolocation
     · The "WHAT IS HAPPENING HERE" click probe
     · Honest degradation: a 404 raster says UNAVAILABLE, it does not fake ON
     · Live refresh intervals for point layers

   ADDED, AND THE WHOLE POINT OF v1:
     · SEARCH THE LIVING PLANET_ — one search line, over the world, that
       resolves taxa (GBIF, live), places (seeded registry) and living systems
       (seeded graph) into the SAME canonical id space
     · The world RESPONDS: selecting anything flies the camera and repaints
     · The SHARED CONTEXT LAYER: one panel, every object type
     · FOLLOW: local-first, canonical ids
     · NOW: one signal pool, shown as change over time from supported data
     · WATCH: matched signals with a mandatory "why am I seeing this"

   @ts-nocheck is inherited from V36's Atlas.tsx and kept for the same reason:
   this file is imperative MapLibre glue, and MapLibre's types fight React refs
   at every turn. The typed core of the product lives in src/planet/*, which is
   strict. That boundary is deliberate. See ADAPTATION.md.
   ═══════════════════════════════════════════════════════════════════════════ */
/* eslint-disable */
// @ts-nocheck

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import * as maplibregl from "maplibre-gl";
import maplibreWorkerUrl from "maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url";
import "maplibre-gl/dist/maplibre-gl.css";
import "./world.css";
import { trackEvent } from "@/analytics/Analytics";

import {
  BASE, C, DOT, LAYERS, MODES, RASTER_ORDER,
  daysAgo, esc, gibs, inatPhoto, makeStyle, nightPolygon, stamp, titleCase, wms,
} from "./layers";

import { ContextLayer, TYPE_COLOR, type ContextState } from "./Context";
import { WorldBoundary } from "./Boundary";
import { atlasLayerIntentMatches } from "./AtlasSearchIntentBridge";
import { replaceAtlasUrl } from "./atlasUrl";
import { setAtlasTheme } from "./atlasTheme";
import { familyHref } from "@/seo/ownership";
import { navigateWithIdentity } from "@/identity/identityClient";

/** A link to another 4PLANET site keeps the visitor signed in (4PLANET ID bridge). */
const followFamilyLink = (event: { preventDefault(): void; metaKey?: boolean; ctrlKey?: boolean; shiftKey?: boolean }, href: string) => {
  if (!/^https?:/.test(href) || event.metaKey || event.ctrlKey || event.shiftKey) return;
  event.preventDefault();
  void navigateWithIdentity(href);
};
import { LAYER_CATEGORIES, TIME_LABEL, layerPresentation, layerSource, layerStatusText } from "./layerPresentation";
import { describePoint, searchLoadedPlaces } from "./placeNames";
import { describeKnowledge, knowPlace, placeContext, searchPlaces as searchWorldPlaces } from "./placeKnowledge";

import { field } from "@/planet/types";
import { DEMO_WHALE_OBSERVATION, DEMO_WHALE_OCCURRENCE } from "@/data/demoWhaleOccurrence";
import { cinematicLanding, prefersReducedMotion, MOTION } from "@/earth/motion";
import { authorityOf, placeId as mkPlaceId, sourceKeyOf, typeOf } from "@/planet/ids";
import {
  binomialOf, occurrencesInWkt, searchTaxa, taxonOccurrences, taxonPhoto, taxonVernacular, topSpeciesInWkt,
} from "@/planet/connectors";
import { PLACES, bboxWkt, distanceKm, placeById, placeRadiusKm, searchPlaces } from "@/planet/places";
import {
  LIVING_SYSTEMS, MISSIONS, PRESSURES, SOLUTIONS,
  missionById, nodeById, pressureById, searchSystems, solutionById, systemById,
} from "@/planet/livingSystems";
import { CLASS_LABEL, CLASS_NAME, EMPTY_POOL, loadSignalPool, signalHeadline, signalsNear, timeAgo, timeAgoHuman } from "@/planet/signals";
import { useFollows } from "@/planet/follow";
import { EMPTY_WATCH, WATCH_WINDOW_DAYS, matchPool, matchTaxa } from "@/planet/watch";

/* ── URL state (V36) ─────────────────────────────────────────────────────── */

const readUrl = () => {
  const p = new URLSearchParams(window.location.search);
  const c = (p.get("c") || "").split(",").map(Number);
  return {
    mode: MODES.some((m) => m.id === p.get("m")) ? p.get("m") : "PLANET",
    // Premium default: start on the clean vector basemap so place names and
    // street-level detail are visible immediately. Blue Marble and the other
    // NASA rasters are opt-in overlays, never the default (they hid the labels
    // and pixelated on zoom). An explicit ?l= in the URL is still honoured.
    // ATLAS opens on Blue Marble (founder decision — we do not ship our own
    // world map for now). The label-ordering fix keeps place names on top of the
    // raster, and rasters are still opt-out via the layer console. Explicit ?l=
    // is honoured.
    on: (p.get("l") || "bluemarble").split(",").filter((x) => LAYERS.some((l) => l.id === x)),
    light: p.get("t") === "light",
    flat: p.get("p") === "2d",
    lens: ["EARTH", "NOW", "WATCH"].includes(p.get("lens")) ? p.get("lens") : "EARTH",
    focus: p.get("entity") || p.get("f") || "",
    zoom: Number(p.get("z")) || 2.1,
    center: c.length === 2 && !c.some(isNaN) ? c : [10, 25],
  };
};

const SIGNAL_COLOR = { FIRE_ACTIVITY: C.red, NATURAL_EVENT: C.amber, SEISMIC: C.white, SPECIES_OBSERVATION: C.green };

/* V36's three panel groups, in display order. Layers self-declare their group. */
const LAYER_GROUPS = ["EARTH", "LIFE", "SIGNALS"];

/* Keyboard activation for div-based interactive rows (Enter / Space). */
const onKeyActivate = (fn) => (e) => {
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fn(); }
};

/* One phone-sized work surface at a time; the same breakpoint the stylesheet uses. */
const isCompact = () => typeof window !== "undefined" && window.matchMedia("(max-width: 760px)").matches;

/* How much of a compact screen the resting sheet covers. Kept in step with
   --atlas-sheet-mid in world.css so the camera can frame a selection in the part
   of Earth that is actually visible above the sheet. */
const sheetCoverPx = () => (isCompact() ? Math.min(window.innerHeight * 0.46, 430) : 0);

/* Felt-scale threshold for the NOW feed. Below this, an earthquake is usually
   instrument-only; it stays available, one tap down, and is never dropped. */
const FELT_MAGNITUDE = 4.5;

/* Map selection → sentence-case speciesField helper for PLACE / HERE. */
const speciesFieldOf = (r) => (!r.ok
  ? field("SOURCE_UNAVAILABLE")
  : r.data.species.length ? field("LIVE", r.data) : field("NO_RECORDS"));

/* V40 P0: street-level vector basemap prototype. OpenFreeMap ships a fully
   MapLibre-compatible, no-cost vector style (OSM-derived, self-hostable) giving
   sharp roads / streets / place names / buildings / parks / water from planetary
   zoom to street level — the CARTO raster base (maxZoom 10) could not. 4PLANET's
   imagery + data overlays are added ON TOP via the existing registry, so basemap
   and science stay separate. On load failure the map falls back to raster. */
const VECTOR_STYLE = "https://tiles.openfreemap.org/styles/liberty";
/* ATLAS opens dark unless ?t=light. Opening on the light style and letting
   AtlasBasemapSync swap it a moment later meant every default visit loaded and
   parsed TWO complete basemap styles before the first usable frame. Start on the
   style the visitor will actually see; the sync then has nothing to do. */
const VECTOR_STYLE_DARK = "https://tiles.openfreemap.org/styles/dark";

/* MapLibre + third-party vector styles may render symbol glyphs from a world
   copy through the rear hemisphere. On the globe, 4PLANET therefore removes
   basemap symbol layers entirely; geometry and data layers remain. Mercator
   restores each layer's original visibility. This is deterministic, reversible
   and safer than trying to infer which rear-facing label should be visible. */
const setBackfaceSafeLabels = (m, flat, originalVisibility) => {
  const layers = m.getStyle()?.layers ?? [];
  layers.forEach((layer) => {
    if (layer.type !== "symbol" || String(layer.id).startsWith("4planet-")) return;
    if (!originalVisibility.has(layer.id)) {
      originalVisibility.set(layer.id, layer.layout?.visibility ?? "visible");
    }
    try {
      m.setLayoutProperty(layer.id, "visibility", flat ? originalVisibility.get(layer.id) : "none");
    } catch { /* style may be changing; next style.load reapplies */ }
  });
};

/* Watch items are two classes. These helpers read either without collapsing them. */
const watchItemId = (w) =>
  w.itemClass === "OBSERVATION" ? w.observation.id : w.signal.id;
const watchItemTitle = (w) =>
  w.itemClass === "OBSERVATION"
    ? (w.observation.occurrence.commonName || w.observation.taxon.label)
    : w.signal.title;
const watchItemSub = (w) =>
  w.itemClass === "OBSERVATION"
    ? `OBSERVATION RECORD · ${w.observation.occurrence.scientificName}`
    : `${w.signal.title}`;

function WorldInner() {
  const boxRef = useRef(null);
  const map = useRef(null);
  const timers = useRef({});
  const popup = useRef(null);
  const init = useRef(readUrl());

  // P0 (V38R): live refs so once-registered MapLibre handlers never call a stale
  // closure. Updated every render below.
  const askHereRef = useRef((_lng: number, _lat: number, _opts?: { label?: { name: string; kind: string; wikidata?: string } }) => {});
  const writeUrlRef = useRef(() => {});
  const dismissHintRef = useRef(() => {});
  const openEntityRef = useRef((_id: string) => {});
  const openLegacyRef = useRef((_p: any) => {});
  const searchRequestSeq = useRef(0);
  // V40 P0: has the user taken the camera since the last intentional focus?
  const userMoved = useRef(false);
  // The place/point the current context focused on, for the RECENTER control.
  const focusTarget = useRef<{ bbox?: number[]; lng?: number; lat?: number; zoom?: number } | null>(null);
  // V40: has the vector basemap failed (→ raster fallback)? And which overlays
  // are active right now, so any style reload can rehydrate them.
  const vectorFailed = useRef(false);
  const onRef = useRef<string[]>([]);
  const basemapSymbolVisibility = useRef(new Map());
  const flatRef = useRef(init.current.flat);

  /* ── V36 console state, preserved ─────────────────────────────────────── */
  const [ready, setReady] = useState(false);
  const lastFailureRepaint = useRef(0);
  const [mode, setMode] = useState(init.current.mode);
  const [on, setOn] = useState(() => Object.fromEntries(init.current.on.map((id) => [id, true])));
  const [light, setLight] = useState(init.current.light);
  // Publish the theme for the surfaces World does not render (atlasTheme.ts).
  useEffect(() => { setAtlasTheme(light ? "light" : "dark"); }, [light]);
  useEffect(() => () => setAtlasTheme(null), []);
  const [flat, setFlat] = useState(init.current.flat);
  flatRef.current = flat;
  const [status, setStatus] = useState({});
  const [busy, setBusy] = useState({});
  const [info, setInfo] = useState({});
  const [opacity, setOpacity] = useState({});
  const [collapsed, setCollapsed] = useState(true);
  const [satOffset, setSatOffset] = useState(2);
  const [sect, setSect] = useState({});
  const [utc, setUtc] = useState(new Date().toISOString().slice(11, 19) + "Z");
  const [copied, setCopied] = useState(false);

  /* ── v1 state ─────────────────────────────────────────────────────────── */
  const [lens, setLens] = useState(init.current.lens);
  const [ctx, setCtx] = useState<ContextState | null>(null);

  useEffect(() => {
    if (!ctx) return;
    trackEvent("atlas_object_opened", {
      product_area: "atlas",
      object_kind: ctx.kind,
      has_canonical_entity: !["COORDINATE", "LEGACY_POINT"].includes(ctx.kind),
    });
  }, [ctx]);
  const [pool, setPool] = useState(EMPTY_POOL);
  const [poolLoading, setPoolLoading] = useState(false);
  const poolRef = useRef(EMPTY_POOL);
  const poolPromiseRef = useRef(null);
  const [q, setQ] = useState("");
  const [taxaHits, setTaxaHits] = useState([]);
  const [taxaSearchFailed, setTaxaSearchFailed] = useState(false);
  const [searching, setSearching] = useState(false);
  const [open, setOpen] = useState(false);
  const [watchTaxaMatches, setWatchTaxaMatches] = useState([]);
  const [watchTaxaStatus, setWatchTaxaStatus] = useState("NOT_CHECKED");
  const [watchFailedTaxa, setWatchFailedTaxa] = useState([]);
  const [watchLoading, setWatchLoading] = useState(false);
  const [siteMenu, setSiteMenu] = useState(false);
  const [stripOpen, setStripOpen] = useState(false);
  // My Atlas is owned by AtlasSavedViews; World mirrors only whether it is open
  // so the dock can show it and so the surfaces stay mutually exclusive.
  const [myAtlasOpen, setMyAtlasOpen] = useState(false);
  // Compact sheets rest at a medium height and grow when the reader asks for depth.
  const [sheetFull, setSheetFull] = useState(false);
  const [smallQuakesOpen, setSmallQuakesOpen] = useState(false);
  // One quiet line that tells a first-time visitor how to begin. It leaves the
  // moment they do anything, and does not come back in the same session.
  const [hint, setHint] = useState(() => {
    try { return sessionStorage.getItem("4p:atlas-hint-seen") !== "1"; } catch { return true; }
  });
  const dismissHint = useCallback(() => {
    setHint(false);
    try { sessionStorage.setItem("4p:atlas-hint-seen", "1"); } catch { /* storage is optional */ }
  }, []);

  const { follows, toggle: toggleFollow, following } = useFollows();

  // One mobile work surface at a time. Context owns the screen when an object
  // is opened; stale search/layer/menu surfaces must not remain tappable behind it.
  useEffect(() => {
    if (!ctx) return;
    setOpen(false);
    setCollapsed(true);
    setSiteMenu(false);
    if (lens !== "EARTH") setLens("EARTH");
  }, [ctx]);

  // ONE SURFACE AUTHORITY. Search, Context, Layers, Now/Watch, the site menu and
  // My Atlas are mutually exclusive work surfaces. World owns five of them as
  // React state; My Atlas and Time are separate components that speak the
  // existing "4p:atlas-surface-open" contract. World announces every surface it
  // opens (so they close) and closes its own when one of them opens.
  const surface = open ? "SEARCH"
    : ctx ? "CONTEXT"
    : !collapsed ? "LAYERS"
    : lens !== "EARTH" ? lens
    : siteMenu ? "MENU"
    : myAtlasOpen ? "MY_ATLAS"
    : "REST";

  useEffect(() => {
    if (surface === "REST" || surface === "MY_ATLAS") return;
    window.dispatchEvent(new CustomEvent("4p:atlas-surface-open", { detail: surface }));
  }, [surface]);

  useEffect(() => {
    const onSurface = (event) => {
      const detail = event?.detail;
      if (detail === "MY_ATLAS") {
        setMyAtlasOpen(true);
        setOpen(false); setCollapsed(true); setCtx(null); setSiteMenu(false); setLens("EARTH");
      } else if (detail) {
        setMyAtlasOpen(false);
      }
    };
    const onClosed = () => setMyAtlasOpen(false);
    window.addEventListener("4p:atlas-surface-open", onSurface);
    window.addEventListener("4p:atlas-my-atlas-closed", onClosed);
    return () => {
      window.removeEventListener("4p:atlas-surface-open", onSurface);
      window.removeEventListener("4p:atlas-my-atlas-closed", onClosed);
    };
  }, []);

  // A new object or surface always starts at the resting sheet height.
  useEffect(() => { setSheetFull(false); }, [surface, ctx?.kind]);
  useEffect(() => { if (surface !== "REST") dismissHint(); }, [surface, dismissHint]);

  // Escape closes the surface in front. Predictable, and it never traps focus.
  useEffect(() => {
    const onKey = (event) => {
      if (event.key !== "Escape") return;
      if (open) { setOpen(false); setQ(""); (document.activeElement as HTMLElement | null)?.blur?.(); }
      else if (ctx) { setCtx(null); }
      else if (!collapsed) { setCollapsed(true); }
      else if (lens !== "EARTH") { setLens("EARTH"); }
      else if (siteMenu) { setSiteMenu(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, ctx, collapsed, lens, siteMenu]);

  // Updating a clock once per second re-rendered the entire ATLAS React tree even
  // while the source strip was closed. Only run a coarse clock when it is visible.
  useEffect(() => {
    if (!stripOpen) return;
    const tick = () => setUtc(new Date().toISOString().slice(11, 19) + "Z");
    tick();
    const t = window.setInterval(tick, 30000);
    return () => window.clearInterval(t);
  }, [stripOpen]);

  /* ── ONE SIGNAL POOL, ON DEMAND ─────────────────────────────────────────
     NO INVISIBLE WORK: EONET + USGS are not fetched simply because ATLAS opened (mobile closure contract).
     NOW/WATCH or a place/coordinate question earns the network work. */
  const publishSignalPool = useCallback((nextPool) => {
    poolRef.current = nextPool;
    setPool(nextPool);
    return nextPool;
  }, []);

  const ensureSignalPool = useCallback(async () => {
    if (poolRef.current.fetchedAt) return poolRef.current;
    if (poolPromiseRef.current) return poolPromiseRef.current;
    setPoolLoading(true);
    const pending = loadSignalPool()
      .then(publishSignalPool)
      .finally(() => {
        poolPromiseRef.current = null;
        setPoolLoading(false);
      });
    poolPromiseRef.current = pending;
    return pending;
  }, [publishSignalPool]);

  useEffect(() => {
    if (lens === "EARTH") return;
    let alive = true;
    ensureSignalPool();
    const t = window.setInterval(async () => {
      const next = await loadSignalPool();
      if (alive) publishSignalPool(next);
    }, 5 * 60 * 1000);
    return () => { alive = false; window.clearInterval(t); };
  }, [lens, ensureSignalPool, publishSignalPool]);

  // Stable id for the open context, written to the URL as ?entity= so a deep
  // link (and the cross-product returnTo) can reopen it. Undefined-safe: any
  // context without a canonical id contributes no entity rather than throwing.
  const idOfCtx = (c: ContextState | null): string => {
    if (!c) return "";
    switch (c.kind) {
      case "OBSERVATION": return c.observation?.taxon?.id || c.observation?.id || "";
      case "TAXON": return c.ref?.id || "";
      case "PLACE": return c.place?.id || "";
      case "LIVING_SYSTEM": return c.system?.id || "";
      case "SIGNAL": return c.signal?.id || "";
      case "MISSION": return c.mission?.id || "";
      case "PRESSURE": return c.pressure?.id || "";
      case "SOLUTION": return c.solution?.id || "";
      default: return "";
    }
  };

  const writeUrl = useCallback((patch = {}) => {
    const m = map.current; if (!m) return;
    const current = new URLSearchParams(window.location.search);
    const p = new URLSearchParams();
    p.set("m", patch.mode ?? mode);
    const src = patch.on ?? on;
    const act = Object.keys(src).filter((k) => src[k]);
    if (act.length) p.set("l", act.join(","));
    if (patch.light ?? light) p.set("t", "light");
    if (patch.flat ?? flat) p.set("p", "2d");
    const ln = patch.lens ?? lens;
    if (ln !== "EARTH") p.set("lens", ln);
    const f = "focus" in patch ? patch.focus : ctx ? idOfCtx(ctx) : "";
    if (f) p.set("entity", f);
    ["journey", "record"].forEach((key) => {
      const value = current.get(key);
      if (value) p.set(key, value);
    });
    const c = m.getCenter();
    p.set("z", m.getZoom().toFixed(2));
    p.set("c", `${c.lng.toFixed(2)},${c.lat.toFixed(2)}`);
    replaceAtlasUrl(`${window.location.pathname}?${p.toString()}${window.location.hash}`);
  }, [mode, on, light, flat, lens, ctx]);

  // The address bar follows what is open, immediately — not only after the next
  // camera move — so a link copied the moment a place or species opens is right.
  const openIdentity = idOfCtx(ctx);
  useEffect(() => { writeUrlRef.current(); }, [openIdentity]);

  /* ── V36 layer machinery, preserved verbatim in behaviour ─────────────── */

  const rasterBefore = (id) => {
    const m = map.current;
    const i = RASTER_ORDER.indexOf(id);
    for (let j = i + 1; j < RASTER_ORDER.length; j++) if (m.getLayer(RASTER_ORDER[j])) return RASTER_ORDER[j];
    // Insert rasters BENEATH the basemap's place-name labels so names are never
    // hidden. The raster-fallback style uses a layer literally named "lbls"; the
    // vector basemap (OpenFreeMap) uses symbol layers with other names, so find
    // the first symbol layer and anchor above it.
    if (m.getLayer("lbls")) return "lbls";
    try {
      const layers = m.getStyle().layers || [];
      const firstSymbol = layers.find((ly) => ly.type === "symbol");
      if (firstSymbol) return firstSymbol.id;
    } catch { /* style not ready */ }
    return undefined;
  };

  const drawPoints = (id, label, srcName, note, rows, colorFallback, rFallback) => {
    const m = map.current; if (!m) return;
    const fc = {
      type: "FeatureCollection",
      features: rows.map((p) => ({
        type: "Feature",
        geometry: { type: "Point", coordinates: [p.lon, p.lat] },
        properties: {
          html: p.html, col: p.col || colorFallback, size: p.size || rFallback,
          sppKey: p.sppKey || "", aphia: p.aphia || "", eid: p.eid || "",
        },
      })),
    };
    if (m.getSource(id)) { m.getSource(id).setData(fc); return; }
    m.addSource(id, { type: "geojson", data: fc });
    // Visible dot. Radius grows a little as you zoom in so points stay easy to
    // read at street level without swamping the globe view.
    m.addLayer({
      id, type: "circle", source: id,
      paint: {
        "circle-radius": [
          "interpolate", ["linear"], ["zoom"],
          2, ["*", ["get", "size"], 0.9],
          6, ["get", "size"],
          12, ["*", ["get", "size"], 1.8],
        ],
        "circle-color": ["get", "col"], "circle-opacity": 0.82,
        "circle-stroke-width": 1.25, "circle-stroke-color": ["get", "col"], "circle-stroke-opacity": 0.9,
      },
    });
    // Invisible, larger HIT layer under the visible dot so taps/clicks land even
    // when the point is small — a real premium/mobile ergonomics fix. It shares
    // the same source and carries the click; it never paints anything visible.
    const hitId = `${id}__hit`;
    m.addLayer({
      id: hitId, type: "circle", source: id,
      paint: {
        "circle-radius": [
          "interpolate", ["linear"], ["zoom"],
          2, ["max", ["+", ["get", "size"], 8], 12],
          12, ["max", ["+", ["get", "size"], 16], 22],
        ],
        "circle-color": "#000", "circle-opacity": 0.01,
      },
    }, id); // insert the hit layer BELOW the visible dot
    // Pointer cursor over tappable points.
    m.on("mouseenter", hitId, () => { m.getCanvas().style.cursor = "pointer"; });
    m.on("mouseleave", hitId, () => { m.getCanvas().style.cursor = ""; });

    const onPointClick = (e) => {
      const f = e.features && e.features[0]; if (!f) return;

      // v1: a point that carries a canonical id opens the shared context layer
      // instead of a dead-end popup. That is the entire difference between a map
      // and an interface.
      const eid = f.properties.eid;
      if (eid) { openEntityRef.current(eid); return; }

      // V39.1 Scope 01 / V40: a legacy point routes into the ONE shared context
      // surface as a display envelope — same world, one surface, no invented
      // semantics — carrying the source-aware detail the old popup showed.
      const col = f.properties.col;
      const html = f.properties.html || "";
      // Names are said as a person says them: the binomial, never its citation
      // ("Hydroprogne caspia", not "Hydroprogne caspia (Pallas, 1770)").
      const rawSci = (html.match(/<span class="lat">([^<]+)/) || [])[1];
      const rawCommon = (html.match(/<b class="nm">([^<]+)/) || html.match(/<b>([^<]+)/) || [])[1];
      const sciName = rawSci ? (binomialOf(rawSci) || rawSci) : undefined;
      const commonCandidate = rawCommon && /\(.*\d{4}.*\)|,\s*\d{4}/.test(rawCommon) ? binomialOf(rawCommon) || rawCommon : rawCommon;
      const commonName = commonCandidate;
      const observedDate = (html.match(/<div class="when">([^<]+)/) || [])[1];
      const coords = (f.geometry && f.geometry.coordinates) || [e.lngLat.lng, e.lngLat.lat];
      const planetary = /ISS|SEISMIC|QUAKE|EARTHQUAKE/i.test(label);
      openLegacyRef.current({
        title: commonName || sciName || label,
        sub: label,
        scientificName: sciName,
        commonName: commonName && commonName !== sciName ? commonName : undefined,
        observedDate,
        lat: coords[1],
        lng: coords[0],
        sourceLabel: srcName,
        previewHtml: html,
        gbifKey: f.properties.sppKey,
        aphiaId: f.properties.aphia,
        planetaryContext: planetary,
        accent: col,
      });
    };
    // Bind to the visible dot AND the larger invisible hit layer.
    m.on("click", id, onPointClick);
    m.on("click", hitId, onPointClick);
    m.on("mouseenter", id, () => { m.getCanvas().style.cursor = "pointer"; });
    m.on("mouseleave", id, () => { m.getCanvas().style.cursor = ""; });
  };

  const addLayer = useCallback(async (l, silent) => {
    const m = map.current; if (!m || !l) return;
    if (l.kind === "shade") {
      if (m.getSource("shade")) return;
      m.addSource("shade", { type: "geojson", data: nightPolygon() });
      m.addLayer({ id: "shade", type: "fill", source: "shade", paint: { "fill-color": "#02030a", "fill-opacity": 0.42 } },
        m.getLayer("lbls") ? "lbls" : undefined);
      if (!timers.current.shade) timers.current.shade = setInterval(() => {
        const s = map.current && map.current.getSource("shade");
        if (s) s.setData(nightPolygon());
      }, 60000);
      setStatus((st) => ({ ...st, shade: "LIVE" }));
      return;
    }
    if (l.kind === "planned") { setStatus((st) => ({ ...st, [l.id]: "PLANNED" })); return; }
    if (l.kind === "raster") {
      if (m.getSource(l.id)) return;
      const s = { type: "raster", tiles: [l.tiles(satOffset)], tileSize: 256, attribution: l.attr };
      if (!l.wms) s.maxzoom = l.maxzoom;
      m.addSource(l.id, s);
      m.addLayer({ id: l.id, type: "raster", source: l.id, paint: { "raster-opacity": opacity[l.id] ?? l.opacity } }, rasterBefore(l.id));
      setStatus((st) => ({ ...st, [l.id]: "ON" }));
      return;
    }
    if (!silent) { setBusy((s) => ({ ...s, [l.id]: true })); setStatus((s) => ({ ...s, [l.id]: DOT + DOT + DOT })); }
    let rows = [];
    try { rows = await l.load(); }
    catch { setStatus((s) => ({ ...s, [l.id]: "OFFLINE" })); setBusy((s) => ({ ...s, [l.id]: false })); return; }
    drawPoints(l.id, l.label, l.src, l.note, rows, l.color, l.r);
    if (!silent) { setStatus((s) => ({ ...s, [l.id]: `${rows.length} ${DOT} ${stamp()}` })); setBusy((s) => ({ ...s, [l.id]: false })); }
    if (l.kind === "live" && l.every && !timers.current[l.id]) {
      timers.current[l.id] = setInterval(async () => {
        try {
          const r = await l.load();
          drawPoints(l.id, l.label, l.src, l.note, r, l.color, l.r);
          setStatus((s) => ({ ...s, [l.id]: `${r.length} ${DOT} ${stamp()}` }));
        } catch { /* keep last good frame */ }
      }, l.every);
    }
  }, [satOffset, opacity]);

  const removeLayer = (l) => {
    const m = map.current; if (!m) return;
    if (timers.current[l.id]) { clearInterval(timers.current[l.id]); delete timers.current[l.id]; }
    if (m.getLayer(`${l.id}__hit`)) m.removeLayer(`${l.id}__hit`); // remove the tap target too
    if (m.getLayer(l.id)) m.removeLayer(l.id);
    if (m.getSource(l.id)) m.removeSource(l.id);
  };

  /* ── THE WORLD RESPONDS ────────────────────────────────────────────────── */

  /** Paint an arbitrary set of canonical objects onto Earth as a focus layer. */
  const paintFocus = (id, rows, color, radius = 4) => {
    const m = map.current; if (!m) return;
    drawPoints(id, "FOCUS", "4PLANET", null, rows, color, radius);
    if (m.getLayer(id)) m.moveLayer(id);
  };

  // A gentle "breathing" pulse on the focus marker so the eye lands on the
  // record. Honours reduced-motion (no pulse), is BOUNDED (a small number of
  // breaths, then rests — never mutates paint every frame forever), and cleans
  // itself up on unmount or when a new landing starts.
  const pulseRaf = useRef<number | null>(null);
  const stopFocusPulse = () => {
    if (pulseRaf.current) { cancelAnimationFrame(pulseRaf.current); pulseRaf.current = null; }
  };
  const startFocusPulse = () => {
    const m = map.current; if (!m) return;
    stopFocusPulse();
    if (prefersReducedMotion()) return;
    const t0 = performance.now();
    const totalMs = MOTION.pulseBreaths * MOTION.pulsePeriodMs;
    const tick = (t: number) => {
      const mm = map.current;
      if (!mm || !mm.getLayer("focus")) { pulseRaf.current = null; return; }
      const elapsed = t - t0;
      if (elapsed >= totalMs) {
        // Bounded: settle to a calm resting marker and STOP the rAF loop.
        try {
          mm.setPaintProperty("focus", "circle-radius", ["get", "size"]);
          mm.setPaintProperty("focus", "circle-stroke-width", 1);
          mm.setPaintProperty("focus", "circle-stroke-opacity", 0.9);
        } catch { /* layer swapped out */ }
        pulseRaf.current = null;
        return;
      }
      const phase = (Math.sin((elapsed / MOTION.pulsePeriodMs) * Math.PI * 2) + 1) / 2; // 0..1
      try {
        mm.setPaintProperty("focus", "circle-radius", ["+", ["get", "size"], phase * 5]);
        mm.setPaintProperty("focus", "circle-stroke-width", 1 + phase * 3);
        mm.setPaintProperty("focus", "circle-stroke-opacity", 0.9 - phase * 0.55);
      } catch { /* layer swapped out mid-frame */ }
      pulseRaf.current = requestAnimationFrame(tick);
    };
    pulseRaf.current = requestAnimationFrame(tick);
  };
  // In-flight cinematic landing, so we can cancel it on interaction/unmount.
  const landingRef = useRef<{ cancel: () => void } | null>(null);
  const panelTimer = useRef<number | null>(null);
  const cancelLanding = () => {
    if (landingRef.current) { landingRef.current.cancel(); landingRef.current = null; }
    if (panelTimer.current) { clearTimeout(panelTimer.current); panelTimer.current = null; }
  };
  useEffect(() => () => { stopFocusPulse(); cancelLanding(); }, []);

  const clearFocus = (id) => {
    const m = map.current; if (!m) return;
    if (m.getLayer(`${id}__hit`)) m.removeLayer(`${id}__hit`);
    if (m.getLayer(id)) m.removeLayer(id);
    if (m.getSource(id)) m.removeSource(id);
  };

  const fitRows = (rows) => {
    const m = map.current; if (!m || !rows.length) return;
    const b = new maplibregl.LngLatBounds();
    rows.forEach((r) => b.extend([r.lon, r.lat]));
    const cover = sheetCoverPx();
    const padding = cover ? { top: 96, bottom: cover + 24, left: 28, right: 28 } : { top: 90, bottom: 90, left: 460, right: 90 };
    try { m.fitBounds(b, { padding, maxZoom: 6, duration: 1400 }); } catch { /* single point */ }
  };

  /* ── OPEN: the one function every lens routes through ──────────────────── */

  const openTaxon = useCallback(async (hit) => {
    const ref = {
      id: hit.id, type: "TAXON",
      label: hit.commonName || hit.scientificName,
      sub: hit.scientificName,
    };
    setCtx({ kind: "TAXON", ref, photo: null, occ: field("LOADING") });
    setOpen(false);
    setQ("");

    const [occ, photo] = await Promise.all([
      taxonOccurrences(hit.gbifKey, 400),
      taxonPhoto(hit.scientificName),
    ]);

    if (!occ.ok) {
      setCtx((c) => (c && c.kind === "TAXON" && c.ref.id === ref.id
        ? { ...c, photo, occ: field("SOURCE_UNAVAILABLE") } : c));
      return;
    }

    const rows = occ.data.rows.map((o) => ({
      lon: o.lng, lat: o.lat, col: C.green, size: 3.6, sppKey: hit.gbifKey,
      html: `<b class="nm">${esc(ref.label)}</b><br/><span class="lat">${esc(o.scientificName)}</span>${o.eventDate ? `<div class="when">${esc(o.eventDate)}</div>` : ""}`,
    }));

    paintFocus("focus", rows, C.green, 3.6);
    fitRows(rows);

    setCtx((c) => (c && c.kind === "TAXON" && c.ref.id === ref.id
      ? { ...c, photo, occ: occ.data.rows.length
          ? field("LIVE", { rows: occ.data.rows, total: occ.data.total })
          : field("NO_RECORDS") }
      : c));
  }, []);

  const openPlace = useCallback(async (place) => {
    const m = map.current;
    setOpen(false);
    setQ("");
    setCtx({ kind: "PLACE", place, life: field("LOADING"), species: field("LOADING"), signals: field("LOADING") });

    if (m) {
      // V40 P0: this is the ONE intentional focus for this place. Record it for
      // RECENTER, and reset the ownership flag — from here the camera is the
      // user's until they open something else.
      const [w, s, e, n] = place.bbox;
      focusTarget.current = { bbox: [w, s, e, n], lng: place.lng, lat: place.lat, zoom: place.zoom };
      userMoved.current = false;
      // Frame the place in the part of Earth the sheet leaves visible, so the
      // interface never covers the thing being explored. fitBounds padding is
      // per-call; it does not become a persistent camera offset.
      const cover = sheetCoverPx();
      const padding = cover ? { top: 96, bottom: cover + 24, left: 28, right: 28 } : { top: 80, bottom: 80, left: 460, right: 80 };
      try { m.fitBounds([[w, s], [e, n]], { padding, duration: 1600, maxZoom: 16 }); }
      catch { m.flyTo({ center: [place.lng, place.lat], zoom: place.zoom, duration: 1600 }); }
    }

    // Signals are earned by this explicit place question, not preloaded on ATLAS open.
    // The species names arrive on their own so the first read is not held back by
    // the slower sample that paints record points on the map.
    topSpeciesInWkt(bboxWkt(place)).then((top) => {
      setCtx((c) => (c && c.kind === "PLACE" && c.place.id === place.id ? { ...c, species: speciesFieldOf(top) } : c));
    });
    const [life, activePool] = await Promise.all([
      occurrencesInWkt(bboxWkt(place), { limit: 300 }),
      ensureSignalPool(),
    ]);
    const near = signalsNear(activePool, place, placeRadiusKm(place));
    const signalSourcesUnavailable = ["eonet", "usgs"].some((id) => activePool.status[id] === "SOURCE_UNAVAILABLE");
    const sigField = near.length
      ? field("LIVE", near)
      : signalSourcesUnavailable ? field("SOURCE_UNAVAILABLE") : field("NO_RECORDS");

    if (life.ok) {
      const rows = life.data.rows.map((o) => ({
        lon: o.lng, lat: o.lat, col: C.green, size: 3.2,
        html: `<b class="nm">${esc(o.commonName || o.scientificName)}</b><br/><span class="lat">${esc(o.scientificName)}</span>${o.eventDate ? `<div class="when">${esc(o.eventDate)}</div>` : ""}`,
      }));
      // Paint the records, but NEVER move the camera here — the user may already
      // be panning. Focus points only; no fit. (V40 P0.)
      paintFocus("focus", rows, C.green, 3.2);
    }

    setCtx((c) => (c && c.kind === "PLACE" && c.place.id === place.id
      ? {
          ...c,
          signals: sigField,
          life: !life.ok
            ? field("SOURCE_UNAVAILABLE")
            : life.data.total
              ? field("LIVE", { total: life.data.total, names: life.data.names })
              : field("NO_RECORDS"),
        }
      : c));
  }, [ensureSignalPool]);

  // V40 P0: RECENTER / FOCUS SELECTED — the user's escape hatch. The camera is
  // never locked to context; instead this puts it back on demand.
  const recenter = useCallback(() => {
    const m = map.current; const t = focusTarget.current; if (!m || !t) return;
    userMoved.current = false;
    if (t.bbox) {
      const [w, s, e, n] = t.bbox;
      const cover = sheetCoverPx();
      const padding = cover ? { top: 96, bottom: cover + 24, left: 28, right: 28 } : { top: 80, bottom: 80, left: 460, right: 80 };
      try { m.fitBounds([[w, s], [e, n]], { padding, duration: 900, maxZoom: 16 }); return; }
      catch { /* fall through */ }
    }
    if (t.lng != null && t.lat != null) {
      m.flyTo({ center: [t.lng, t.lat], zoom: t.zoom ?? Math.max(m.getZoom(), 5), duration: 900 });
    }
  }, []);

  const openSystem = useCallback(async (system) => {
    setOpen(false); setQ("");
    setCtx({ kind: "LIVING_SYSTEM", system });

    // A living system is not a point, but it is somewhere. Show where it lives.
    const places = (system.placeIds || []).map(placeById).filter(Boolean);
    if (places.length) {
      const rows = places.map((p) => ({
        lon: p.lng, lat: p.lat, col: TYPE_COLOR.LIVING_SYSTEM, size: 8, eid: p.id,
        html: `<b>${esc(p.name)}</b>`,
      }));
      paintFocus("focus", rows, TYPE_COLOR.LIVING_SYSTEM, 8);
      fitRows(rows);
    } else {
      clearFocus("focus");
    }
  }, []);

  const openSignal = useCallback((signal) => {
    const m = map.current;
    setOpen(false);
    setCtx({ kind: "SIGNAL", signal });
    focusTarget.current = { lng: signal.lng, lat: signal.lat, zoom: Math.max(m?.getZoom() ?? 4.2, 4.2) };
    userMoved.current = false;
    if (m) m.flyTo({ center: [signal.lng, signal.lat], zoom: Math.max(m.getZoom(), 4.2), duration: 1400, offset: [0, -sheetCoverPx() / 2] });
  }, []);

  // V39.1 Scope 01 / V40: open a legacy map point in the one shared context
  // surface. No camera move — the world stays exactly where it is — but we record
  // the point so RECENTER can bring the user to it on demand.
  const openLegacy = useCallback((payload) => {
    setOpen(false);
    setCtx({ kind: "LEGACY_POINT", ...payload });
    // A species record arrives with only its scientific name. Its English name is
    // looked up once and replaces the title when the source has one.
    const titleIsScientific = !payload?.commonName || payload.commonName === payload.scientificName;
    if (payload?.gbifKey && titleIsScientific) {
      void taxonVernacular(Number(payload.gbifKey)).then((english) => {
        if (!english) return;
        setCtx((current) => current && current.kind === "LEGACY_POINT" && current.gbifKey === payload.gbifKey && current.lat === payload.lat && current.lng === payload.lng
          ? { ...current, title: english, commonName: english }
          : current);
      }).catch(() => { /* the scientific name stays the title */ });
    }
    if (payload && payload.lng != null && payload.lat != null) {
      focusTarget.current = { lng: payload.lng, lat: payload.lat, zoom: Math.max(map.current?.getZoom() ?? 6, 6) };
    }
  }, []);

  const openPressure = useCallback((p) => {
    setOpen(false);
    setCtx({ kind: "PRESSURE", pressure: p });
    // Show the places where the systems it affects are represented.
    const places = p.affects
      .filter((id) => typeOf(id) === "LIVING_SYSTEM")
      .flatMap((id) => systemById(id)?.placeIds || [])
      .map(placeById)
      .filter(Boolean);
    if (places.length) {
      const rows = places.map((pl) => ({
        lon: pl.lng, lat: pl.lat, col: C.red, size: 7, eid: pl.id,
        html: `<b>${esc(pl.name)}</b>`,
      }));
      paintFocus("focus", rows, C.red, 7);
      fitRows(rows);
    }
  }, []);

  const askHere = useCallback(async (lng, lat, opts?: { label?: { name: string; kind: string; wikidata?: string } }) => {
    setOpen(false);
    // WHERE IS THIS? Two answers, both honest about distance: the basemap labels
    // already in memory (instant), and the open place files for this part of the
    // planet (GeoNames + Natural Earth, one small file) — country, region, sea,
    // landscape, nearest town. Then, from our own server: the ecoregion and a
    // Wikipedia lead for the most specific named area.
    const where = describePoint(map.current, lng, lat);
    const label = opts?.label;
    const same = (c) => c && c.kind === "COORDINATE" && c.lat === lat && c.lng === lng;
    setCtx({ kind: "COORDINATE", lat, lng, where, label, known: { status: "LOADING" }, context: null, life: field("LOADING"), species: field("LOADING"), signals: field("LOADING") });
    void knowPlace(lat, lng).then((known) => {
      if (known.status !== "OK") {
        setCtx((c) => (same(c) ? { ...c, known: { status: "UNAVAILABLE" } } : c));
        return;
      }
      setCtx((c) => (same(c) ? { ...c, known: { status: "OK", value: known.value } } : c));
      const described = describeKnowledge(known.value);
      const ids = [...new Set([label?.wikidata, ...described.specificWikidata].filter(Boolean))];
      void placeContext(known.value, ids, label ? undefined : described.town).then((context) => {
        setCtx((c) => (same(c) ? { ...c, context } : c));
      });
    });
    focusTarget.current = { lng, lat, zoom: Math.max(map.current?.getZoom?.() ?? 4, 4) };

    const zoom = Number(map.current?.getZoom?.() ?? 5);
    const nearbyRadiusKm = Math.max(30, Math.min(220, Math.round(900 / Math.pow(2, Math.max(0, zoom - 3)))));
    const d = 0.35;
    const wkt = `POLYGON((${lng - d} ${lat - d},${lng + d} ${lat - d},${lng + d} ${lat + d},${lng - d} ${lat + d},${lng - d} ${lat - d}))`;
    const [top, activePool] = await Promise.all([
      topSpeciesInWkt(wkt),
      ensureSignalPool(),
    ]);
    const near = signalsNear(activePool, { lat, lng }, nearbyRadiusKm);
    const signalSourcesUnavailable = ["eonet", "usgs"].some((id) => activePool.status[id] === "SOURCE_UNAVAILABLE");
    const sigField = near.length
      ? field("LIVE", near)
      : signalSourcesUnavailable ? field("SOURCE_UNAVAILABLE") : field("NO_RECORDS");

    setCtx((c) => (c && c.kind === "COORDINATE" && c.lat === lat && c.lng === lng
      ? {
          ...c,
          signals: sigField,
          species: speciesFieldOf(top),
          life: !top.ok
            ? field("SOURCE_UNAVAILABLE")
            : top.data.total
              ? field("LIVE", { total: top.data.total, names: top.data.species.map((x) => x.scientificName) })
              : field("NO_RECORDS"),
        }
      : c));
  }, [ensureSignalPool]);

  /** Resolve ANY canonical id and open it. This is what makes the world one world. */
  const openEntity = useCallback(async (id) => {
    const t = typeOf(id);
    if (t === "PLACE") { const p = placeById(id); if (p) openPlace(p); return; }
    if (t === "LIVING_SYSTEM") { const s = systemById(id); if (s) openSystem(s); return; }
    if (t === "PRESSURE") { const p = pressureById(id); if (p) openPressure(p); return; }
    if (t === "SOLUTION") { const s = solutionById(id); if (s) { setOpen(false); setCtx({ kind: "SOLUTION", solution: s }); } return; }
    if (t === "MISSION") { const m = missionById(id); if (m) { setOpen(false); setCtx({ kind: "MISSION", mission: m }); } return; }
    if (t === "SIGNAL") {
      const activePool = await ensureSignalPool();
      const s = activePool.signals.find((x) => x.id === id);
      if (s) openSignal(s);
      return;
    }
    if (t === "OBSERVATION") {
      const w = watchTaxaMatches.find((x) => x.observation?.id === id);
      if (w?.observation) { setOpen(false); setCtx({ kind: "OBSERVATION", observation: w.observation }); }
      return;
    }
    if (t === "TAXON") {
      const authority = authorityOf(id);
      const key = sourceKeyOf(id);
      const n = nodeById(id);
      // A seeded node already knows its names. Skip the round trip.
      if (n) { openTaxon({ id, gbifKey: key, scientificName: n.sub || n.label, commonName: n.label }); return; }
      // P1 (V38R): the id format claims an authority, so honour it. Occurrence
      // resolution in v1 is GBIF-shaped only; a non-GBIF taxon id must not be
      // silently sent through the GBIF resolver as if it were a GBIF key.
      if (authority !== "gbif") {
        setOpen(false);
        setCtx({
          kind: "TAXON",
          ref: { id, type: "TAXON", label: key, sub: authority.toUpperCase() },
          photo: null,
          occ: field(
            "NOT_CHECKED",
            null,
            `This taxon is identified by ${authority.toUpperCase()}. 4PLANET's occurrence resolver is GBIF-only in v1, so it has not queried records for this id rather than pretend a ${authority.toUpperCase()} id is a GBIF key.`,
          ),
        });
        return;
      }
      const vern = await taxonVernacular(key);
      openTaxon({ id, gbifKey: key, scientificName: vern || key, commonName: vern });
      return;
    }
    // COORDINATE has no registry entry to open; it is created by a map click only.
    // UNKNOWN / FUNCTION / HUMAN_SYSTEM graph nodes have no map geometry and no
    // source record, so they are shown inside the relationship chain, never
    // opened as a standalone spatial object. Doing nothing here is the honest
    // behaviour — better than inventing a coordinate.
  }, [openPlace, openSystem, openPressure, openSignal, openTaxon, ensureSignalPool, watchTaxaMatches]);

  /* ── SEARCH THE LIVING PLANET_ ─────────────────────────────────────────── */

  useEffect(() => {
    const text = q.trim();
    const requestId = ++searchRequestSeq.current;
    if (text.length < 3) { setTaxaHits([]); setSearching(false); setTaxaSearchFailed(false); return; }
    setSearching(true);
    const t = window.setTimeout(async () => {
      const r = await searchTaxa(text);
      if (requestId !== searchRequestSeq.current) return;
      // P0: a GBIF failure is not "no life matched". Also collapse provider
      // synonyms that resolve to the same scientific name so mobile search does
      // not show three visually identical Orca rows.
      setTaxaSearchFailed(!r.ok);
      if (r.ok) {
        const seen = new Set<string>();
        const unique = r.data.filter((hit) => {
          const key = String(hit.scientificName || hit.id).trim().toLowerCase();
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        setTaxaHits(unique);
      } else {
        setTaxaHits([]);
      }
      setSearching(false);
    }, 300);
    return () => window.clearTimeout(t);
  }, [q]);

  const placeHits = useMemo(() => searchPlaces(q), [q]);
  const systemHits = useMemo(() => searchSystems(q), [q]);
  const layerHits = useMemo(() => atlasLayerIntentMatches(q), [q]);
  // Place names visible on the basemap right now. Not a geocoder: it only knows
  // the tiles already loaded, and the result group says so. Curated places win.
  const mapPlaceHits = useMemo(() => {
    if (!open) return [];
    const curated = new Set(placeHits.map((p) => p.name.toLowerCase()));
    return searchLoadedPlaces(map.current, q).filter((hit) => !curated.has(hit.name.toLowerCase()));
  }, [q, open, placeHits]);
  // Places worldwide: towns of 5,000+ people, every capital, countries, regions,
  // seas, landscapes, lakes and peaks — from the open place index on this site.
  const [worldHits, setWorldHits] = useState([]);
  const [worldSearchFailed, setWorldSearchFailed] = useState(false);
  useEffect(() => {
    const text = q.trim();
    if (text.length < 2) { setWorldHits([]); setWorldSearchFailed(false); return; }
    let alive = true;
    const t = window.setTimeout(async () => {
      const hits = await searchWorldPlaces(text, 6);
      if (!alive) return;
      setWorldSearchFailed(hits === null);
      const curated = new Set(placeHits.map((p) => p.name.toLowerCase()));
      setWorldHits((hits ?? []).filter((h) => !curated.has(h.name.toLowerCase())));
    }, 120);
    return () => { alive = false; window.clearTimeout(t); };
  }, [q, placeHits]);
  const shownMapPlaceHits = mapPlaceHits.filter((hit) => !worldHits.some((w) => w.name.toLowerCase() === hit.name.toLowerCase()));
  const hasResults = placeHits.length || worldHits.length || shownMapPlaceHits.length || systemHits.length || taxaHits.length || layerHits.length;

  const WORLD_ZOOM = { Country: 4.2, Ocean: 2.6, Sea: 4.6, Gulf: 5.5, Bay: 7, Strait: 6.5, Fjord: 8, Sound: 8, Channel: 7, Lagoon: 8,
    Desert: 4.6, "Mountain range": 5.6, Plateau: 5.6, Island: 7, "Island group": 6, Peninsula: 6, Basin: 5, Plain: 5.4, Delta: 7, Coast: 6,
    Capital: 9.5, City: 9.5, Town: 10.5, Mountain: 10, Landmark: 10, Depression: 9, Lake: 8, Reservoir: 9, "Salt lake": 8 };
  const openWorldPlace = (hit) => {
    const m = map.current; if (!m) return;
    setOpen(false); setQ("");
    const zoom = WORLD_ZOOM[hit.kind] ?? (/state|province|county|region|department|district/i.test(hit.kind) ? 6.5 : 7);
    userMoved.current = false;
    m.flyTo({ center: [hit.lon, hit.lat], zoom, duration: 1700, offset: [0, -sheetCoverPx() / 2] });
    m.once("moveend", () => askHereRef.current(hit.lon, hit.lat, { label: { name: hit.name, kind: hit.kind, wikidata: hit.wikidata } }));
  };

  const openMapPlace = (hit) => {
    const m = map.current; if (!m) return;
    setOpen(false); setQ("");
    const zoom = Math.max(m.getZoom(), hit.placeClass === "city" ? 9 : 11);
    userMoved.current = false;
    m.flyTo({ center: [hit.lng, hit.lat], zoom, duration: 1600, offset: [0, -sheetCoverPx() / 2] });
    // Ask once the camera has arrived, so the label tiles for that place are loaded.
    m.once("moveend", () => askHereRef.current(hit.lng, hit.lat));
  };

  /* ── LENSES ────────────────────────────────────────────────────────────── */

  const watchPoolMatches = useMemo(() => matchPool(pool, follows), [pool, follows]);

  useEffect(() => {
    if (lens !== "WATCH") return;
    let alive = true;
    setWatchLoading(true);
    matchTaxa(follows).then((res) => {
      if (!alive) return;
      setWatchTaxaMatches(res.matches);
      setWatchTaxaStatus(res.status);
      setWatchFailedTaxa(res.failedTaxa);
      setWatchLoading(false);
    });
    return () => { alive = false; };
  }, [lens, follows]);

  const watchMatches = useMemo(
    () => [...watchPoolMatches, ...watchTaxaMatches],
    [watchPoolMatches, watchTaxaMatches],
  );

  /* Paint the active lens onto Earth. The world always shows what the lens means. */
  useEffect(() => {
    const m = map.current; if (!m || !ready) return;

    clearFocus("lens");

    const dim = (v) => {
      ["whales", "species", "events", "quakes", "iss", "focus"].forEach((id) => {
        if (m.getLayer(id)) m.setPaintProperty(id, "circle-opacity", v);
      });
    };

    if (lens === "EARTH") { dim(0.78); return; }

    if (lens === "NOW") {
      dim(0.14);
      const rows = pool.signals.map((s) => ({
        lon: s.lng, lat: s.lat, col: SIGNAL_COLOR[s.cls] || C.amber, size: s.cls === "SEISMIC" ? 3 : 5,
        eid: s.id, html: `<b>${esc(s.title)}</b>`,
      }));
      if (rows.length) paintFocus("lens", rows, C.amber, 5);
      return;
    }

    if (lens === "WATCH") {
      dim(0.1);
      const rows = watchMatches.map((w) => ({
        lon: w.lng, lat: w.lat,
        col: w.itemClass === "OBSERVATION" ? C.green : (SIGNAL_COLOR[w.signal?.cls] || C.amber), size: 6,
        eid: watchItemId(w), html: `<b>${esc(watchItemTitle(w))}</b>`,
      }));
      const placeRows = follows
        .filter((f) => f.type === "PLACE")
        .map(placeById)
        .filter(Boolean)
        .map((p) => ({ lon: p.lng, lat: p.lat, col: C.blue, size: 9, eid: p.id, html: `<b>${esc(p.name)}</b>` }));
      const all = [...placeRows, ...rows];
      if (all.length) paintFocus("lens", all, C.blue, 6);
      return;
    }
  }, [lens, pool, watchMatches, follows, ready]);

  /* ── map lifecycle (V36) ──────────────────────────────────────────────── */

  // Keep the live refs current so the once-registered handlers below always see
  // the latest askHere/writeUrl (and the state they close over).
  askHereRef.current = askHere;
  dismissHintRef.current = dismissHint;
  writeUrlRef.current = writeUrl;
  openEntityRef.current = openEntity;
  openLegacyRef.current = openLegacy;
  onRef.current = Object.keys(on).filter((k) => on[k]);

  useEffect(() => {
    if (map.current) return;
    // MapLibre v6 ESM + Vite: the package default resolves a worker URL that
    // production preview may serve as HTML via SPA fallback. Bundle the matching
    // self-contained worker with Vite; never create a second map/camera authority.
    maplibregl.setWorkerUrl(maplibreWorkerUrl);
    const m = new maplibregl.Map({
      container: boxRef.current, style: init.current.light ? VECTOR_STYLE : VECTOR_STYLE_DARK, center: init.current.center,
      zoom: init.current.zoom, minZoom: 1, maxZoom: 22,
      attributionControl: { compact: true },
      canvasContextAttributes: { antialias: false, powerPreference: "high-performance" },
      maxTileCacheSize: window.matchMedia("(max-width: 760px)").matches ? 64 : 128,
      fadeDuration: window.matchMedia("(max-width: 760px)").matches ? 80 : 160,
      // V40 P0: the persistent world must never freeze when context is open.
      // Every interaction is turned on explicitly so no default can silently drop.
      interactive: true,
      dragPan: true,
      dragRotate: true,
      scrollZoom: true,
      boxZoom: true,
      doubleClickZoom: true,
      touchZoomRotate: true,
      touchPitch: true,
      keyboard: true,
      trackResize: true,
      renderWorldCopies: false,
    });
    map.current = m;
    // V40: expose the live map so behavioural browser tests can read real camera
    // state (center/zoom) and assert the world stays movable with context open.
    (window as any).__4planet_map = m;
    m.addControl(new maplibregl.NavigationControl({ showCompass: false }), "bottom-right");
    m.on("style.load", () => {
      const isFlat = flatRef.current;
      m.setProjection({ type: isFlat ? "mercator" : "globe" });
      setBackfaceSafeLabels(m, isFlat, basemapSymbolVisibility.current);
    });
    m.on("load", () => setReady(true));
    // The whole planet is never tilted. A two-finger drag at globe scale used to
    // pitch Earth down and out of the screen, leaving empty space above it.
    // Tilt returns once the visitor is close enough for it to mean something.
    let pitchLocked: boolean | null = null;
    const syncPitch = () => {
      const lock = m.getZoom() < 3.5;
      if (lock === pitchLocked) return;
      pitchLocked = lock;
      try { m.setMaxPitch(lock ? 0 : 60); } catch { /* style changing */ }
    };
    m.on("zoomend", syncPitch);
    syncPitch();
    // Attribution stays one tap away behind MapLibre's own (i) control. On a
    // phone the stylesheet keeps it collapsed until the visitor asks (it would
    // otherwise sit across the planet and under the legend); this records that
    // request. Moving the map puts it away again, as MapLibre itself does.
    const attrib = boxRef.current?.querySelector(".maplibregl-ctrl-attrib");
    attrib?.querySelector(".maplibregl-ctrl-attrib-button")
      ?.addEventListener("click", () => attrib.toggleAttribute("data-user-open"));
    m.on("dragstart", () => attrib?.removeAttribute("data-user-open"));
    m.on("error", (e) => {
      const id = e && e.sourceId;
      if (id && LAYERS.some((l) => l.id === id)) setStatus((st) => ({ ...st, [id]: "UNAVAILABLE" }));
      // A failed tile produces no new frame, and MapLibre only reports `load` and
      // `idle` from inside a frame. When a provider is down for every tile in view
      // the map could therefore sit "loaded" forever without ATLAS ever becoming
      // ready (no layers, no deep link, no panel). One frame per reported failure
      // lets the map settle honestly on whatever did arrive. Bounded: a repaint
      // does not re-request failed tiles, so it cannot feed itself.
      // Throttled: at most one extra frame per half second however many tiles fail.
      const now = Date.now();
      if (now - lastFailureRepaint.current > 500) {
        lastFailureRepaint.current = now;
        try { m.triggerRepaint(); } catch { /* map is being removed */ }
      }
      // V40 P0: if the vector basemap itself fails to load, never leave a blank
      // world — fall back to the raster base and rehydrate overlays. Guarded so
      // it only triggers once, for a base-style (not overlay) failure.
      if (!id && !vectorFailed.current && !m.isStyleLoaded()) {
        vectorFailed.current = true;
        try {
          m.setStyle(makeStyle(light));
          m.once("styledata", () => {
            m.setProjection({ type: flatRef.current ? "mercator" : "globe" });
            setBackfaceSafeLabels(m, flatRef.current, basemapSymbolVisibility.current);
            onRef.current.forEach((lid) => addLayer(LAYERS.find((l) => l.id === lid), true));
          });
        } catch { /* keep whatever rendered */ }
      }
    });
    m.on("moveend", () => writeUrlRef.current());
    // Wheel/inertial zoom keeps easing after the last moveend, so the URL can lag
    // the true camera. `idle` fires once the map has fully settled with no pending
    // animation — write once more there so the URL exactly matches what the user
    // sees. This is what makes returnTo reconstruction exact.
    m.on("idle", () => writeUrlRef.current());
    // If the user grabs the camera mid-landing, their gesture wins: cancel the
    // choreography so a stale moveend can't yank them back or open the panel late.
    m.on("movestart", (e: any) => { if (e && e.originalEvent) { cancelLanding(); stopFocusPulse(); } });
    m.on("mousedown", () => { cancelLanding(); });
    m.on("touchstart", () => { cancelLanding(); });
    // V40 P0: the moment the user takes the camera, no async response may fit or
    // reset it. A Place focuses ONCE on open; after that the world is theirs.
    ["dragstart", "zoomstart", "rotatestart", "pitchstart"].forEach((ev) =>
      m.on(ev, (e) => { userMoved.current = true; if (e && e.originalEvent) dismissHintRef.current(); }),
    );
    m.on("click", (e) => {
      const base = ["whales", "species", "events", "quakes", "iss", "emissions", "focus", "lens"];
      const ids = base.flatMap((id) => [id, `${id}__hit`]).filter((id) => m.getLayer(id));
      const hit = ids.length ? m.queryRenderedFeatures(e.point, { layers: ids }) : [];
      if (!hit.length) askHereRef.current(e.lngLat.lng, e.lngLat.lat);
    });
    return () => { Object.values(timers.current).forEach(clearInterval); m.remove(); map.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mobile Safari changes the visual viewport when browser chrome, orientation
  // and the keyboard change. MapLibre does not always receive a layout resize
  // for those transitions, which can leave the canvas visibly cut. Keep one
  // lightweight resize authority bound to real viewport changes only.
  useEffect(() => {
    let frame = 0;
    const resize = () => {
      // The visual viewport is what is left above an on-screen keyboard. Search
      // results size themselves to it (--atlas-vvh) so they never sit under it.
      const vv = window.visualViewport;
      document.documentElement.style.setProperty("--atlas-vvh", `${Math.round(vv?.height ?? window.innerHeight)}px`);
      // Part of the page that the browser itself covers at the bottom (iOS Safari's
      // floating toolbar can sit over a fixed-bottom sheet). Sheets keep their last
      // line above it.
      const covered = vv ? Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop)) : 0;
      document.documentElement.style.setProperty("--atlas-covered-b", `${Math.min(covered, 160)}px`);
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => map.current?.resize());
    };
    resize();
    window.addEventListener("resize", resize, { passive: true });
    window.addEventListener("orientationchange", resize, { passive: true });
    window.visualViewport?.addEventListener("resize", resize, { passive: true });
    window.visualViewport?.addEventListener("scroll", resize, { passive: true });
    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener("resize", resize);
      window.removeEventListener("orientationchange", resize);
      window.visualViewport?.removeEventListener("resize", resize);
      window.visualViewport?.removeEventListener("scroll", resize);
    };
  }, []);

  useEffect(() => {
    const m = map.current; if (!m) return;
    const id = requestAnimationFrame(() => m.resize());
    return () => cancelAnimationFrame(id);
  }, [ctx, lens, collapsed, open]);

  useEffect(() => {
    if (!ready) return;
    init.current.on.forEach((id) => addLayer(LAYERS.find((l) => l.id === id)));
    // Deep link straight into an object: ?f=place:4p:bergen
    if (init.current.focus) openEntity(init.current.focus);
    // Workstream C — deterministic bundled whale record. ?record=orca-bundled
    // (or the canonical record id) paints a visible marker and opens the real
    // OBSERVATION Context panel, with NO live API dependency.
    const rec = new URLSearchParams(window.location.search).get("record");
    if (rec === "orca-bundled" || rec === DEMO_WHALE_OBSERVATION.provenance.sourceRecordId) {
      const o = DEMO_WHALE_OCCURRENCE;
      // If the URL already carries a camera (returning from a journey via
      // returnTo), the map has ALREADY initialised at that exact camera — we must
      // reconstruct it, not re-fly. Only run the cinematic landing on a cold
      // entry with no camera in the URL.
      const urlp = new URLSearchParams(window.location.search);
      const hasRestoredCamera = urlp.has("z") && urlp.has("c");
      const targetZoom = hasRestoredCamera ? (map.current?.getZoom() ?? init.current.zoom) : Math.max(init.current.zoom, 6);
      paintFocus("focus", [{ lon: o.lng, lat: o.lat, col: C.blue, size: 9, eid: DEMO_WHALE_OBSERVATION.id, html: `<b>${o.commonName}</b>` }], C.blue, 8);
      focusTarget.current = { lng: o.lng, lat: o.lat, zoom: targetZoom };
      // Make the marker breathe so the eye finds it (no-op under reduced motion).
      startFocusPulse();
      // Normalise the record param up-front so returnTo captures it.
      const sp = new URLSearchParams(window.location.search);
      if (sp.get("record") !== "orca-bundled") {
        sp.set("record", "orca-bundled");
        replaceAtlasUrl(`${window.location.pathname}?${sp.toString()}`);
      }
      // Cinematic landing, then let the panel arrive with rhythm (a beat after the
      // camera settles) rather than snapping in at the same instant. The whole
      // sequence is cancellation-safe: a user interaction, route change or unmount
      // cancels it so a stale moveend can never open the panel late.
      const openPanel = () => setCtx({ kind: "OBSERVATION", observation: DEMO_WHALE_OBSERVATION });
      cancelLanding();
      if (hasRestoredCamera || !map.current) {
        // Reconstruction (or no map yet): do NOT re-fly. The camera is already the
        // restored one; just open the panel so state equals the returned-to state.
        openPanel();
      } else {
        const landing = cinematicLanding(map.current as any, { lng: o.lng, lat: o.lat, zoom: targetZoom });
        landingRef.current = landing;
        landing.done.then((outcome) => {
          if (outcome !== "settled") return; // cancelled → do nothing
          landingRef.current = null;
          panelTimer.current = window.setTimeout(() => {
            panelTimer.current = null;
            openPanel();
          }, prefersReducedMotion() ? 0 : MOTION.panelBeatMs);
        });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  useEffect(() => {
    const m = map.current; if (!m || !ready) return;
    // V40: on the vector basemap, light/dark reskins the 4PLANET chrome (the
    // .world.light class) and does NOT swap the base style — so overlays, context
    // and camera are never dropped by a theme toggle. Only if we already fell back
    // to the raster base do we re-theme it (and rehydrate overlays as before).
    if (vectorFailed.current) {
      const active = Object.keys(on).filter((k) => on[k]);
      m.setStyle(makeStyle(light));
      m.once("styledata", () => {
        m.setProjection({ type: flat ? "mercator" : "globe" });
        setBackfaceSafeLabels(m, flat, basemapSymbolVisibility.current);
        RASTER_ORDER.forEach((id) => { if (active.includes(id)) addLayer(LAYERS.find((l) => l.id === id), true); });
        active.filter((id) => !RASTER_ORDER.includes(id)).forEach((id) => addLayer(LAYERS.find((l) => l.id === id), true));
      });
    }
    writeUrl({ light });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [light]);

  const toggle = (l) => {
    if (busy[l.id]) return;
    if (on[l.id]) {
      removeLayer(l);
      const next = { ...on, [l.id]: false };
      setOn(next); setStatus((s) => ({ ...s, [l.id]: "" })); writeUrl({ on: next });
    } else {
      const next = { ...on, [l.id]: true };
      setOn(next); writeUrl({ on: next }); addLayer(l);
    }
    window.dispatchEvent(new CustomEvent("4p:atlas-layer-change"));
  };

  const activateLayerIntent = (layerId) => {
    const layer = LAYERS.find((item) => item.id === layerId);
    if (!layer) return;
    if (!on[layer.id]) toggle(layer);
    setQ("");
    setOpen(false);
    setCollapsed(true);
    setCtx(null);
    setLens("EARTH");
  };

  const isolate = (l) => {
    const m = map.current; if (!m) return;
    Object.keys(on).filter((k) => on[k] && k !== l.id).forEach((k) => removeLayer(LAYERS.find((x) => x.id === k)));
    const next = { [l.id]: true };
    setOn(next); writeUrl({ on: next });
    if (!m.getLayer(l.id)) addLayer(l);
  };

  const setOpa = (l, v) => {
    setOpacity((s) => ({ ...s, [l.id]: v }));
    const m = map.current;
    if (m && m.getLayer(l.id)) m.setPaintProperty(l.id, "raster-opacity", v);
  };

  const setDate = (off) => {
    setSatOffset(off);
    const m = map.current; const l = LAYERS.find((x) => x.id === "truecolor");
    const s = m && m.getSource("truecolor");
    if (s && s.setTiles) s.setTiles([l.tiles(off)]);
  };

  const toggleProjection = () => {
    const next = !flat;
    flatRef.current = next;
    setFlat(next);
    map.current.setProjection({ type: next ? "mercator" : "globe" });
    setBackfaceSafeLabels(map.current, next, basemapSymbolVisibility.current);
    writeUrl({ flat: next });
  };

  const goHome = () => map.current.flyTo({ center: [10, 25], zoom: 2.1, duration: 1200 });

  const share = async () => {
    try { await navigator.clipboard.writeText(window.location.href); setCopied(true); setTimeout(() => setCopied(false), 1800); }
    catch { /* ignore */ }
  };

  const nearMe = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const { latitude: lat, longitude: lng } = p.coords;
        map.current.flyTo({ center: [lng, lat], zoom: 7, duration: 1800 });
        askHere(lng, lat); // used once, then forgotten. Brief §37.
      },
      () => {},
      { timeout: 8000 },
    );
  };

  /* ── mode switching (V36) ─────────────────────────────────────────────── */
  const applyMode = (id) => {
    setMode(id);
    const m = MODES.find((x) => x.id === id);
    if (!m || !m.layers) { writeUrl({ mode: id }); return; }
    Object.keys(on).filter((k) => on[k] && !m.layers.includes(k)).forEach((k) => removeLayer(LAYERS.find((x) => x.id === k)));
    const next = Object.fromEntries(m.layers.map((k) => [k, true]));
    setOn(next);
    writeUrl({ mode: id, on: next });
    RASTER_ORDER.forEach((lid) => { if (m.layers.includes(lid)) addLayer(LAYERS.find((l) => l.id === lid)); });
    m.layers.filter((lid) => !RASTER_ORDER.includes(lid)).forEach((lid) => addLayer(LAYERS.find((l) => l.id === lid)));
  };

  /* ── render ───────────────────────────────────────────────────────────── */

  const sources = pool.status;
  const liveCount = Object.values(sources).filter((s) => s === "LIVE").length;
  const eonetDown = sources.eonet === "SOURCE_UNAVAILABLE";
  const usgsDown = sources.usgs === "SOURCE_UNAVAILABLE";

  const searchActive = open;
  const activeLayerIds = Object.keys(on).filter((k) => on[k]);
  // The data layers a person has added on top of the base picture of Earth.
  const dataLayers = activeLayerIds.map((id) => LAYERS.find((l) => l.id === id)).filter((l) => l && l.id !== "bluemarble");
  const legendLayer = dataLayers[dataLayers.length - 1];
  const legendInfo = legendLayer ? layerPresentation(legendLayer) : null;

  const closeAll = () => { setOpen(false); setCollapsed(true); setCtx(null); setSiteMenu(false); };
  const toggleLens = (id) => {
    const next = lens === id ? "EARTH" : id;
    closeAll();
    setLens(next);
    writeUrl({ lens: next });
  };
  const toggleLayers = () => {
    const next = !collapsed;
    setCollapsed(next);
    if (!next) { setOpen(false); setCtx(null); setLens("EARTH"); setSiteMenu(false); }
  };
  const closeSearch = () => {
    setQ("");
    setTaxaHits([]);
    setOpen(false);
    clearFocus("focus");
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
  };

  /* A layer row: plain name first, one switch, detail on request. On a compact
     screen turning a layer ON hands the screen back to Earth, and the legend
     chip keeps what it means one tap away. */
  const toggleLayerRow = (l) => {
    const turningOn = !on[l.id];
    toggle(l);
    if (turningOn && isCompact() && l.kind !== "planned") setCollapsed(true);
  };

  // A render function, not a component: defining a component inside render would
  // remount every row on every World render.
  const nowRow = (s) => {
    const h = signalHeadline(s);
    return (
      <div key={s.id} className="li tap" role="button" tabIndex={0} onClick={() => openSignal(s)} onKeyDown={onKeyActivate(() => openSignal(s))}>
        <span className="lidot" style={{ background: SIGNAL_COLOR[s.cls] === C.white ? "#8A94A6" : (SIGNAL_COLOR[s.cls] || C.amber) }} />
        <span className="limain">
          <span className="liname">{h.title}</span>
          {h.detail && <div className="lisub">{h.detail}</div>}
        </span>
        <span className="liend">{timeAgoHuman(s.provenance.occurredAt)}</span>
      </div>
    );
  };

  return (
    <div
      data-atlas-mobile-closure="v1"
      data-atlas-surface={surface}
      className={`world ${light ? "light" : ""} ${searchActive ? "search-active" : ""} ${ctx ? "context-active" : ""} ${!collapsed ? "layers-active" : ""} ${lens !== "EARTH" && !ctx ? "lens-active" : ""} ${siteMenu ? "menu-active" : ""} ${sheetFull ? "sheet-full" : ""}`}
    >
      <div ref={boxRef} className="world-map" style={{ position: "absolute", inset: 0 }} />

      {/* ── SEARCH — the one obvious first action ───────────────────────── */}
      <div className="search-wrap" role="search">
        <div className="search-line">
          <svg className="search-glyph" viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" focusable="false">
            <circle cx="8.5" cy="8.5" r="5.75" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M12.8 12.8 17 17" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            enterKeyHint="search"
            inputMode="search"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setOpen(true);
              setCollapsed(true);
              setCtx(null);
              setLens("EARTH");
              setSiteMenu(false);
            }}
            onFocus={() => {
              setOpen(true);
              setCollapsed(true);
              setCtx(null);
              setLens("EARTH");
              setSiteMenu(false);
            }}
            placeholder="Search places and species"
            aria-label="Search the living planet — life, places and living systems"
            spellCheck={false}
          />
          {searching && <span className="search-busy" role="status" aria-label="Searching" />}
          {open && (
            <button className="search-exit" aria-label="Close search" onClick={closeSearch}>
              <span aria-hidden="true">×</span>
            </button>
          )}
          {/* The world is the door — but the door must open onto the rest of the house.
              Without this, Earth is a room you cannot leave. */}
          {!open && (
            <button
              className="site-btn"
              aria-label={siteMenu ? "Close 4PLANET site menu" : "Open 4PLANET site menu"}
              aria-expanded={siteMenu}
              onClick={() => {
                const next = !siteMenu;
                setSiteMenu(next);
                if (next) {
                  setOpen(false);
                  setCollapsed(true);
                  setCtx(null);
                  setLens("EARTH");
                }
              }}
            >
              <svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" focusable="false">
                {siteMenu
                  ? <path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                  : <path d="M3.5 6h13M3.5 10h13M3.5 14h13" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />}
              </svg>
            </button>
          )}
        </div>

        {siteMenu && (
          <nav className="site-menu" aria-label="4PLANET sections">
            <a className="ritem family-home" href={familyHref("/")} onClick={(e) => { setSiteMenu(false); followFamilyLink(e, familyHref("/")); }}>
              <span className="rmain">
                <span className="rname"><span className="wordmark">4PLANET_</span> For a Living Planet</span>
                <div className="rsub">The home of ATLAS, SPECIES and the rest of the family</div>
              </span>
              <span aria-hidden="true">↗</span>
            </a>
            <div className="rgrp">From 4PLANET</div>
            {[
              ["/domains", "Domains", "Ocean, Earth, human systems and culture"],
              ["/missions", "Missions", "Every active mission"],
              ["/impact", "Impact", "Pathways and proof"],
              ["/living-systems", "Living Systems", "How life connects"],
              ["/species", "Species", "Life, one species at a time"],
              ["/places", "Places", "Enter the planet through a place"],
              ["/about", "About", "What 4PLANET is"],
            ].map(([to, label, sub]) => {
              const href = familyHref(to);
              const body = (
                <span className="rmain">
                  <span className="rname">{label}</span>
                  <div className="rsub">{sub}</div>
                </span>
              );
              return href.startsWith("http")
                ? <a key={to} href={href} className="ritem" onClick={(e) => { setSiteMenu(false); followFamilyLink(e, href); }}>{body}</a>
                : <Link key={to} to={to} className="ritem" onClick={() => setSiteMenu(false)}>{body}</Link>;
            })}
          </nav>
        )}

        {open && q.trim().length < 2 && (
          <div className="results results-hint" aria-live="polite">
            <div className="rgrp">Try</div>
            {["Oslofjord", "Orca", "Kenya", "Sea ice"].map((example) => (
              <div key={example} className="ritem" role="button" tabIndex={0}
                onClick={() => setQ(example)} onKeyDown={onKeyActivate(() => setQ(example))}>
                <span className="rmain"><span className="rname">{example}</span></span>
              </div>
            ))}
          </div>
        )}

        {open && q.trim().length >= 2 && (
          <div className="results" role="listbox" aria-label="Search results">
            {placeHits.length > 0 && <div className="rgrp">Places</div>}
            {placeHits.map((p) => (
              <div key={p.id} className="ritem" role="option" tabIndex={0}
                onClick={() => openPlace(p)} onKeyDown={onKeyActivate(() => openPlace(p))}>
                <span className="rmain">
                  <span className="rname">{p.name}</span>
                  <div className="rsub">{titleCase(p.kind.replace(/_/g, " ")).replace(/ A/g, " a")}</div>
                </span>
              </div>
            ))}

            {worldHits.length > 0 && <div className="rgrp">{placeHits.length ? "More places" : "Places"}</div>}
            {worldHits.map((hit) => (
              <div key={`${hit.name}-${hit.lat}-${hit.lon}-${hit.kind}`} className="ritem" role="option" tabIndex={0}
                data-atlas-world-place={hit.name}
                onClick={() => openWorldPlace(hit)} onKeyDown={onKeyActivate(() => openWorldPlace(hit))}>
                <span className="rmain">
                  <span className="rname">{hit.name}</span>
                  <div className="rsub">{[hit.kind, hit.context].filter(Boolean).join(" · ")}</div>
                </span>
              </div>
            ))}

            {shownMapPlaceHits.length > 0 && <div className="rgrp">On the map now</div>}
            {shownMapPlaceHits.map((hit) => (
              <div key={`${hit.name}-${hit.lng}-${hit.lat}`} className="ritem" role="option" tabIndex={0}
                data-atlas-map-place={hit.name}
                onClick={() => openMapPlace(hit)} onKeyDown={onKeyActivate(() => openMapPlace(hit))}>
                <span className="rmain">
                  <span className="rname">{hit.name}</span>
                  <div className="rsub">{titleCase(hit.placeClass)} · from the map in view</div>
                </span>
              </div>
            ))}

            {taxaHits.length > 0 && <div className="rgrp">Life</div>}
            {taxaHits.map((h) => (
              <div key={h.id} className="ritem" role="option" tabIndex={0}
                onClick={() => openTaxon(h)} onKeyDown={onKeyActivate(() => openTaxon(h))}>
                <span className="rmain">
                  <span className="rname">{h.commonName || h.scientificName}</span>
                  {h.commonName && <div className="rsub"><em>{h.scientificName}</em></div>}
                </span>
              </div>
            ))}

            {systemHits.length > 0 && <div className="rgrp">Living systems</div>}
            {systemHits.map((s) => (
              <div key={s.id} className="ritem" role="option" tabIndex={0}
                onClick={() => openSystem(s)} onKeyDown={onKeyActivate(() => openSystem(s))}>
                <span className="rmain">
                  <span className="rname">{s.name}</span>
                  <div className="rsub">{s.sub}</div>
                </span>
              </div>
            ))}

            {layerHits.length > 0 && <div className="rgrp">On the map</div>}
            {layerHits.map((hit) => {
              const layer = LAYERS.find((l) => l.id === hit.layerId);
              const info = layer ? layerPresentation(layer) : null;
              return (
                <div
                  key={hit.layerId}
                  className="ritem"
                  role="option"
                  tabIndex={0}
                  data-atlas-intent-layer={hit.layerId}
                  onClick={() => activateLayerIntent(hit.layerId)}
                  onKeyDown={onKeyActivate(() => activateLayerIntent(hit.layerId))}
                >
                  <span className="rmain">
                    <span className="rname">{info?.name ?? hit.label}</span>
                    <div className="rsub">Map layer · {hit.source}</div>
                  </span>
                </div>
              );
            })}

            {worldSearchFailed && (
              <div className="results-note bad" role="status">
                <strong>The place index did not load.</strong>
                <span>That is a connection problem, not an empty result. Species and map layers are still searchable.</span>
              </div>
            )}

            {/* P0 (V38R): source failure is not the same as no match. Say so. */}
            {taxaSearchFailed && !searching && (
              <div className="results-note bad" role="status">
                <strong>The species index did not answer.</strong>
                <span>
                  That is a connection problem, not an empty result — there may well be matches.
                  Places and map layers are still searchable.
                </span>
              </div>
            )}

            {!hasResults && !searching && !taxaSearchFailed && (
              <div className="results-note" role="status">
                <strong>Nothing matched “{q.trim()}”.</strong>
                <span>
                  ATLAS searches species, places worldwide (towns of 5,000 people or more, every
                  capital, countries, regions, seas, landscapes and lakes) and its own map layers.
                  Smaller places: move the map there and tap it.
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── DOCK — four quiet doors; Earth is the resting state ──────────── */}
      <nav className="lens-rail atlas-dock" aria-label="ATLAS">
        <button className={`lens ${lens === "NOW" && !ctx ? "on" : ""}`} data-atlas-action="now"
          aria-pressed={lens === "NOW" && !ctx} onClick={() => toggleLens("NOW")}>
          Now
        </button>
        <button className={`lens ${!collapsed ? "on" : ""}`} data-atlas-action="layers"
          aria-expanded={!collapsed} onClick={toggleLayers}>
          Layers{dataLayers.length > 0 && <span className="cnt" aria-label={`${dataLayers.length} added`}>{dataLayers.length}</span>}
        </button>
        <button className={`lens ${lens === "WATCH" && !ctx ? "on" : ""}`} data-atlas-action="watch"
          aria-pressed={lens === "WATCH" && !ctx} onClick={() => toggleLens("WATCH")}>
          Watch{follows.length > 0 && <span className="cnt" aria-label={`${follows.length} followed`}>{follows.length}</span>}
        </button>
        <button className={`lens ${myAtlasOpen ? "on" : ""}`} data-atlas-action="my-atlas"
          aria-expanded={myAtlasOpen}
          onClick={() => { closeAll(); setLens("EARTH"); window.dispatchEvent(new CustomEvent("4p:atlas-my-atlas-toggle")); }}>
          My Atlas
        </button>
      </nav>

      {hint && surface === "REST" && ready && (
        <p className="atlas-hint" role="note">Tap anywhere on Earth to see what has been recorded there.</p>
      )}

      {/* ── WHAT AM I LOOKING AT — the layer on top, with its scale ───────── */}
      {legendLayer && legendInfo && (
        <button className="atlas-legend" data-atlas-legend={legendLayer.id}
          aria-label={`${legendInfo.name}. ${TIME_LABEL[legendInfo.time]}. Show details`}
          onClick={() => { closeAll(); setLens("EARTH"); setCollapsed(false); setInfo((s) => ({ ...s, [legendLayer.id]: true })); }}>
          {/* Point layers carry their dot colour, so the dots on the map can be read. */}
          {dataLayers.some((l) => l.kind === "point") && (
            <span className="lg-dots" aria-hidden="true">
              {dataLayers.filter((l) => l.kind === "point").slice(-4).map((l) => (
                <span key={l.id} className="lg-dot" style={{ background: l.color }} />
              ))}
            </span>
          )}
          <span className="lg-name">{legendInfo.name}{dataLayers.length > 1 ? ` +${dataLayers.length - 1}` : ""}</span>
          {legendLayer.legend ? (
            <span className="lg-scale">
              <span className="lg-end">{titleCase(legendLayer.legend.lo)}</span>
              <span className="ramp" style={{ background: legendLayer.legend.ramp ?? `linear-gradient(90deg, ${(legendLayer.legend.stops || []).join(",")})` }} />
              <span className="lg-end">{titleCase(legendLayer.legend.hi)}</span>
            </span>
          ) : (
            <span className="lg-time">{TIME_LABEL[legendInfo.time]}</span>
          )}
        </button>
      )}

      {/* ── LAYERS — the full V36 machinery behind one calm sheet ─────────── */}
      <section className={`atlas-panel ${collapsed ? "rest" : ""}`} aria-label="Map layers" aria-hidden={collapsed}>
        <header className="sheet-head">
          <button className="sheet-grab" aria-label={sheetFull ? "Make this panel smaller" : "Make this panel larger"}
            onClick={() => setSheetFull((v) => !v)} />
          <h2>Layers</h2>
          <button className="sect sheet-close" aria-label="Close" aria-expanded={!collapsed} onClick={toggleLayers}>
            <span aria-hidden="true">×</span>
          </button>
        </header>

        {!collapsed && (
          <div className="sheet-body">
            <div className="seg" role="group" aria-label="Show layers for">
              {MODES.map((m) => (
                <button key={m.id} className={`chip ${mode === m.id ? "on" : ""}`} aria-pressed={mode === m.id} onClick={() => applyMode(m.id)}>
                  {{ PLANET: "All", OCE4N: "Ocean", E4RTH: "Land", S4PIENS: "Sapiens" }[m.id] ?? m.label}
                </button>
              ))}
            </div>

            {LAYER_CATEGORIES.map((category) => {
              // V36's real model: a layer belongs to the current mode when its
              // `domain` array includes the mode. Sections are plain categories.
              const rows = LAYERS.filter(
                (l) => layerPresentation(l).category === category && (l.domain ? l.domain.includes(mode) : true),
              );
              if (!rows.length) return null;
              return (
                <div key={category} className="layer-group">
                  <div className="grp">{category}</div>
                  {rows.map((l) => {
                    const active = !!on[l.id];
                    const p = layerPresentation(l);
                    const state = layerStatusText(status[l.id], l.kind);
                    const planned = l.kind === "planned";
                    return (
                      <div key={l.id} className={`layer ${active ? "on" : ""}`} data-atlas-layer={l.id}>
                        <div className="atlas-row">
                          <button
                            className="alyr"
                            role="switch"
                            aria-checked={active}
                            disabled={planned}
                            onClick={() => toggleLayerRow(l)}
                          >
                            <span className="alyr-txt">
                              <span className="alyr-name">{p.name}</span>
                              <span className="alyr-what">{state || p.what}</span>
                            </span>
                            <span className="switch" aria-hidden="true" />
                          </button>
                          <button className="ibtn" aria-label={`About ${p.name}`} aria-expanded={!!info[l.id]}
                            onClick={() => setInfo((s) => ({ ...s, [l.id]: !s[l.id] }))}>
                            <svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" focusable="false">
                              <circle cx="10" cy="10" r="7.25" fill="none" stroke="currentColor" strokeWidth="1.4" />
                              <path d="M10 9v5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                              <circle cx="10" cy="6.4" r=".95" fill="currentColor" />
                            </svg>
                          </button>
                        </div>

                        {info[l.id] && (
                          <div className="drawer">
                            {(() => {
                              const source = layerSource(l.src);
                              return (
                                <p className="layer-source">
                                  <span>Source</span>
                                  {source.url
                                    ? <a href={source.url} target="_blank" rel="noopener noreferrer">{source.name} <span aria-hidden="true">↗</span></a>
                                    : <strong>{source.name}</strong>}
                                </p>
                              );
                            })()}
                            <p className="prose">{l.note}</p>
                            {l.legend && (
                              <div className="legend">
                                <div className="ramp" style={{ background: l.legend.ramp ?? `linear-gradient(90deg, ${(l.legend.stops || []).join(",")})` }} />
                                <div className="legend-ends">
                                  <span>{titleCase(l.legend.lo)}</span><span>{titleCase(l.legend.hi)}</span>
                                </div>
                                {l.legend.sub && <div className="foot">{l.legend.sub}</div>}
                              </div>
                            )}
                            <div className="hrow"><span>Kind of time</span><span>{TIME_LABEL[p.time]}</span></div>
                            {p.when && <div className="hrow"><span>How current</span><span>{p.when}</span></div>}
                            <div className="hrow"><span>Provider data</span><span>{l.src}</span></div>
                            <div className="hrow"><span>Layer</span><span className="mono">{l.label}</span></div>
                            {status[l.id] && <div className="hrow"><span>State</span><span className="mono">{status[l.id]}</span></div>}
                            {l.kind === "raster" && active && (
                              <label className="hrow">
                                <span>Opacity</span>
                                <input
                                  type="range" min={0} max={1} step={0.05}
                                  value={opacity[l.id] ?? l.opacity}
                                  onChange={(e) => setOpa(l, Number(e.target.value))}
                                />
                              </label>
                            )}
                            {l.id === "truecolor" && active && (
                              <label className="hrow">
                                <span>Day shown · {daysAgo(satOffset)}</span>
                                <input type="range" min={1} max={14} step={1} value={satOffset}
                                  onChange={(e) => setDate(Number(e.target.value))} />
                              </label>
                            )}
                            {!planned && (
                              <button className="mbtn" onClick={() => isolate(l)} aria-label={`Show only ${p.name} (ISOLATE)`}>
                                Show only this
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}

            <div className="layer-group">
              <div className="grp">Map</div>
              <div className="map-actions">
                <button className="mbtn" onClick={toggleProjection}>{flat ? "Globe" : "Flat map"}</button>
                <button className="mbtn" onClick={() => setLight(!light)}>{light ? "Dark map" : "Light map"}</button>
                <button className="mbtn" onClick={goHome}>Whole Earth</button>
                <button className="mbtn" onClick={nearMe}>Near me</button>
                <button className="mbtn" onClick={share}>{copied ? "Link copied" : "Copy link"}</button>
              </div>
            </div>

            {/* Coverage is part of truth, but not the headline: the per-source
                readout lives here, one tap away, never hidden. */}
            <details className="evidence" open={stripOpen} onToggle={(e) => setStripOpen(e.currentTarget.open)}>
              <summary>Sources and coverage</summary>
              <div className="evidence-body">
                <div className="hrow"><span>NASA EONET · natural events</span><span>{sources.eonet ? sourceWord(sources.eonet) : "Asked when needed"}</span></div>
                <div className="hrow"><span>USGS · earthquakes</span><span>{sources.usgs ? sourceWord(sources.usgs) : "Asked when needed"}</span></div>
                <div className="hrow"><span>GBIF · species records</span><span>Asked when needed</span></div>
                <div className="hrow"><span>Forest disturbance events</span><span>No coverage yet</span></div>
                <div className="hrow"><span>Protected-area boundaries</span><span>Not checked</span></div>
                <div className="hrow"><span>Living-system relationships</span><span>4PLANET editorial</span></div>
                {stripOpen && <div className="hrow"><span>Checked</span><span className="mono">{utc}</span></div>}
                <p className="note-box">
                  A source that did not answer is shown as unavailable, never as zero. “Asked when
                  needed” means ATLAS does not load a feed until you open something that uses it.
                </p>
              </div>
            </details>
          </div>
        )}
      </section>

      {/* ── NOW / WATCH — the lens speaks ─────────────────────────────────── */}
      {lens !== "EARTH" && !ctx && (
        <aside className="ctx lens-panel" aria-label={lens === "NOW" ? "Now" : "Watch"}>
          <header className="ctx-head">
            <button className="sheet-grab" aria-label={sheetFull ? "Make this panel smaller" : "Make this panel larger"}
              onClick={() => setSheetFull((v) => !v)} />
            <div className="ctx-kind">{lens === "NOW" ? "Reported around the planet" : "What you follow"}</div>
            <h2 className="ctx-title">{lens === "NOW" ? "Now" : "Watch"}</h2>
            <button className="ctx-close" aria-label="Close" onClick={() => { setLens("EARTH"); writeUrl({ lens: "EARTH" }); }}>
              <span aria-hidden="true">×</span>
            </button>
          </header>

          <div className="ctx-body">
            {lens === "NOW" && (() => {
              // Product judgement (V38R): NOW asks "what is happening to the LIVING
              // planet?" Fire and natural events have plausible ecological bearing;
              // raw seismicity mostly does not. NOW therefore leads with natural
              // events, and shows earthquakes by what a person could have felt:
              // records below FELT_MAGNITUDE stay real and reachable, one tap down,
              // instead of burying everything under instrument-only tremors.
              const living = pool.signals.filter((s) => s.cls !== "SEISMIC");
              const seismic = pool.signals.filter((s) => s.cls === "SEISMIC");
              const felt = seismic.filter((s) => typeof s.magnitude === "number" && s.magnitude >= FELT_MAGNITUDE);
              const small = seismic.filter((s) => !(typeof s.magnitude === "number" && s.magnitude >= FELT_MAGNITUDE));
              return (
                <>
                  <section className="sec" data-status={eonetDown ? "SOURCE_UNAVAILABLE" : poolLoading ? "LOADING" : living.length ? "LIVE" : "NO_RECORDS"}>
                    <div className="sec-h">
                      <h3>Natural events</h3>
                      {poolLoading && <span className="stat load">Loading…</span>}
                      {!poolLoading && eonetDown && <span className="stat bad">Source unavailable</span>}
                      {!poolLoading && !eonetDown && !living.length && <span className="stat none">No records returned</span>}
                    </div>
                    <div className="sec-body">
                      {poolLoading && <div className="skeleton" aria-hidden="true"><i /><i /><i /></div>}
                      {!poolLoading && eonetDown && (
                        <p className="note-box">
                          NASA's event tracker did not answer. That is a connection problem, not a
                          quiet planet. Nothing is shown rather than guessed.
                        </p>
                      )}
                      {!poolLoading && !eonetDown && !living.length && (
                        <p className="note-box">
                          NASA's event tracker answered and listed no open events. That is a statement
                          about the tracker, not about the world.
                        </p>
                      )}
                      {living.slice(0, 50).map(nowRow)}
                      {!eonetDown && living.length > 0 && (
                        <p className="origin">
                          Wildfires, storms, volcanoes and ice that NASA EONET lists as open, newest first.
                          Nothing is promoted to an alert — 4PLANET has no methodology for that and
                          will not invent one. Forest disturbance is absent because no per-event
                          forest source is connected yet.
                        </p>
                      )}
                    </div>
                  </section>

                  <section className="sec" data-status={usgsDown ? "SOURCE_UNAVAILABLE" : poolLoading ? "LOADING" : seismic.length ? "LIVE" : "NO_RECORDS"}>
                    <div className="sec-h">
                      <h3>Earthquakes · past 24 hours</h3>
                      {poolLoading && <span className="stat load">Loading…</span>}
                      {!poolLoading && usgsDown && <span className="stat bad">Source unavailable</span>}
                      {!poolLoading && !usgsDown && !seismic.length && <span className="stat none">No records returned</span>}
                    </div>
                    <div className="sec-body">
                      {!poolLoading && usgsDown && (
                        <p className="note-box">
                          The USGS earthquake feed did not answer. That is a connection problem, not
                          an absence of earthquakes.
                        </p>
                      )}
                      {felt.slice(0, 30).map(nowRow)}
                      {!poolLoading && !usgsDown && seismic.length > 0 && felt.length === 0 && (
                        <p className="origin">No earthquake of magnitude {FELT_MAGNITUDE} or above in the past 24 hours.</p>
                      )}
                      {small.length > 0 && (
                        <>
                          <button className="disclose" aria-expanded={smallQuakesOpen} onClick={() => setSmallQuakesOpen((v) => !v)}>
                            {smallQuakesOpen ? "Hide" : "Show"} {small.length.toLocaleString("en-GB")} smaller earthquakes
                          </button>
                          {smallQuakesOpen && small.slice(0, 200).map(nowRow)}
                        </>
                      )}
                      {!usgsDown && seismic.length > 0 && (
                        <p className="origin">
                          Recorded earthquakes from the USGS Earthquake Hazards Program. Shown as planetary
                          context, not as living-planet change: a seismic event is a geophysical fact,
                          and 4PLANET draws no ecological conclusion from it.
                        </p>
                      )}
                    </div>
                  </section>
                </>
              );
            })()}

            {lens === "WATCH" && (
              <>
                {follows.length === 0 ? (
                  <section className="sec" data-status="NO_RECORDS">
                    <p className="lead">
                      Follow a species, a place or a living system, and what the connected sources
                      report about it appears here — always with why you are seeing it.
                    </p>
                    <p className="origin">
                      Follows are kept on this device. Nothing is sent anywhere unless you sign in
                      through My Atlas to keep them across devices.
                    </p>
                    <div className="sec-h"><h3>Start with</h3></div>
                    <div className="sec-body">
                      {/* V39.1: canon-safe suggestions. FD-11 makes Oslofjorden the
                          proof place and B-01 leaves its geometry unresolved, so WATCH
                          suggests living systems (relationship intelligence) rather than
                          a place, avoiding any place-membership implication. */}
                      {[LIVING_SYSTEMS[0], LIVING_SYSTEMS[1]].filter(Boolean).map((x) => (
                        <div key={x.id} className="li tap" role="button" tabIndex={0}
                          onClick={() => openEntity(x.id)} onKeyDown={onKeyActivate(() => openEntity(x.id))}>
                          <span className="limain">
                            <span className="liname">{x.name}</span>
                            <div className="lisub">{x.sub}</div>
                          </span>
                        </div>
                      ))}
                    </div>
                  </section>
                ) : (
                  <>
                    <section className="sec" data-status="LIVE">
                      <div className="sec-h"><h3>Following · {follows.length}</h3></div>
                      <div className="sec-body">
                        {follows.map((f) => (
                          <div key={f.id} className="li tap" role="button" tabIndex={0}
                            onClick={() => openEntity(f.id)} onKeyDown={onKeyActivate(() => openEntity(f.id))}>
                            <span className="limain">
                              <span className="liname">{f.label}</span>
                              <div className="lisub">{f.type === "TAXON" && f.sub ? <em>{f.sub}</em> : titleCase(String(f.sub || f.type).replace(/_/g, " "))}</div>
                            </span>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="sec" data-status={watchTaxaStatus === "SOURCE_UNAVAILABLE" ? "SOURCE_UNAVAILABLE" : watchLoading ? "LOADING" : watchMatches.length ? "LIVE" : "NO_RECORDS"}>
                      <div className="sec-h">
                        <h3>Reported in the last {WATCH_WINDOW_DAYS} days</h3>
                        {/* P0 (V38R): a failed GBIF call must not read as "no records". */}
                        {watchLoading && <span className="stat load">Loading…</span>}
                        {!watchLoading && watchTaxaStatus === "SOURCE_UNAVAILABLE" && <span className="stat bad">Source unavailable</span>}
                        {!watchLoading && watchTaxaStatus !== "SOURCE_UNAVAILABLE" && !watchMatches.length && <span className="stat none">No records returned</span>}
                      </div>
                      <div className="sec-body">
                        {watchLoading && <div className="skeleton" aria-hidden="true"><i /><i /><i /></div>}
                        {!watchLoading && watchFailedTaxa.length > 0 && (
                          <p className="note-box">
                            GBIF did not answer for: {watchFailedTaxa.join(", ")}. That is a source
                            failure, not an absence of records. 4PLANET is showing nothing for these
                            rather than pretending the answer is zero.
                          </p>
                        )}
                        {!watchLoading && watchMatches.length === 0 && watchTaxaStatus !== "SOURCE_UNAVAILABLE" && (
                          <>
                            <p className="prose">{EMPTY_WATCH.headline}</p>
                            <p className="note-box">{EMPTY_WATCH.body}</p>
                          </>
                        )}
                        {watchMatches.slice(0, 60).map((w, i) => {
                          const isObs = w.itemClass === "OBSERVATION";
                          const openItem = () => (isObs
                            ? setCtx({ kind: "OBSERVATION", observation: w.observation })
                            : openSignal(w.signal));
                          return (
                            <div key={`${watchItemId(w)}-${i}`} className="li tap" role="button" tabIndex={0}
                              onClick={openItem} onKeyDown={onKeyActivate(openItem)}>
                              <span className="limain">
                                <span className="liname">{isObs ? watchItemTitle(w) : signalHeadline(w.signal).title}</span>
                                <div className="lisub">
                                  {isObs ? "Observation record" : CLASS_NAME[w.signal.cls]} · {String(w.kind || "").toLowerCase()}
                                </div>
                                <div className="liwhy">{w.why}</div>
                              </span>
                              <span className="liend">{timeAgoHuman(w.occurredAt)}</span>
                            </div>
                          );
                        })}
                      </div>
                    </section>
                  </>
                )}
              </>
            )}
          </div>
        </aside>
      )}

      {/* V40 P0: RECENTER — the camera is never locked to context. This puts it
          back on the selected place/point on demand, and only when it helps. */}
      {ctx && focusTarget.current && ["PLACE", "SIGNAL", "OBSERVATION", "COORDINATE", "LEGACY_POINT"].includes(ctx.kind) && (
        <button className="recenter-btn" onClick={recenter} aria-label="Recenter the map on this selection (RECENTER)">
          Recenter
        </button>
      )}

      {/* ── SHARED CONTEXT LAYER ────────────────────────────────────────── */}
      {ctx && (
        <>
          <button className="sheet-grab ctx-grab" aria-label={sheetFull ? "Make this panel smaller" : "Make this panel larger"}
            onClick={() => setSheetFull((v) => !v)} />
          <ContextLayer
            ctx={ctx}
            onClose={() => { setCtx(null); clearFocus("focus"); writeUrl({ focus: "" }); }}
            onOpen={openEntity}
            following={following}
            onFollow={toggleFollow}
            onDepth={(deep) => setSheetFull(deep)}
          />
        </>
      )}

      {/* ── BRAND LINE: the masterbrand stays present, and so does the way out.
          The per-source readout that used to sit here lives in Layers →
          Sources and coverage: reduced weight, evidence never hidden. ─────── */}
      <div className="status-strip">
        <span className="s"><a href={familyHref("/story")} onClick={(e) => followFamilyLink(e, familyHref("/story"))}><span className="wordmark">4PLANET_</span> For a Living Planet →</a></span>
      </div>
    </div>
  );
}

/* Source state in a person's words. A failure is never rendered as empty. */
function sourceWord(status) {
  return {
    LIVE: "Answering",
    NO_RECORDS: "Answered · nothing listed",
    SOURCE_UNAVAILABLE: "Unavailable right now",
    NOT_CHECKED: "Not checked",
    NO_COVERAGE: "No coverage yet",
    LOADING: "Loading…",
  }[status] ?? String(status).toLowerCase();
}

/* Wrapped so a runtime throw degrades to an honest message, never a white screen. */
export default function World() {
  return (
    <WorldBoundary>
      <WorldInner />
    </WorldBoundary>
  );
}
