/**
 * The ONE way ATLAS rewrites the address bar.
 *
 * Several owners keep the URL shareable (World: camera, layers, entity; TIME:
 * the chosen slice). They write on `moveend` and `idle`, which can fire many
 * times a second while tiles settle. Safari refuses more than 100
 * `history.replaceState` calls per 10 seconds and throws — which took the whole
 * ATLAS down on a real iPhone ("The world failed to render").
 *
 * So: a write that would not change the URL is skipped, and real changes are
 * kept far under the browser's budget. When the budget is used up the newest
 * URL is written once the window allows it — the address always converges on
 * the latest view; it is never left stale.
 */
const WINDOW_MS = 10_000;
const BUDGET = 40; // well under Safari's 100 per 10 s
const writes: number[] = [];
let pending: string | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;

function currentUrl() {
  return `${window.location.pathname}${window.location.search}${window.location.hash}`;
}

function prune(now: number) {
  while (writes.length && now - writes[0] > WINDOW_MS) writes.shift();
}

function flush() {
  timer = null;
  if (pending === null) return;
  const next = pending;
  pending = null;
  replaceAtlasUrl(next);
}

/** Replace the current history entry with `next` (path + query + hash), safely. */
export function replaceAtlasUrl(next: string): boolean {
  if (typeof window === "undefined") return false;
  if (next === currentUrl()) return false;
  const now = Date.now();
  prune(now);
  if (writes.length >= BUDGET) {
    pending = next;
    if (!timer) timer = setTimeout(flush, Math.max(50, WINDOW_MS - (now - writes[0]) + 10));
    return false;
  }
  try {
    window.history.replaceState(window.history.state, "", next);
    writes.push(now);
    return true;
  } catch {
    // A browser that still refuses keeps the last good URL; the view itself is unaffected.
    pending = next;
    if (!timer) timer = setTimeout(flush, 1_000);
    return false;
  }
}

/** Test-only: forget the write history. */
export function __resetAtlasUrlBudget() {
  writes.length = 0;
  pending = null;
  if (timer) clearTimeout(timer);
  timer = null;
}
