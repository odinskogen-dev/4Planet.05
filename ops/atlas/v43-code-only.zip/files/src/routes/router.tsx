import { lazy, Suspense, useEffect } from "react";
import { Routes, Route, Navigate, useLocation, useParams } from "react-router-dom";
import { isAtlasHost } from "@/seo/ownership";
import Home from "@/pages/v5/Home";
import {
  LabsOverview,
  DomainsIndex,
  DomainWorld,
  MissionDetail,
  MissionsIndex,
  ImpactLabIndex,
  ImpactTestJourney,
  PersonalImpactRecordPage,
  ImpactPublicHome,
  ImpactStory,
  BayActionProof,
  CheckoutReturn,
  CommerceStripeLab,
  CompanyGoldTony,
  SpeciesIndex,
  SpeciesProfilePage,
  SpeciesEngineLab,
  SpeciesRoute,
  PlacesIndex,
  PlaceRoute,
  AtlasDiscoveryPage,
  DiscoveryTopicPage,
  EarthNowPage,
  DISCOVERY_TOPIC_SLUGS,
  LensCapture,
  FoodCapture,
  PickPrototype,
  FourFinanceHome,
  FourSapienHome,
  People,
  Brands,
  Partners,
  Funders,
  Join,
  LivingSystemJourney,
  PlanetProofPage,
  Reports,
  About,
  AboutStory,
  AboutSystem,
  WhatWeBelieve,
  Founder,
  CulturePlay,
  MarketHome,
  OdinCreatorPage,
  Privacy,
  PlanetSignal,
} from "./deferredRoutes";
import { NotFound } from "@/pages/system";

const PublicWorld = lazy(() => import("@/earth/PublicWorld"));

/**
 * The root of the standalone ATLAS host IS the map. "/" there is a real,
 * prerendered, canonical page (scripts/finalize-atlas-host.mjs), and the running
 * app continues on the one existing ATLAS route so camera authority, return-to
 * links, embeds and saved views keep a single path. Query and hash survive, so a
 * shared "/?z=…&c=…" link opens exactly that view. Every other host is unchanged.
 */
function RootRoute() {
  const { search, hash } = useLocation();
  if (isAtlasHost()) return <Navigate to={{ pathname: "/atlas", search, hash }} replace />;
  return <Home />;
}
const NationPage = lazy(() => import("@/pages/nation/NationPage"));
const LumeRoom = lazy(() => import("@/pages/v5/LumeRoom"));
const FoodUserTest = lazy(() => import("../food/FoodUserTest"));
const Magazine = lazy(() => import("@/pages/v5/Magazine"));
const StoryArticle = lazy(() => import("@/pages/v5/StoryArticle").then((module) => ({ default: module.StoryArticle })));
const MagazineAbout = lazy(() => import("@/pages/v5/MagazineInfo").then((module) => ({ default: module.MagazineAbout })));
const MagazineSources = lazy(() => import("@/pages/v5/MagazineInfo").then((module) => ({ default: module.MagazineSources })));
const MagazineCorrections = lazy(() => import("@/pages/v5/MagazineInfo").then((module) => ({ default: module.MagazineCorrections })));
const MagazineStoryRecord = lazy(() => import("@/pages/v5/MagazineStoryRecord").then((module) => ({ default: module.MagazineStoryRecord })));
const ActorsIndex = lazy(() => import("@/pages/v5/ActorGold").then((module) => ({ default: module.ActorsIndex })));
const ActorProfile = lazy(() => import("@/pages/v5/ActorGold").then((module) => ({ default: module.ActorProfilePage })));
const FindYourWayToHelp = lazy(() => import("@/pages/v5/Participation").then((module) => ({ default: module.FindYourWayToHelp })));
const EmblaFoodChoice = lazy(() => import("@/pages/sapien/EmblaFoodChoice"));
const GoldTemplateSystemIndex = lazy(() => import("@/pages/labs/GoldTemplateSystem").then((module) => ({ default: module.GoldTemplateSystemIndex })));
const GoldObjectProofPage = lazy(() => import("@/pages/labs/GoldTemplateSystem").then((module) => ({ default: module.GoldObjectProofPage })));
const GoldStoryProofPage = lazy(() => import("@/pages/labs/GoldTemplateSystem").then((module) => ({ default: module.GoldStoryProofPage })));
const DiscoveryMasterGold = lazy(() => import("@/pages/labs/DiscoveryMasterGold"));
const SandboxGoldRoutes = lazy(() => import("@/pages/labs/SandboxGoldRoutes"));

const WorldFallback = (<div style={{ position: "fixed", inset: 0, background: "#080808" }} />);
const MagazineFallback = (<div aria-hidden style={{ minHeight: "100vh", background: "#fff" }} />);
const LabFallback = (<div aria-hidden style={{ minHeight: "100vh", background: "#f4f1eb" }} />);
const ActorFallback = (<div aria-hidden style={{ minHeight: "100vh", background: "#080b10" }} />);
const toImpact = <Navigate to="/impact" replace />;
const toMarket = <Navigate to="/market" replace />;
const toJoin = <Navigate to="/join" replace />;
const toBrands = <Navigate to="/brands" replace />;
const toHome = <Navigate to="/" replace />;
function MtoMission() { const { slug } = useParams(); return <Navigate to={"/missions/" + slug} replace />; }
function RedirectTestUnit() { const { unit } = useParams(); return <Navigate to={`/impact/lab/${unit}`} replace />; }
function RedirectRecord() { const { recordId } = useParams(); return <Navigate to={`/impact/lab/records/${recordId}`} replace />; }
function ExternalRedirect({ to }: { to: string }) {
  useEffect(() => {
    window.location.replace(to);
  }, [to]);
  return <div aria-hidden style={{ minHeight: "100vh", background: "#fff" }} />;
}

export function AppRoutes() {
  return (
    <Suspense fallback={MagazineFallback}>
      <Routes>
      <Route path="/" element={<RootRoute />} />
      <Route path="/4nation/*" element={<Suspense fallback={LabFallback}><NationPage /></Suspense>} />
      <Route path="/labs" element={<LabsOverview />} />
      <Route path="/labs/gold" element={<Suspense fallback={LabFallback}><GoldTemplateSystemIndex /></Suspense>} />
      <Route path="/labs/gold/object/:slug" element={<Suspense fallback={LabFallback}><GoldObjectProofPage /></Suspense>} />
      <Route path="/labs/gold/story/:slug" element={<Suspense fallback={LabFallback}><GoldStoryProofPage /></Suspense>} />
      <Route path="/labs/gold/discovery/:slug" element={<Suspense fallback={LabFallback}><DiscoveryMasterGold /></Suspense>} />
      <Route path="/sandbox/gold/*" element={<Suspense fallback={LabFallback}><SandboxGoldRoutes /></Suspense>} />
      <Route path="/labs/food-user-test" element={<Suspense fallback={LabFallback}><FoodUserTest /></Suspense>} />
      <Route path="/labs/company-gold/tonys" element={<CompanyGoldTony />} />
      <Route path="/os" element={<LabsOverview />} />
      <Route path="/os/labs" element={<LabsOverview />} />
      <Route path="/story" element={<Navigate to="/" replace />} />
      <Route path="/domains" element={<DomainsIndex />} />
      <Route path="/domains/:key" element={<DomainWorld />} />
      <Route path="/missions" element={<MissionsIndex />} />
      <Route path="/missions/pl4stic" element={<Navigate to="/missions/cle4n" replace />} />
      <Route path="/missions/amazonia" element={<Navigate to="/missions/am4zonia" replace />} />
      <Route path="/missions/4ntarctica" element={<Navigate to="/missions/rewild-marine" replace />} />
      <Route path="/missions/rewild" element={<Navigate to="/missions/rewild-land" replace />} />
      <Route path="/missions/en3rgy" element={<Navigate to="/missions/en4rgy" replace />} />
      <Route path="/missions/4telier" element={toMarket} />
      <Route path="/missions/4rt" element={toMarket} />
      <Route path="/missions/m4gazine" element={<ExternalRedirect to="https://4planetmagazine.com" />} />
      <Route path="/missions/4film" element={<ExternalRedirect to="https://4planetmagazine.com/films" />} />
      <Route path="/culture/telier" element={toMarket} />
      <Route path="/domains/oce4n/pl4stic" element={<Navigate to="/missions/cle4n" replace />} />
      <Route path="/ecosystems/amazon-rainforest" element={<Navigate to="/missions/am4zonia" replace />} />
      <Route path="/missions/:slug" element={<MissionDetail />} />
      <Route path="/atlas" element={<Suspense fallback={WorldFallback}><PublicWorld /></Suspense>} />
      <Route path="/embed/atlas" element={<Suspense fallback={WorldFallback}><PublicWorld /></Suspense>} />
      <Route path="/atlas/:objectSlug" element={<AtlasDiscoveryPage />} />
      <Route path="/now" element={<EarthNowPage />} />
      <Route path="/earth-now" element={<Navigate to="/now" replace />} />
      {DISCOVERY_TOPIC_SLUGS.map((slug) => (
        <Route key={slug} path={`/${slug}`} element={<DiscoveryTopicPage slug={slug} />} />
      ))}
      <Route path="/places" element={<PlacesIndex />} />
      <Route path="/place/:slug" element={<PlaceRoute />} />
      <Route path="/species" element={<SpeciesIndex />} />
      <Route path="/species/lab" element={<SpeciesEngineLab />} />
      <Route path="/species/orca/lume" element={<Suspense fallback={WorldFallback}><LumeRoom /></Suspense>} />
      <Route path="/species/:slug" element={<SpeciesRoute curatedElement={<SpeciesProfilePage />} />} />
      <Route path="/lens" element={<LensCapture />} />
      <Route path="/food/lens" element={<FoodCapture />} />
      <Route path="/s4piens/food/lens" element={<FoodCapture />} />
      <Route path="/4sapien" element={<FourSapienHome />} />
      <Route path="/4sapien/food" element={<PickPrototype />} />
      <Route path="/4sapien/food/choose" element={<Suspense fallback={MagazineFallback}><EmblaFoodChoice /></Suspense>} />
      <Route path="/4sapien/finance" element={<FourFinanceHome />} />
      <Route path="/food/pick" element={<PickPrototype />} />
      <Route path="/impact" element={<ImpactPublicHome />} />
      <Route path="/impact/lab" element={<ImpactLabIndex />} />
      <Route path="/impact/lab/:unit" element={<ImpactTestJourney />} />
      <Route path="/impact/lab/records/:recordId" element={<PersonalImpactRecordPage />} />
      <Route path="/impact/test/:unit" element={<RedirectTestUnit />} />
      <Route path="/impact/record/:recordId" element={<RedirectRecord />} />
      <Route path="/impact/actions/bay-of-biscay-survey" element={<BayActionProof />} />
      <Route path="/impact/:slug" element={<ImpactStory />} />
      <Route path="/checkout/lab" element={<CommerceStripeLab />} />
      <Route path="/checkout/return" element={<CheckoutReturn />} />
      <Route path="/join" element={<Join />} />
      <Route path="/people" element={<People />} />
      <Route path="/brands" element={<Brands />} />
      <Route path="/partners" element={<Partners />} />
      <Route path="/actors" element={<Suspense fallback={ActorFallback}><ActorsIndex /></Suspense>} />
      <Route path="/actors/:slug" element={<Suspense fallback={ActorFallback}><ActorProfile /></Suspense>} />
      <Route path="/get-involved" element={<Suspense fallback={ActorFallback}><FindYourWayToHelp /></Suspense>} />
      <Route path="/funders" element={<Funders />} />
      <Route path="/living-systems" element={<ExternalRedirect to="/livingsystems/" />} />
      <Route path="/living-systems/oslofjorden" element={<Navigate to="/living-systems/oslofjord" replace />} />
      <Route path="/living-systems/oslofjord" element={<PlanetProofPage slug="oslofjorden" />} />
      <Route path="/living-systems/great-barrier-reef" element={<PlanetProofPage slug="great-barrier-reef" />} />
      <Route path="/living-systems/:slug" element={<LivingSystemJourney />} />
      <Route path="/reports" element={<Reports />} />
      <Route path="/about" element={<About />} />
      <Route path="/about/story" element={<AboutStory />} />
      <Route path="/about/system" element={<AboutSystem />} />
      <Route path="/about/what-we-believe" element={<WhatWeBelieve />} />
      <Route path="/about/founder" element={<Founder />} />
      <Route path="/magazine" element={<ExternalRedirect to="https://4planetmagazine.com" />} />
      <Route path="/magazine/about" element={<Suspense fallback={MagazineFallback}><MagazineAbout /></Suspense>} />
      <Route path="/magazine/sources" element={<Suspense fallback={MagazineFallback}><MagazineSources /></Suspense>} />
      <Route path="/magazine/corrections" element={<Suspense fallback={MagazineFallback}><MagazineCorrections /></Suspense>} />
      <Route path="/magazine/stories/:id" element={<Suspense fallback={MagazineFallback}><MagazineStoryRecord /></Suspense>} />
      <Route path="/magazine/:slug" element={<Suspense fallback={MagazineFallback}><StoryArticle /></Suspense>} />
      <Route path="/stories" element={<ExternalRedirect to="https://4planetmagazine.com" />} />
      <Route path="/stories/:slug" element={<Suspense fallback={MagazineFallback}><StoryArticle /></Suspense>} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/signal" element={<PlanetSignal />} />
      <Route path="/culture/film" element={<ExternalRedirect to="https://4planetmagazine.com/films" />} />
      <Route path="/culture/play" element={<CulturePlay />} />
      <Route path="/market" element={<MarketHome />} />
      <Route path="/cre4tor" element={<OdinCreatorPage />} />
      <Route path="/cre4tor/odin" element={<OdinCreatorPage />} />
      <Route path="/creator/odin" element={<OdinCreatorPage />} />
      <Route path="/os/*" element={<LabsOverview />} />
      <Route path="/m/:slug" element={<MtoMission />} />
      <Route path="/m/:slug/support" element={toImpact} />
      <Route path="/m/:slug/campaign" element={toImpact} />
      <Route path="/marketplace" element={toMarket} />
      <Route path="/store" element={toMarket} />
      <Route path="/cart" element={toMarket} />
      <Route path="/checkout" element={toMarket} />
      <Route path="/members" element={toJoin} />
      <Route path="/ambassadors" element={toJoin} />
      <Route path="/portal/*" element={toImpact} />
      <Route path="/sponsors" element={toBrands} />
      <Route path="/oce4n" element={<Navigate to="/domains/oce4n" replace />} />
      <Route path="/e4rth" element={<Navigate to="/domains/e4rth" replace />} />
      <Route path="/s4piens" element={<Navigate to="/domains/s4piens" replace />} />
      <Route path="/4culture" element={<Navigate to="/domains/4culture" replace />} />
      <Route path="/system" element={toHome} />
      <Route path="/404" element={<NotFound />} />
      <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
