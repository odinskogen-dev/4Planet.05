/**
 * GET /api/atlas-place?lat=59.05&lon=10.03&q=Q1,Q2&land=1
 *
 * What ATLAS can say about a point beyond its name (the name itself comes from
 * the static place files in /atlas-data/places — no call needed):
 *
 *   ecoregion — RESOLVE Ecoregions 2017 (CC BY 4.0, Dinerstein et al. 2017),
 *               read from UNEP-WCMC's public service: the ecoregion, its biome,
 *               its biogeographic realm and its "Nature Needs Half" status.
 *               Asked only for points on land (`land=1`); RESOLVE does not
 *               cover the ocean.
 *   about     — the lead of the English Wikipedia article (CC BY-SA 4.0) for
 *               the most specific named area the caller sends, resolved by
 *               Wikidata id so a name can never match the wrong article.
 *   ecoregionAbout — the same for the ecoregion itself, by its exact title.
 *
 * Server-side and cached, so the browser's Content-Security-Policy does not
 * widen and no visitor talks to a third party. Every part reports its own
 * status; a provider that fails is said to have failed, never shown as "none".
 */

type Json = Record<string, any>;
type Status = "OK" | "NONE" | "UNAVAILABLE" | "NOT_ASKED";

const USER_AGENT = "4PLANET-ATLAS/1.0 (+https://4planet.org/about)";
const ECOREGIONS =
  "https://data-gis.unep-wcmc.org/server/rest/services/Bio-geographicalRegions/Resolve_Ecoregions/FeatureServer/0/query";
const TIMEOUT_MS = 6500;
const DAY = 86_400;

const json = (body: unknown, status = 200, maxAge = DAY) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": `public, max-age=${maxAge}`,
      "access-control-allow-origin": "*",
    },
  });

async function getJson(url: string, ttl: number): Promise<{ ok: true; data: Json } | { ok: false; status: number | string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { accept: "application/json", "user-agent": USER_AGENT, "api-user-agent": USER_AGENT },
      cf: { cacheTtl: ttl, cacheEverything: true } as RequestInit["cf"],
    } as RequestInit);
    if (response.status === 404) return { ok: false, status: 404 };
    if (!response.ok) return { ok: false, status: response.status };
    return { ok: true, data: (await response.json()) as Json };
  } catch (error) {
    return { ok: false, status: (error as Error)?.name === "AbortError" ? "TIMEOUT" : "NETWORK" };
  } finally {
    clearTimeout(timer);
  }
}

const NNH: Record<string, string> = {
  "Half Protected": "At least half of this ecoregion is protected.",
  "Nature Could Reach Half Protected": "Enough natural habitat remains here for half of the ecoregion to be protected.",
  "Nature Could Recover": "Too little natural habitat remains for half to be protected today; restoration could change that.",
  "Nature Imperiled": "So little natural habitat remains that protecting what is left is urgent.",
};

export async function ecoregionAt(lat: number, lon: number) {
  const url = `${ECOREGIONS}?${new URLSearchParams({
    geometry: `${lon},${lat}`,
    geometryType: "esriGeometryPoint",
    inSR: "4326",
    spatialRel: "esriSpatialRelIntersects",
    outFields: "eco_name,biome_name,realm,nnh_name,eco_id,ecoregion_area_km2",
    returnGeometry: "false",
    f: "json",
  })}`;
  const result = await getJson(url, 30 * DAY);
  if (!result.ok) return { status: "UNAVAILABLE" as Status, value: null, error: String(result.status) };
  if (result.data?.error) return { status: "UNAVAILABLE" as Status, value: null, error: "PROVIDER_ERROR" };
  const a = result.data?.features?.[0]?.attributes;
  if (!a || !a.eco_name || /^rock and ice$/i.test(String(a.eco_name))) {
    return { status: "NONE" as Status, value: a?.eco_name ? { name: "Rock and ice", biome: a.biome_name || null, realm: null, nnh: null, nnhSentence: null, id: a.eco_id ?? null, areaKm2: null } : null };
  }
  return {
    status: "OK" as Status,
    value: {
      name: String(a.eco_name),
      biome: a.biome_name ? String(a.biome_name) : null,
      realm: a.realm && a.realm !== "N/A" ? String(a.realm) : null,
      nnh: a.nnh_name ? String(a.nnh_name) : null,
      nnhSentence: a.nnh_name ? NNH[String(a.nnh_name)] ?? null : null,
      id: typeof a.eco_id === "number" ? a.eco_id : null,
      areaKm2: typeof a.ecoregion_area_km2 === "number" ? Math.round(a.ecoregion_area_km2) : null,
    },
  };
}

async function summaryByTitle(title: string) {
  const result = await getJson(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`, 7 * DAY);
  if (!result.ok) return { status: (result.status === 404 ? "NONE" : "UNAVAILABLE") as Status, value: null };
  const d = result.data;
  if (d?.type !== "standard" || !d?.extract) return { status: "NONE" as Status, value: null };
  return {
    status: "OK" as Status,
    value: {
      title: String(d.title),
      description: d.description ? String(d.description) : null,
      // The lead, cut at a sentence boundary: the first read is two sentences.
      extract: leadOf(String(d.extract)),
      url: d.content_urls?.desktop?.page ? String(d.content_urls.desktop.page) : `https://en.wikipedia.org/wiki/${encodeURIComponent(String(d.title).replace(/ /g, "_"))}`,
      licence: "CC BY-SA 4.0",
      coordinates: d.coordinates && typeof d.coordinates.lat === "number" ? { lat: d.coordinates.lat, lon: d.coordinates.lon } : null,
    },
  };
}

export function leadOf(extract: string, max = 340) {
  const text = extract.replace(/\s+/g, " ").trim();
  if (text.length <= max) return text;
  const sentences = text.match(/[^.!?]+[.!?]+(\s|$)/g) ?? [text];
  let out = "";
  for (const sentence of sentences) {
    if ((out + sentence).length > max && out) break;
    out += sentence;
  }
  return out.trim() || `${text.slice(0, max).replace(/\s+\S*$/, "")}…`;
}

const km = (aLat: number, aLon: number, bLat: number, bLon: number) => {
  const r = Math.PI / 180;
  const s = Math.sin(((bLat - aLat) * r) / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(((bLon - aLon) * r) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(s)));
};

/**
 * A town's article, accepted only when Wikipedia's own coordinates for it are
 * within 25 km of the GeoNames town — so "Bergen" in Norway never shows the
 * article about Bergen in the Netherlands.
 */
export async function aboutTown(name: string, lat: number, lon: number) {
  const tried = [name];
  const summary = await summaryByTitle(name);
  const ok = (v: any) => v?.coordinates && km(lat, lon, v.coordinates.lat, v.coordinates.lon) <= 25;
  if (summary.status === "OK" && ok(summary.value)) return summary;
  if (summary.status === "UNAVAILABLE") return { status: "UNAVAILABLE" as Status, value: null, tried };
  return { status: "NONE" as Status, value: null, tried };
}

export async function aboutWikidata(ids: string[]) {
  let unavailable = false;
  for (const id of ids) {
    const entity = await getJson(
      `https://www.wikidata.org/w/api.php?${new URLSearchParams({ action: "wbgetentities", ids: id, props: "sitelinks", sitefilter: "enwiki", format: "json" })}`,
      30 * DAY,
    );
    if (!entity.ok) { unavailable = true; continue; }
    const title = entity.data?.entities?.[id]?.sitelinks?.enwiki?.title;
    if (!title) continue;
    const summary = await summaryByTitle(String(title));
    if (summary.status === "OK" && summary.value) return { status: "OK" as Status, value: { ...summary.value, wikidata: id } };
    if (summary.status === "UNAVAILABLE") unavailable = true;
  }
  return { status: (unavailable ? "UNAVAILABLE" : "NONE") as Status, value: null };
}

export const onRequestGet = async ({ request }: { request: Request }) => {
  const url = new URL(request.url);
  const lat = Number(url.searchParams.get("lat"));
  const lon = Number(url.searchParams.get("lon"));
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return json({ ok: false, error: "INVALID_COORDINATES" }, 400, 60);
  }
  const ids = String(url.searchParams.get("q") || "")
    .split(",").map((s) => s.trim()).filter((s) => /^Q\d{1,10}$/.test(s)).slice(0, 3);
  const land = url.searchParams.get("land") === "1";
  const town = String(url.searchParams.get("town") || "").trim().slice(0, 80);
  const tlat = Number(url.searchParams.get("tlat"));
  const tlon = Number(url.searchParams.get("tlon"));
  const askTown = town.length > 0 && Number.isFinite(tlat) && Number.isFinite(tlon);
  // Round so nearby taps share a cache entry (~1 km), without changing the answer
  // for anything ATLAS shows.
  const rlat = Math.round(lat * 100) / 100;
  const rlon = Math.round(lon * 100) / 100;

  const [eco, about] = await Promise.all([
    land ? ecoregionAt(rlat, rlon) : Promise.resolve({ status: "NOT_ASKED" as Status, value: null }),
    (async () => {
      if (askTown) {
        const t = await aboutTown(town, tlat, tlon);
        if (t.status === "OK") return t;
      }
      return ids.length ? aboutWikidata(ids) : { status: "NOT_ASKED" as Status, value: null };
    })(),
  ]);
  const ecoAbout = eco.status === "OK" && eco.value
    ? await summaryByTitle(eco.value.name)
    : { status: "NOT_ASKED" as Status, value: null };

  const allFailed = [eco.status, about.status].every((s) => s === "UNAVAILABLE" || s === "NOT_ASKED") &&
    [eco.status, about.status].some((s) => s === "UNAVAILABLE");
  return json({
    ok: true,
    retrievedAt: new Date().toISOString(),
    ecoregion: { status: eco.status, value: eco.value },
    about: { status: about.status, value: about.value },
    ecoregionAbout: { status: ecoAbout.status, value: ecoAbout.value },
    sources: {
      ecoregion: "RESOLVE Ecoregions 2017 · Dinerstein et al. 2017 · CC BY 4.0 · via UNEP-WCMC",
      about: "Wikipedia · CC BY-SA 4.0 · resolved through Wikidata",
    },
  }, 200, allFailed ? 120 : 7 * DAY);
};

export const onRequestOptions = () => new Response(null, {
  headers: {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, OPTIONS",
    "access-control-max-age": "86400",
  },
});
