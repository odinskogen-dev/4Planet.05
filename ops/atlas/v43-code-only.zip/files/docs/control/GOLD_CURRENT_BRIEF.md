# ATLAS R1.1 (package v43) — FOUNDER REVIEW ON iPHONE — 08 OCT 2026

**STATUS:** IMPLEMENTED + TESTED LOCALLY / CANDIDATE ON TOP OF v42 AGAINST HEIR `king/test@5dc63fe8ddd1daea32d62d102066705d3c7efbfe` / NOT MERGED / NOT DEPLOYED.

**FOUNDER DECISIONS (08 Oct 2026, after testing v42 on test-king):** dark map = Ink surfaces with E4RTH green (#3AE86F) as the one accent, including the 4PLANET wordmark; light map = Paper surfaces with 4PLANET Blue. Search is transparent until used. "People" is called **Sapiens**. The layer stays "Emission sources" and its source (Climate TRACE) is one tap away. Take in the open datasets ATLAS needs to name and describe any point. Only fully open images (CC0, CC BY, CC BY-SA). An easy way to 4planet.org from ATLAS; 4PLANET ID sign-in carried between our sites as on 4SAPIEN. Founder decisions outrank the older Brand OS line that keeps green to bounded success states, for ATLAS dark mode only.

## USER ARRIVES BECAUSE
They want to know what a place on Earth is and what lives there — any place, not only the twenty curated ones.

## ONE THING TO UNDERSTAND
Tap anywhere or search any place: ATLAS names it, says what landscape and living setting it belongs to, and shows what has been recorded there, each with its source.

## PRIMARY ACTION
Search any place or species — or tap Earth.

## SECONDARY DEPTH
Wikipedia lead (CC BY-SA, title always stated), geography at a glance (region, country, nearest town with distance, nearest peak, local time), RESOLVE ecoregion with biome, realm and Nature Needs Half status; then Sources and limits.

## P1 / P2 / P3 / P4
P1 Earth. P2 kind + true name ("Town · Larvik", "Strait · Skagerrak", "Desert · Ténéré · In the Sahara"). P3 Follow / More / Recenter. P4 sources, licences, distances, query geometry.

## WHAT CAN BE REMOVED
The always-loaded auth SDK for anonymous visitors; the first-match vernacular names ("Renard Roux"); citations in record titles; the floating Time box; the stretched black Time bar; a source notice that never leaves; unbounded address-bar writes.

## WHAT MUST BE REUSED
The same ContextLayer, COORDINATE kind, search surface, Pages Functions pattern, identity bridge (`bridgeSessionTo`), theme tokens. No new map engine, no new design system, no geocoder service.

## TRUTH BOUNDARY
A name is the area the point is in, or the nearest town with its distance. A Wikipedia lead always says which article it is. A town article is accepted only when Wikipedia's own coordinates are within 25 km. Ecoregions are land only. A failed place file, place function, Wikipedia or ecoregion read is said as unavailable, never as "nothing here". Images without a fully open licence are not shown.

## MOBILE-FIRST RISK
Safari's toolbar over sheets (sheets now clear it; real-device proof pending); per-tap download size (one 5° cell, ≤400 KB raw / ≤140 KB compressed in the densest cell); Safari's 100-per-10-s address-bar limit (now ≤40).

## HUMAN SUCCESS
On a phone, a tap in Siberia, the Sahara or the Skagerrak gives a name and a meaning in the first read — not "This point".

**DONOR DECISION:** none.

---

# ATLAS R1 — HUMAN AWE FIRST / PUBLIC EXPERIENCE P0 — 08 OCT 2026

**STATUS:** IMPLEMENTED + TESTED LOCALLY / CANDIDATE DELIVERY AGAINST HEIR `king/test@5dc63fe8ddd1daea32d62d102066705d3c7efbfe` / NOT MERGED / NOT DEPLOYED / FOUNDER iPHONE REVIEW PENDING.

**AUTHORITY:** Founder ATLAS master execution pack 07 Oct 2026 + AXE answers 07 Oct 2026 (three releases; R1 first; `4planetatlas.com` owns ATLAS + PLACE in search) + Brand OS with Founder Brand Reset 05 Oct 2026 (fresh-read from Drive `1bOIr3a83N53RVFZs_jibXr02cRS_RSP_bhCDVmN0_88`).

**BRAND OS PREFLIGHT:** user job — see what the living planet holds at a place, in a person's words · brand mode — REDUCED / MORE ICONIC utility surface around one immersive element · dominant idea — THE EARTH IS THE HERO · dominant visual anchor — the globe in its own dark space · obvious next action — search, or tap Earth · living-world presence — ENCOUNTER (the planet itself; documentary species photograph where the source licenses one) · active contextual accent — 4PLANET Blue, on Paper only, for the one decisive action (Brand OS §15.2A) · type hierarchy — Instrument Sans 26/24 display (weight 500), DM Sans 16/15/13.5/12.5 reading and interface, Fragment Mono 12/10.5 for identifiers at evidence depth only (7 levels) · grid / whitespace — one 384px column beside Earth on wide screens, one sheet beneath it on compact screens, 16/20px gutters · geometry — one radius family 12 / 22 / capsule, one elevation, two line strengths · deliberately deferred — weather, local time, NOW geographic relevance, TIME model, COMPARE, global place search (geocoder needs a rights decision).

## USER ARRIVES BECAUSE
They searched for a place, a species or a planetary phenomenon and landed on ATLAS from Google, on a phone, never having heard of 4PLANET.

## ONE THING TO UNDERSTAND
This is an interactive view of the living planet: tap or search anywhere and see what has actually been recorded there, with where it came from.

## PRIMARY ACTION
Search a place or species — or tap anywhere on Earth.

## SECONDARY DEPTH
More (relationships, pressures, reported events) on request; then SOURCES AND LIMITS: exact source, query geometry, counts, identifiers, check times and every caveat, one tap away on every object.

## P1 DOMINANT
Earth. Resting chrome (wordmark, search line, dock, zoom) covers under a fifth of a 390×844 screen.

## P2 ORIENTATION
A plain kind word and a name ("Marine area · Oslofjord", "Species · Orca", "Here · Near Larvik"), one human sentence, and the species with the most records in the area by common name.

## P3 ACTION / NEXT
Follow (the one blue action) and "More about …", both reachable without scrolling; four dock doors — Now, Layers, Watch, My Atlas.

## P4 DEPTH
Identifiers, coordinates, bounding-box caveats, record counts, source links, review/evidence axes, per-source coverage (Layers → Sources and coverage), layer source/time-class/legend/opacity.

## WHAT CAN BE REMOVED
Removed: the all-mono uppercase console voice; internal ids, coordinates, SEEDED/LIVE badges and BOUNDING BOX rows on the first read; separate floating Layers and My Atlas buttons; the EARTH lens button (closing a surface IS Earth); the duplicated desktop wordmark; the status strip readout; the unused `atlasPolish.css` override sheet and its body-wide MutationObserver sidecar; the `window.fetch` interception sidecar; a second basemap style load at every boot; a full basemap re-style on every panel open/close.

## WHAT MUST BE REUSED
One MapLibre engine, one ContextLayer, one layer registry, one signal pool, one camera authority, the existing follow / saved-view / 4PLANET ID stores, the existing `/api/atlas-feed` and `/api/atlas-wms` bridges, the shared typographic product switcher, Brand OS type and colour tokens. No parallel Context engine, no second design system, no new source.

## TRUTH BOUNDARY
Hide complexity, never hide uncertainty. A gap (source unavailable, nothing returned, not checked, no coverage, bundled-not-live) is spoken in words on the first read; a sound section carries its origin as a caption and its provenance in SOURCES AND LIMITS. Query area ≠ place membership; a tapped point is named only by the nearest basemap label WITH its distance, or not at all; "most recorded" is a statement about records in a query area, not a species list; source failure ≠ zero; LIVE only for a genuinely live source; nothing is promoted to an alert.

## MOBILE-FIRST RISK
A control floating over a sheet; iOS focus-zoom leaving the page panned; a sheet covering the thing selected; touch targets under 44px; text under 12px; horizontal overflow; search results under the keyboard; map not recovering after repeated surfaces. Each is covered by `tests/e2e/atlas-r1-human-awe.spec.ts` at 390×844 and 430×932 except real-device Safari and the real keyboard, which remain human gates.

## HUMAN SUCCESS
A person who has never heard of 4PLANET opens ATLAS on a phone and, without instruction, searches or taps, reads what lives there in ordinary words, sees where that came from when they ask, follows something, and comes back. Technical PASS is not this; Founder iPhone review on `test.4planet.org/atlas` and observed users decide it.

**DONOR DECISION:** none adopted. The unmounted `atlasPolish.css` / `AtlasHumanSurfacePolish.tsx` donor layer is REJECTED WITH REASON (an `!important` correction sheet plus a body-wide MutationObserver — the pattern this release retires) and removed.

**RELEASE:** delivered as a versioned patch against the exact HEIR parent. AXE owns apply, sandbox-registry reconciliation, final gates, deploy, Search Console and public LIVE verification.

---

# WHAT WE BELIEVE — HOMEPAGE DISCOVERY SYNC — 07 OCT 2026

**STATUS:** BOUNDED HEIR FOLLOW-UP / SAME VALUES CANDIDATE / NO NEW CANON.

**DELTA:** The existing homepage belief section now routes directly to `/about/what-we-believe` instead of generic `/about`, and its invitation matches canonical intent: “There is a place for everyone who wants to help — including you.”

**WHY:** Values must be discoverable in normal product journeys, not hidden only inside About navigation. Reuse the existing homepage belief block; create no new campaign or duplicate values source.

**TRUTH / SCOPE:** Homepage language remains a short public derivative. Canon remains the single Drive Founder Thesis authority. No product claim, impact claim or new value is introduced.

**MOBILE RISK:** Longer invitation heading must wrap without overflow.

**RELEASE:** Same exact-artifact QA and bounded LIVE release as the owning WHAT WE BELIEVE candidate.

---

# WHAT WE BELIEVE — CANON WORDING SYNC + HUMAN INVITATION — 07 OCT 2026

**STATUS:** BOUNDED HEIR CANDIDATE / FOUNDER-APPROVED VALUES CANON SYNC / LIVE RELEASE REQUIRES EXACT TESTED ARTIFACT.

## USER ARRIVES BECAUSE
A person wants to understand why 4PLANET exists, what it believes, how it behaves and whether there is a meaningful place for them to contribute.

## ONE THING TO UNDERSTAND
The website is a public projection of the single canonical WHAT WE BELIEVE Founder Thesis. It does not own or fork the values.

## PRIMARY ACTION
Read `/about/what-we-believe`, understand the seven values and continue through `FIND YOUR PART` if the person wants to contribute.

## SECONDARY DEPTH
The page exposes purpose, ambition, beliefs, values, behaviours, brand law and invitation without replacing The Story, The System or The Founder.

## P1 DOMINANT
FOR A LIVING PLANET: “people and the rest of nature can thrive together.” People are explicitly part of nature, not outside it.

## P2 ORIENTATION
BETTER. FOR EVERYONE. now uses solutions language: create broad, durable value without quietly moving costs to other people, species, places or generations.

## P3 ACTION / NEXT
EVERYONE HAS A PART TO PLAY: “No one solves problems this big alone. Together, we can.” The invitation is explicitly for everyone who wants to help, including the reader.

## P4 DEPTH
HOW WE BEHAVE starts with “Love life. Care deeply for the living world.” Curiosity, truth, courage, welcome, listening, sharing, mutual help, ownership, finishing, correction and learning remain behaviours under the values rather than competing top-level values.

## WHAT CAN BE REMOVED
No new values document, no second manifesto, no alternative values list, no generic empowerment slogan.

## WHAT MUST BE REUSED
Canonical Drive authority `1dzdFFP_9IxJSORKxRgcxeZ5TKgJaQwDMD3XFcu8YoVE`; existing About architecture; existing public route; existing 7-value structure; existing Join route.

## TRUTH BOUNDARY
“Including you” applies to people who want to help in good faith. Inclusion does not waive truth, safety, dignity, law or responsible-conduct standards. “Together, we can” is an agency statement, not a claim that every problem is solvable or that 4PLANET has already solved it.

## MOBILE-FIRST RISK
Long invitation heading and behaviour copy must wrap cleanly at 390/430 without horizontal overflow or hierarchy collapse.

## HUMAN SUCCESS
A first-time visitor can explain purpose, values and expected behaviour, and feels invited into a meaningful contribution path without being told they must become an activist or expert.

**RELEASE:** Founder has explicitly asked to get this values work LIVE, but production promotion remains bound to exact candidate QA and bounded release so unrelated TEST KING work is not promoted.

---

# LIVE PROMOTION AUTHORITY TOKEN CONVERGENCE — 07 OCT 2026

**STATUS:** RELEASE-CONTROL REPAIR / NO PRODUCT BYTE CHANGE / NO LIVE BYPASS.

## USER ARRIVES BECAUSE
A Founder-authorised, fully tested public product change must be able to move from the sole TEST KING to LIVE through one internally consistent release contract.

## ONE THING TO UNDERSTAND
Two existing release guards used different success tokens for the same Founder decision: `FOUNDER_ACCEPTED` and `FOUNDER_AUTHORISED`. One manifest cannot satisfy both. The canonical token is now `FOUNDER_AUTHORISED` in both guards.

## PRIMARY ACTION
Require one exact Founder-authorised manifest status across GOLD PR-to-main validation and the LIVE exact-artifact guard.

## SECONDARY DEPTH
Preserve every other exact-artifact condition: source branch `king/test`, tested SHA, prior LIVE SHA, Founder decision reference, evidence reference and rollback reference.

## P1 DOMINANT
Release-control consistency. No application route, content, design, data or product runtime changes.

## P2 ORIENTATION
The current Discovery Engine candidate remains the tested product objective; this change only makes the existing release gates mutually satisfiable.

## P3 ACTION / NEXT
Run the full exact-SHA gate set again, then create the manifest-only release-control child commit after all required product gates pass.

## P4 DEPTH
A regression test reads both release guards and fails if the authorised status token diverges again.

## WHAT CAN BE REMOVED
The obsolete `FOUNDER_ACCEPTED` token from the GOLD promotion path.

## WHAT MUST BE REUSED
Existing LIVE_PROMOTION_MANIFEST, sole TEST KING authority, exact-artifact law, rollback identity, GOLD policy and live-promotion guard.

## TRUTH BOUNDARY
This control repair does not authorise a release by itself. LIVE still requires explicit Founder authority already given for DISCOVERY ENGINE 01, successful exact-SHA evidence, and the manifest-only release-control commit.

## MOBILE-FIRST RISK
None. No user-facing runtime byte changes.

## HUMAN SUCCESS
A valid Founder-authorised artifact can pass both release guards without weakening either guard or bypassing any evidence requirement.

---

# DISCOVERY ENGINE 01 — ROUTE-LEVEL BUNDLE SPLIT — 07 OCT 2026

**STATUS:** BOUNDED PERFORMANCE / RELEASE-GATE FIX FOR THE FOUNDER-AUTHORISED DISCOVERY LIVE OBJECTIVE.

## USER ARRIVES BECAUSE
Public discovery and the rest of 4PLANET must load without forcing every secondary product surface into the first JavaScript payload.

## ONE THING TO UNDERSTAND
The existing router eagerly imported many independent product pages. This change converts secondary routes to React lazy boundaries so the initial bundle carries only what the current route needs.

## PRIMARY ACTION
Preserve every existing public URL and route behaviour while reducing the main production bundle below the existing convergence threshold.

## SECONDARY DEPTH
Discovery Engine pages, Species, Places, Impact, Labs, 4SAPIEN, About, Market and other secondary surfaces are fetched as route chunks only when entered.

## P1 DOMINANT
No product redesign. No URL change. No content change. Main-bundle reduction only.

## P2 ORIENTATION
Home stays eager; existing already-lazy ATLAS, Magazine and specialist flows remain lazy; newly deferred routes use one shared top-level Suspense boundary.

## P3 ACTION / NEXT
Exact typecheck, build, smoke, security, browser and bundle evidence decide acceptance.

## P4 DEPTH
The 20 discovery slugs stay explicit in the router layer while the full discovery data/content module moves out of the initial bundle.

## WHAT CAN BE REMOVED
Eager imports of route modules that are not required to render the current entry route.

## WHAT MUST BE REUSED
Existing React Router, existing route paths, current page components, existing fallbacks, Master Brand OS and all current product data.

## TRUTH BOUNDARY
A smaller bundle is a delivery improvement, not evidence of better content or product outcomes. No route is removed or renamed.

## MOBILE-FIRST RISK
Lazy loading must not create blank navigation states; the existing white/public, dark/world and lab fallbacks remain available.

## HUMAN SUCCESS
Users reach the same destinations with the same content while initial JavaScript is materially smaller and the existing convergence budget is met.

---

# DISCOVERY ENGINE 01 — ROUTER SECURITY REMEDIATION — 07 OCT 2026

**STATUS:** BOUNDED RELEASE BLOCKER FIX FOR THE FOUNDER-AUTHORISED DISCOVERY LIVE OBJECTIVE.

**USER ARRIVES BECAUSE:** the public discovery surfaces must reach production without bypassing the repository's dependency-security gate.

**ONE THING TO UNDERSTAND:** React Router 6.30.4 is blocked by current security advisories with no patched 6.x release. This bounded change migrates the existing declarative router dependency to 7.18.4; it does not redesign routing.

**PRIMARY ACTION:** preserve all existing routes and Discovery Engine behaviour while clearing the security audit.

**SECONDARY DEPTH:** exact typecheck, build, smoke, GOLD and browser gates must prove compatibility before LIVE promotion.

**P1 DOMINANT:** dependency security remediation only.

**P2 ORIENTATION:** existing BrowserRouter / Routes / Route / Link / Navigate / hooks remain the application routing model.

**P3 ACTION / NEXT:** if any compatibility regression appears, repair the specific route behaviour; do not suppress npm audit.

**P4 DEPTH:** package-lock is updated to the exact 7.18.4 router artifacts and required cookie/set-cookie-parser transitive dependencies.

**WHAT CAN BE REMOVED:** obsolete @remix-run/router 1.23.3 transitive package from the v6 line.

**WHAT MUST BE REUSED:** existing route definitions, PublicShell, Discovery Engine, identity/auth and all product URLs.

**TRUTH BOUNDARY:** passing dependency audit does not itself prove UI correctness; typecheck/build/smoke/browser proof remain required.

**MOBILE-FIRST RISK:** no intended visual/mobile change; regression gates remain authority.

**HUMAN SUCCESS:** users see no routing regression, while the release no longer ships the blocked router dependency.

---

# LIVING SYSTEMS v1.4.2 — QA CORRECTION 02 — 06 OCT 2026

**CONCURRENT HEIR CHANGE:** The Founder-authorised homepage premium refinement landed after the canonical route fix and rewrote the product-card tuple, restoring its prior `/living-systems` target as part of that refactor.

**RECONCILIATION:** Preserve the entire new homepage refinement. Change only the Living Systems target to `/livingsystems/` and full-document navigation so the standalone recovered Next product is loaded. Harden the contract to ignore cosmetic label case.

**ZERO LOSS:** 88/88 historical v1.4.2 source files remain untouched. No current homepage visual work is reverted.

---

# 4PLANET HOMEPAGE — BRAND + COPY REFINEMENT LIVE CANDIDATE — 06 OCT 2026

**STATUS:** FOUNDER-AUTHORISED BOUNDED LIVE CANDIDATE / EXACT-HEAD HUMAN CRAFT + ATLAS ZERO LOSS REQUIRED BEFORE LIVE CLAIM.

**FOUNDER DIRECTION:** 06 OCT 2026 — complete and publish the agreed 4planet.org homepage refinement now, then report exactly what changed.

**BOUNDED LIVE SCOPE:** Homepage presentation/copy and the existing first-party ATLAS homepage embed only. Preserve current routing, shared ATLAS renderer, camera authority, source model, auth, data and product architecture.

**USER / BRAND JOB:** A first-time visitor should quickly understand what 4Planet is, why it exists, how the four lenses help, why the four Domains exist, and where credible action can begin — while the page feels calm, premium, human and unmistakably 4Planet.

**VISUAL / COPY CHANGES:** pure white light surfaces; restrained card shadows; materially less mono; no unnecessary all-caps or underscores in body copy; 4Planet casing in prose; black-on-white Lens cards; controlled headline line-breaks; clearer Impact development language; blue Domains introduction with white text; one non-duplicated Domain title per image; explicit Marine / Terrestrial / Human / Cultural system descriptors; closer Orca encounter; blue DJ 4Culture visual; researcher visual retained before Join.

**ATLAS:** Homepage embed reuses the existing MapLibre World and canonical Layers console, with one separate blue trigger that only opens/closes that existing console. No second map, camera, data or layer authority. Full ATLAS and homepage embed use lower-cost WebGL rendering, a bounded tile cache and short tile fade to reduce visible loading/popping during movement.

**TRUTH / IMPACT:** Impact pathways remain explicitly in development. No public participation, delivery, partner, outcome or ecological-impact claim is promoted by this release.

**ACCEPTANCE:** exact-head typecheck/build; Human Craft desktop-1440 + mobile-390 + mobile-430; real white-mode MapLibre canvas + functional Layers trigger; ATLAS Zero Loss; no horizontal overflow.

---
# DISCOVERY RELEASE SECURITY CORRECTION — SOURCE-MAP-JS 1.2.2 — 06 OCT 2026

**STATUS:** CONTROLLED DEPENDENCY PATCH / NO DISCOVERY PRODUCT SEMANTIC CHANGE.

**WHY:** exact TEST KING Public Preview passed typecheck, production build and the full smoke suite, including DISCOVERY ENGINE 01, then failed only because the current dependency audit flags a high-severity `source-map-js <1.2.2` advisory.

**CHANGE:** update the existing transitive `source-map-js` lock entry from 1.2.1 to patched 1.2.2. PostCSS already accepts the compatible `^1.2.1` range. No application source, route, content, source claim, ATLAS behavior or design is altered.

**PROOF REQUIRED:** `npm ci` → typecheck → production build → smoke → `npm audit --audit-level=high` on the new exact TEST KING SHA.

**SOURCE:** GitHub Advisory GHSA-68fv-2mgg-jv7q / CVE-2026-93749.

---

# LIVING SYSTEMS v1.4.2 — QA CORRECTION 01 — 06 OCT 2026

**CAUSE:** TEST KING Home uses a six-field product tuple. The initial bounded route transform targeted the older five-field shape, so the tuple stayed at `/living-systems` while `reloadDocument` expected `/livingsystems/`. TypeScript correctly failed closed.

**CORRECTION:** Change only the LIVING SYSTEMS tuple target to `/livingsystems/` and harden the recovery contract to assert the actual tuple.

**ZERO LOSS:** All 88 recovered v1.4.2 source files remain untouched. No historical visual, graph, intelligence or data semantics changed.

---

# LIVING SYSTEMS v1.4.2 ZERO LOSS — FOUNDER-AUTHORISED LIVE CANDIDATE — 06 OCT 2026

**STATUS:** TEST KING CANDIDATE / FOUNDER AUTHORISED FOR BOUNDED LIVE RELEASE AFTER EXACT-SHA QA + RUNTIME READBACK.

**FOUNDER DECISION:** 06 OCT 2026 — recover the complete historical Living Systems v1.4.2 line-for-line with ZERO LOSS, preserve its full intelligence engine and exact visual baseline, make it the leading Living Systems public product, and release it at 4planet.org/livingsystems. Newer work becomes donor material only after intact recovery.

**SOURCE AUTHORITY:** `odinskogen-dev/4Planet_LivingSystems1.4.2@0a849ff3fd28e6cc6abcd04c95c5292410443502`. 88/88 historical source files. No historical source file is edited for recovery.

**LIVE BOUNDARY:** Living Systems v1.4.2 product tree + build wrapper + 4PLANET home lens/link + canonical sitemap/legacy landing redirect. No wholesale TEST KING promotion. Existing newer Living Systems implementation remains donor/history.

**ROLLBACK:** preserve the exact prior LIVE main SHA at promotion time and immutable prior Pages deployment. No LIVE claim before exact custom-domain readback.

## USER ARRIVES BECAUSE
They want to understand how species, ecosystems, ecological functions, ecosystem services, human systems, threats and solutions depend on one another.

## ONE THING TO UNDERSTAND
Living systems are networks of relationships and dependencies; species and places are entry points, while the relationships are the core intelligence asset.

## PRIMARY ACTION
Start a guided Living Systems journey and move through the connected dependency graph.

## SECONDARY DEPTH
Explore ecosystems, species, dependencies, solutions, decisions, learning, trust and original sources without leaving the same recovered intelligence model.

## P1 DOMINANT
The intact v1.4.2 Living Systems product and its Human Use entry into the graph.

## P2 ORIENTATION
Clear relationship pathways showing what depends on what, why it matters and what can fail or help.

## P3 ACTION / NEXT
Continue into a related species, ecosystem, solution, decision pathway, learning record or source; later donor integration may connect the same object to ATLAS and current NATUREBRAIN.

## P4 DEPTH
Reverse dependencies, recursive failure cascades, claims/sources/trust, data quality, Solution Intelligence, Decision Intelligence and Learning Intelligence.

## WHAT CAN BE REMOVED
Nothing from the historical v1.4.2 source during recovery. Cleanup/redesign is explicitly deferred until full intact live proof exists.

## WHAT MUST BE REUSED
All 88 historical v1.4.2 source files, historical visual language, graph engine, registry/data model, trust/source logic, dependency and cascade logic, Solution/Decision/Learning intelligence, Human Use Translation, Amazon and Pollination/Food proof cases.

## TRUTH BOUNDARY
Historical examples remain structured intelligence/prototype evidence, not proof of live ecological outcomes. Decision Intelligence is structured reasoning, not automated advice. NATUREBRAIN integration later must preserve or expand recovered semantics and source/uncertainty boundaries.

## MOBILE-FIRST RISK
The historical product must render and navigate correctly under the /livingsystems base path on mobile without changing its visual language or breaking internal links.

## HUMAN SUCCESS
A first-time visitor can enter Living Systems, understand a real dependency pathway, move to deeper intelligence and inspect trust/source context while seeing the same v1.4.2 product recovered intact.

---

# 4PLANET DISCOVERY ENGINE 01 — EARTH NOW + 20 CANONICAL LIVE DISCOVERY SURFACES — 06 OCT 2026

**STATUS:** BOUNDED PUBLIC PRODUCT CANDIDATE / FOUNDER LIVE INTENT EXPLICIT / EXACT-ARTIFACT QA REQUIRED BEFORE PRODUCTION PROMOTION.

## USER ARRIVES BECAUSE
A person searches Google, Bing or an AI assistant for a real environmental subject — for example wildfires, earthquakes, climate change, biodiversity, orca, Oslofjord or renewable energy — and needs a useful, source-grounded 4PLANET answer that can continue into the living product.

## ONE THING TO UNDERSTAND
Discovery is a product entry layer over existing 4PLANET intelligence, not a content farm. One permanent canonical URL should become more useful as sources, relationships and visualisation improve.

## PRIMARY ACTION
Read the answer and key source boundary, then inspect the same subject through the embedded canonical 4PLANET ATLAS.

## SECONDARY DEPTH
Continue into related SPECIES, PLACE, Living Systems, Mission, Impact, S4PIENS or 4BRANDS journeys where the existing product graph supports them.

## P1 DOMINANT
EARTH NOW at `/now`: “What is happening on Earth right now?” with latest-available planetary signals and a visible warning that the sources do not share one synchronized real-time clock.

## P2 ORIENTATION
Twenty permanent source-grounded topic pages: Wildfires, Earthquakes, Climate Change, Biodiversity, Deforestation, Plastic Pollution, Coral Bleaching, Air Quality, Orca, Whales, Bees, Amazon Rainforest, Oslofjord, Renewable Energy, Solar Energy, Food Waste, Fast Fashion, Rewilding, Climate Solutions and Environmental Jobs.

## P3 ACTION / NEXT
Each page exposes its canonical source list, latest checked date, an embedded canonical ATLAS view and relevant internal product connections. Earth Now links back into permanent topic pages instead of becoming a disposable feed.

## P4 DEPTH
Crawler-readable prerendered HTML, canonical metadata, OG/Twitter metadata, JSON-LD, Breadcrumb/ItemList structures, sitemap inclusion and explicit establishes / does-not-establish boundaries. Machine readability remains subordinate to human usefulness.

## WHAT CAN BE REMOVED
No new CMS, SEO database, second ATLAS, trend database, duplicate Brain, keyword-stuffed FAQ system or separate design system. Existing discovery, source, ATLAS, PublicShell, analytics, sitemap and prerender infrastructure are reused.

## WHAT MUST BE REUSED
Current Master Brand OS and PublicShell; current `src/data/discoveryInventory.json` and `atlasDiscovery.json`; existing source/provenance discipline; canonical `4planetatlas.com` renderer and its existing layers; current sitemap/prerender pipeline; existing analytics event seam.

## TRUTH BOUNDARY
“Earth Now” means latest available per source, never one universal real-time Earth. Thermal anomaly ≠ confirmed wildfire. Occurrence record ≠ current animal position, abundance or migration route. Tree-cover loss ≠ automatically deforestation. Coral thermal stress ≠ observed bleaching. Aerosol optical depth ≠ ground-level air quality. Context layers are labelled as context where no direct topic layer exists. No indexation, ranking or AI citation is claimed without measurement.

## MOBILE-FIRST RISK
The embedded ATLAS must remain usable at 390/430 widths without horizontal page overflow; topic fact strips and signal rows must collapse cleanly; search-readable fallback must not create duplicate visible content after hydration.

## HUMAN SUCCESS
A first-time visitor can understand the topic within seconds, see what is known versus not established, inspect the original sources, use the map and continue into a deeper 4PLANET object without encountering generic generated SEO prose.

**FOUNDER LIVE INTENT:** On 06 Oct 2026 the Founder explicitly corrected the execution target: “Det er selvsagt Live sidene som må oppdages” and instructed execution to continue. This authorises the LIVE objective for this bounded discovery change, but the production manifest is populated only after the exact integrated artifact has passed the required QA gates.

**RELEASE PATH:** bounded change → sole TEST KING integration → exact-sha QA/evidence → manifest-only Founder release control → production promotion → physical readback on `https://4planet.org/now` and all 20 canonical URLs. Do not stop at TEST/HEIR.

---

# 4BRANDS PUBLIC COMPANY INTELLIGENCE + PREMIUM PRODUCT REBUILD 01 — 06 OCT 2026

**STATUS:** HEIR PRODUCT CANDIDATE / PUBLIC-FIRST COMPANY INTELLIGENCE / NO LIVE RELEASE.

**USER ARRIVES BECAUSE:** a leader, employee, investor, supplier or curious person wants one source-grounded view of what the public world can establish about a company before connecting private data.

**ONE THING TO UNDERSTAND:** exact legal identity comes first. 4BRANDS then separates public FACTS, transparent CALCULATIONS, source SIGNALS, bounded HYPOTHESES and explicit UNKNOWNs instead of generating an AI company essay.

**PRIMARY ACTION:** search a company → resolve the exact BRREG legal entity → inspect its public intelligence profile.

**P1 DOMINANT:** legal company identity, source coverage, key register/financial facts and material change state.

**P2 ORIENTATION:** BUSINESS / FINANCIALS / MARKET / PROCUREMENT / INNOVATION / CAPITAL / PLANET / STRUCTURE / PEOPLE / CHANGES / FINDINGS / SOURCES use progressive disclosure rather than one long report.

**P3 ACTION:** inspect original evidence; use TED demand search; review a Climate TRACE owner identity before showing facility records; inspect exact-legal-name CORDIS relationships; authenticate through existing 4PLANET ID before private Company Brain depth.

**P4 DEPTH:** BRREG roles, group structure, subunits, updates, annual-account availability, latest open key figures and industry cohort; GLEIF exact registration-number identity where available; BRREG-anchored first-party website discovery; CORDIS EURIO; TED; reviewed Climate TRACE.

**DESIGN CONTRACT:** current BRAND OS is authority; historical BRAND OS is donor. PAPER/INK dominate, thin rules/grids, Instrument Sans + DM Sans + bounded Fragment Mono, restrained type scale, no pill-heavy SaaS chrome, no gradient/glow/shadow aesthetic, no giant generic hero typography. REVEAL COMPLEXITY, NOT DISPLAY COMPLEXITY.

**TRUTH BOUNDARIES:** industry cohort ≠ proven competitor set. Published procurement notice ≠ eligibility/contract/payment. Company website content = first-party claim context until corroborated. CORDIS participation/funding-role value ≠ company revenue/cash/profit/current funding availability. Climate TRACE name similarity never becomes a company emissions claim without explicit owner review. Local “last seen” state is non-authoritative UI state; source events remain authoritative.

**SOURCE ACCESS:** a BRREG-registered company website may block automated retrieval. HTTP access control is recorded as SOURCE_UNAVAILABLE / access-controlled, not bypassed and not converted to a fact about the company. Gold requires the first-party mechanism to physically fetch at least one registered website in the real-company matrix where the publisher permits it.

**KNOWN EXTERNAL BLOCKERS:** EPO OPS patent intelligence requires external developer/OAuth credentials and is not presented as connected. Doffin-only national notice coverage remains open until its structured public API path is verified; TED is the currently connected public procurement source. Arbitrary old AI “Research deeper” remains separate and fail-closed where its server model credential is absent.

**RETURN VALUE:** WHAT CHANGED is first-class. A bounded local visit marker can label new register events since the previous visit without becoming a truth store or notification system.

**GOLD MATRIX:** real BRREG source audit on TOMRA, EQUINOR, TELENOR, DNB, KONGSBERG, HYDRO, ORKLA, MOWI, STOREBRAND and AKER BP; dedicated desktop 1440 + mobile 390 public-first browser proof; real open-source liveness for BRREG/first-party, CORDIS, TED and Climate TRACE.

**HUMAN SUCCESS:** the free profile is useful without private data: exact identity, inspectable evidence, material public facts, change context, bounded signals, source tools and explicit unknowns can be navigated without reading a giant AI report.

**FOUR-STATE AUTHORITY:** affected product = 4BRANDS. LIVE = https://4brands.org/ and remains existing production/readback state. HEIR = sole king/test exact candidate. Historical BRAND OS and other donors remain read-only. No new BRAIN, company DB, design-system master or control plane is created.

**RELEASE:** HEIR only. Production/custom-domain promotion remains exact-artifact Founder-gated after independent Gold. Passing CI, preview or merge is not LIVE authority.

---

# HOMEPAGE BRAND RESET — HUMAN CRAFT CONTRACT CORRECTION — 06 OCT 2026

**STATUS:** HEIR QA CONTRACT CORRECTION · PRODUCT SOURCE UNCHANGED · NO LIVE RELEASE.

The first exact-sha Human Craft run failed because its homepage test still required the previous hero links `WHY 4PLANET` and `OPEN ATLAS` and the previous WHY/lens headings. Founder direction in the immediately preceding product commit changed that hierarchy to `EXPLORE THE PLANET` + `JOIN US`, a white human-life premise, an embedded shared ATLAS, the revised four-lens headline, one Orca visual encounter, the preserved four Domain worlds and a four-image asymmetric IMPACT action gallery.

This correction updates the existing Human Craft regression contract to protect the current Founder-approved hierarchy. It additionally asserts the embedded shared ATLAS, four lens entries, Orca encounter, four Domain worlds, four IMPACT entries and the visible “NOT YET OPEN FOR PUBLIC SUPPORT” boundary. Existing navigation, overflow and mobile Domain-width checks remain.

**PRODUCT CODE:** unchanged from `67f93a9c7a3548a30af869cca6586b2b5fb0ccdb`.

**OBSERVED SEPARATE CONVERGENCE DEBT:** the ONE INTERFACE bundle gate was already failing before this homepage change because the largest JS chunk exceeded the historical 1,800,000-byte threshold. Previous HEIR b833973: 1,922,585 bytes. Homepage-reset candidate 67f93a9: 1,913,134 bytes. The homepage reset therefore reduced the largest JS chunk by 9,451 bytes and did not create that blocker. No unrelated bundle threshold or architecture is changed here.

**ROLLBACK:** exact parent `67f93a9c7a3548a30af869cca6586b2b5fb0ccdb`.

---

# 4PLANET HOMEPAGE BRAND RESET — 06 OCT 2026

**STATUS:** HEIR-ONLY FOUNDER-DIRECTED BRAND / EDITORIAL REFACTOR · NO LIVE RELEASE.

**FOUNDER INTENT / HUMAN VALUE:** make the 4PLANET front door feel unmistakably 4PLANET: calm, elegant, intelligent, cinematic where earned, documentary-life-first and immediately useful — while preserving the working product architecture and showing visitors that they can move from understanding into real action pathways.

**USER ARRIVES BECAUSE:** a first-time visitor wants to understand what 4PLANET is, feel why it matters, explore the living planet and discover a credible way to go deeper or take part.

**ONE THING TO UNDERSTAND:** 4PLANET connects one living planet through shared intelligence, distinct lenses, living worlds and evidence-aware pathways from understanding toward action.

**PRIMARY ACTION:** EXPLORE THE PLANET → existing shared ATLAS.

**SECONDARY ACTION:** JOIN US → existing /join route.

**P1 DOMINANT:** cinematic Earth encounter with “4PLANET_ For a Living Planet” and “Everything you love is connected.” The underscore is the separator; no dot/dash is inserted after it.

**P2 ORIENTATION:** calm white premise → live shared ATLAS → “ONE PLANET_ FOUR LENSES” index using 01_ ATLAS / 02_ SPECIES / 03_ LIVING SYSTEMS / 04_ IMPACT.

**P3 LIFE / WORLD:** one bounded visual Orca encounter only, then the four existing large immersive Domain worlds. No second Orca story is added.

**P4 ACTION / PROOF:** retain all four existing IMPACT images and pathways, but change the homepage presentation from a competing dark 2×2 world grid to a white asymmetric editorial action gallery: one leading action plus three smaller visual entries. Truth-status wording remains visible; public support is not implied open.

**CLOSE / BELONGING:** one quiet WHAT WE BELIEVE + JOIN section. 4PEOPLE / 4BRANDS / 4PARTNERS / 4FUNDERS remain in the existing footer rather than becoming another four-item homepage module.

**DELETE / SIMPLIFY:** remove the giant blue WHY colour wall, the early separate black beliefs wall, the five-step process block and the standalone four-actor TAKE PART grid from the homepage. Do not delete their routes or product capabilities.

**REUSE:** existing PublicShell/header/footer, routes, identity/auth, shared ATLAS renderer/runtime, existing image registry, current Domain media, existing IMPACT_UNITS/data/statuses, About/Beliefs/Join routes. No new map engine, auth system, data store, content truth store or product architecture.

**TYPOGRAPHY / BRAND:** Instrument Sans remains display type but uses restrained scale and medium/regular visual weight; authority comes from spacing, composition, imagery and hierarchy. Homepage secondary copy uses a bounded local dim hierarchy rather than changing global product tokens. Brand-blue + white capsule CTAs are used for homepage primary actions. Large Domain imagery stays immersive. Paper/white becomes the dominant connective surface.

**TRUTH BOUNDARY:** IMPACT delivery states remain prototype/pathway states; contribution/payment ≠ delivery ≠ outcome ≠ verified impact. The homepage does not invent partner, outcome or availability claims. ATLAS iframe is the existing first-party /atlas renderer with embed mode, not a second map.

**MOBILE-FIRST RISK:** hero CTAs stack; live ATLAS receives a bounded 520px mobile frame; lens index becomes one column; Domain worlds become one column; IMPACT preserves one featured card followed by the remaining three rather than a cramped four-up grid.

**HUMAN SUCCESS:** within the first journey a visitor can (1) recognise 4PLANET, (2) understand the premise, (3) interact with ATLAS, (4) understand the four lenses, (5) encounter real life, (6) enter a Domain world, (7) see concrete action pathways and their honest state, and (8) join — without experiencing repeated giant four-card systems or generic SaaS hierarchy.

**FOUR-STATE AUTHORITY:** affected product = 4PLANET homepage. LIVE = https://4planet.org/ exact registry source c78f3b9814e823fdaa9167ccc784d2a88283215d. HEIR = sole king/test at the exact parent of this commit, review path https://test.4planet.org/. SANDBOX = NONE. ARCHIVED/donor material remains read-only. Legal write target = HEIR. Rollback identity = exact parent SHA of this commit. No production promotion is authorised.

**DOOR CLASS:** reversible HEIR visual/editorial refactor. LIVE remains a separate one-way exact-artifact Founder release.

**ACCEPTANCE REQUIRED:** exact-head product-authority + Gold policy + typecheck + production build + relevant browser/mobile visual proof. Technical pass is not Founder Human Gold.

---

# HUMAN-FIRST DISCOVERY — MASTER GOLD BROWSER MATRIX — 05 OCT 2026

**STATUS:** EXISTING QA MATRIX EXTENSION / HEIR ONLY.

**DELTA:** add one bounded Playwright proof for the three Discovery Master Gold routes to the existing VALUE CONVERGENCE browser gate. No new workflow, branch, control plane or deployment surface is created.

**MATRIX:** Chromium desktop 1440 + mobile 390 and WebKit desktop + mobile 390, inherited from the existing convergence workflow.

**ASSERTIONS:** HTTP 200; expected human-first H1/boundary copy; noindex; no horizontal overflow; no undefined/NaN; no fatal page errors; screenshots retained by the existing evidence path.

**KNOWN UNRELATED DEBT:** the separate legacy Species/Lens workflow currently expects the superseded literal `4PLANET SPECIES_` on the existing Orca renderer. This sprint did not change that public renderer and does not treat that locator mismatch as Master Gold failure.

---

# HUMAN-FIRST DISCOVERY OBJECTS — WORLD CLASS 01 — 05 OCT 2026

**STATUS:** HEIR / CONTROLLED MASTER GOLD / NOINDEX / NO LIVE RELEASE.

**FOUNDER LAW:** HUMAN FIRST. PREMIUM. CALM. VISUAL. USEFUL. TRUSTWORTHY. MEMORABLE. Search/AI structure stays behind the visible experience.

**DEMAND MAP:** 120 credible opportunity objects are prioritised in one durable discovery asset. Exact keyword volume is not fabricated: no Search Console property is connected, HYPD keyword research is plan-locked and Bing demand data is not configured. Relative demand bands remain hypotheses until hard query data is available.

**TOP 10 PILOTS:** Global Fires; Orca; Great Barrier Reef; Polar Bear; Amazon Basin; Whales; Sea Ice; Coral Bleaching; Tiger; Serengeti.

**MASTER GOLD 01–03:** Orca / Great Barrier Reef / Global Fires. These intentionally stress three different object classes while reading existing canonical Species, PlanetProof, Place and ATLAS data rather than creating parallel truth stores.

**DESIGN STANDARD:** Orca uses existing cleared documentary media; Great Barrier Reef uses the canonical COR4L_ media bank explicitly recorded as founder-supplied, rights-cleared and content-verified; Global Fires uses a designed signal field explicitly disclosed as not-live/non-evidentiary. Shared source, boundary and next-object modules do not force visual sameness.

**TRUTH / RELEASE:** these routes are controlled `/labs/gold/discovery/*` proofs with `noindex,nofollow,noarchive,nosnippet`. No production publication, social send, email send, IndexNow or Search Console submission is authorised.

**ACCEPTANCE:** typecheck + production build + full smoke including `discovery-world-class-contract` + product authority + Gold policy + immutable preview/browser QA. Human Gold remains a judgement gate; passing code is necessary but not sufficient.

---

# WHAT WE BELIEVE — CANON 2.0 PUBLIC SYNC — 05 OCT 2026

**STATUS:** HEIR PRODUCT CANDIDATE / EXACT CANON PROJECTION / FOUNDER REQUESTED LIVE RELEASE / RELEASE GATES REQUIRED.

## USER ARRIVES BECAUSE
A person wants to understand what 4PLANET stands for, why it exists and whether the organisation's claims about purpose can be inspected rather than inferred.

## ONE THING TO UNDERSTAND
4PLANET has one moral core and one value system. The public page is a projection of the canonical WHAT WE BELIEVE Founder Thesis, not a separate marketing value set.

## PRIMARY ACTION
Read /about/what-we-believe; from the homepage, follow the WHAT WE BELIEVE entry.

## SECONDARY DEPTH
Continue into Impact for proof, the System for architecture, Join for participation, or the Founder for origin.

## P1 DOMINANT
“We believe the future can be better.” Purpose = FOR A LIVING PLANET. Ambition = BETTER. FOR EVERYONE.

## P2 ORIENTATION
Four foundational beliefs plus seven values: CARE DEEPLY; TRUTH FIRST; EVERYONE HAS A PART TO PLAY; BE USEFUL; MAKE IT REAL; USE POWER FOR GOOD; LEAVE IT BETTER.

## P3 ACTION / NEXT
SEE IMPACT, SEE THE SYSTEM, or FIND YOUR PART. No duplicate values product or campaign funnel.

## P4 DEPTH
Brand law = DO GOOD → PROVE IT → LET PEOPLE TELL THE STORY. Public copy stays shorter than internal Canon while preserving meaning.

## WHAT CAN BE REMOVED
The superseded six-belief public draft and any suggestion that public beliefs are a second moral system.

## WHAT MUST BE REUSED
Existing About architecture, PublicShell, 4PLANET tokens, Impact/System/Join routes and the BRAIN authority ODDEKALV_ FOUNDER THESIS — WHAT WE BELIEVE — LOCKED CANON 2.0.

## TRUTH BOUNDARY
Publishing values does not prove that 4PLANET lives them. Product behaviour, evidence, Impact/Reports, correction and outcomes must provide proof. Do not describe 4PLANET as “a force for good” as a self-certified fact.

## MOBILE-FIRST RISK
Seven value rows and the homepage belief signature must stack cleanly at 390/430 without overflow; long headings must wrap without obscuring explanatory copy.

## HUMAN SUCCESS
A first-time visitor can explain 4PLANET's purpose, ambition and values, and can find both a proof path and a participation path.

**FOUNDER RELEASE CONTEXT:** Founder explicitly stated on 05 Oct 2026 that “nå må vi få dette ut live”. Production promotion remains exact-artifact and gate-controlled; this brief does not bypass QA.

---

# WHAT WE BELIEVE — VALUES + PUBLIC BELIEFS v1.0 — 04 OCT 2026

**STATUS:** HEIR CANDIDATE / PUBLIC ABOUT STORY / NOT LIVE / VALUES WORKING v1.0 / FOUNDER RED-TEAM PENDING.

## USER ARRIVES BECAUSE
A person wants to understand why 4PLANET exists, what it stands for and what kind of organisation it is trying to become.

## ONE THING TO UNDERSTAND
4PLANET has one moral core with two expressions: internal operating values and public beliefs. They may use different language but may never contradict one another.

## PRIMARY ACTION
Open `/about/what-we-believe` and understand the purpose and beliefs before moving deeper into the system.

## SECONDARY DEPTH
Continue into The Story, The System, The Founder or Impact to inspect how the stated beliefs connect to products, evidence and action.

## P1 DOMINANT
“We believe the future can be better.” The page must communicate constructive purpose before organisational detail.

## P2 ORIENTATION
People, animals, nature and future generations belong to the same living-planet frame. Economic strength is presented as a means to independence, durability and scale rather than the primary purpose.

## P3 ACTION / NEXT
See the System or inspect Impact. Do not add a competing campaign CTA or separate values product.

## P4 DEPTH
Six public beliefs: LIFE MATTERS; TRUTH MATTERS; BETTER SHOULD BE FOR EVERYONE; POWER SHOULD BE USED FOR GOOD; ACTION MATTERS; THE FUTURE CAN BE BETTER.

## WHAT CAN BE REMOVED
Generic corporate-values language, self-congratulation, unsupported “good company” claims and any duplicate Story/System/Founder content.

## WHAT MUST BE REUSED
Existing About architecture, PublicShell, 4PLANET visual tokens, The Story, The System, The Founder, existing Impact route and the BRAIN Founder Thesis “ODDEKALV_ FOUNDER THESIS — WHAT WE BELIEVE — v1.0”.

## TRUTH BOUNDARY
4PLANET does not claim that stating benevolent beliefs proves benevolent impact. Trust is to be earned through truthful products, visible action, evidence, correction and demonstrated usefulness. Values 1.0 remain open to Founder red-team before LOCKED CANON.

## MOBILE-FIRST RISK
Four-item About subnavigation and six belief rows must wrap without horizontal overflow. Belief rows collapse to a two-column mobile hierarchy with explanatory text beneath the title.

## HUMAN SUCCESS
A first-time visitor can explain, in plain language, why 4PLANET exists, what it believes, why economic strength matters and how those claims are meant to be proved — without confusing this page with The Story, The System or The Founder.

**CANON / BRAIN:** one source, two expressions. Website copy is a public projection of the working Founder Thesis, not a parallel values authority.

**RELEASE:** HEIR only. No production publication or Founder Release is inferred by this commit.

---

# COMPANY GOLD 01A — TONY'S REVIEW ROUTE ON CURRENT HEIR — 03 OCT 2026

**STATUS:** HEIR / INTERNAL NOINDEX / NOT HUMAN GOLD / NO LIVE.

**USER ARRIVES BECAUSE:** a reviewer needs the existing Tony's company → product → material drawer, which was on HEIR as a file and not routed.

**ONE THING TO UNDERSTAND:** company-level cocoa traceability is not this retail bar's cooperative, farm or batch. That stays UNKNOWN.

**PRIMARY ACTION:** open `/labs/company-gold/tonys`.

**SECONDARY DEPTH:** named first-party sources and the next evidence decision.

**P1 DOMINANT:** Milk Chocolate 32% 180g, EAN 8717677339914, with UNKNOWN beside it.

**P2 ORIENTATION:** source-backed versus unknown.

**P3 ACTION:** open the named sources.

**P4 DEPTH:** materials, rights, next evidence decision.

**WHAT CAN BE REMOVED:** no second company model.

**WHAT MUST BE REUSED:** existing `TONYS_COMPANY_GOLD` and `CompanyGoldTony`.

**TRUTH BOUNDARY:** Tony's pages are SOURCE TERMS / REFERENCE ONLY. Not an ecological outcome and not business advice.

**MOBILE-FIRST RISK:** cards stack at 390 and 430. No horizontal overflow.

**HUMAN SUCCESS:** desktop and mobile render the same object, robots `noindex,nofollow,noarchive`.

**DELTA:** forward-port of the accepted route and route→same-object noindex regression onto `king/test` `4fcbd7a1`. The prior brief block from `0810f28` was not copied. Prior QA_ACCEPT is lineage only.

---

# ATLAS GOOGLE SEARCH DISCOVERY CLOSURE 01 — 02 OCT 2026

**STATUS:** HEIR CANDIDATE / SEARCH-INDEXABLE SOURCE ARTIFACT / NO GOOGLE INDEX CLAIM.

**FOUNDER DIRECTION:** "Kan du gjøre atlas søkbar i Google nå?" The bounded objective is to make the existing public ATLAS technically discoverable and legible to Google without creating a second ATLAS or SEO content farm.

**OBSERVED EXTERNAL STATE:** fresh web search for `"4PLANET Atlas" 4planetatlas.com`, `site:4planetatlas.com` and `site:4planet.org/atlas 4PLANET` returned no 4PLANET ATLAS result. This is evidence of absent/very weak current search visibility, not a complete Google index export.

**ROOT CAUSE FOUND:** the actual public `/atlas` route renders `PublicWorld` without route-specific `Seo` metadata. The source build has `/atlas` in the 4planet.org sitemap and allows Googlebot, but the raw `/atlas` HTML is otherwise the generic SPA shell and no ATLAS-specific prerender exists. This weakens title/description/entity/canonical/content signals.

**BOUNDED FIX:**
- add explicit runtime ATLAS title, description, canonical path, OG/Twitter metadata and WebApplication JSON-LD to `PublicWorld`;
- add a raw HTML prerender for `/atlas` with a visible H1, product description, source names, truth boundary and crawlable links to Places, Species and Living Systems;
- add the ATLAS prerender to the normal production build;
- add a deterministic search-discovery contract to smoke tests;
- keep existing `/atlas` sitemap entry and Googlebot allow policy.

**PRIMARY INDEX URL:** `https://4planet.org/atlas` remains the source-controlled canonical target in this slice. The separate `4planetatlas.com` host exists in analytics but its edge/DNS routing is outside this repository and cannot be independently HTTP-read from the current runtime; do not invent a canonical-host migration without verified routing.

**TRUTH BOUNDARY:** this makes ATLAS crawlable/indexable and materially more legible to Google. It does NOT guarantee Google will index or rank it. Google controls crawling/index selection. Search Console URL Inspection / Request Indexing can accelerate a single-page recrawl after LIVE; the currently available Search Console connector is read-only.

**ACCEPTANCE:** exact HEIR SHA must pass ATLAS search contract, typecheck, production build, smoke/contracts, Gold/product authority and immutable Cloudflare preview. LIVE custom-domain promotion remains an exact-artifact Founder gate.

---

# DISCOVERY + TRAFFIC GROWTH — PHASE 03 EXISTING-ATLAS PLACE EXPANSION — 02 OCT 2026

**STATUS:** HEIR CANDIDATE / NO PHASE-03 LIVE AUTHORITY.

**OBJECTIVE:** compound public discovery by promoting source-qualified discovery objects for five Places that already exist in the shared ATLAS registry: Amazon Basin, Congo Basin, Borneo, Svalbard and Oslofjord. No new Place engine, map renderer, truth store or geocoder is created.

**GRAPH:** Amazon Basin → Jaguar; Congo Basin → Chimpanzee + Eastern Gorilla; Borneo → Bornean Orangutan; Svalbard → Polar Bear + Humpback Whale + Blue Whale; Oslofjord → Atlantic Cod + Blue Mussel.

**SOURCE BOUNDARY:** Amazon/Congo/Borneo use public WWF ecological/species material for bounded discovery context; Svalbard uses Norwegian Polar Institute + Governor of Svalbard; Oslofjord uses current Norwegian Government and Environment Agency evidence. Monitoring samples, protected-area rules, source-published population estimates and occurrence records retain their distinct semantics.

**PUBLICATION LAW:** no basin/island/fjord object claims one universal protected-area percentage where jurisdictions/designations differ. Navigation bboxes remain navigation only. Species relationships mean documented ecological/geographic relevance, never current individual presence or complete distribution.

**ACCEPTANCE:** exact HEIR SHA must pass build, full smoke/discovery contracts, authority/Gold and immutable preview/browser gates. No production promotion, IndexNow submission, social schedule or email send is authorised by this phase.

---

# DISCOVERY + TRAFFIC GROWTH — PHASE 02 GLOBAL GRAPH EXPANSION — 02 OCT 2026

**STATUS:** HEIR CANDIDATE / NO PHASE-02 LIVE AUTHORITY.

**FOUNDER DIRECTION:** continue production immediately after Sprint 01 LIVE release. This phase remains HEIR-only until a new exact-artifact Founder release.

**P1 USER VALUE:** a person can enter 4PLANET through five source-qualified Places — Kenya, Serengeti, Costa Rica, Great Barrier Reef and Norway — and traverse real crawlable Place ↔ Species relationships into ATLAS and source evidence.

**SPECIES INVENTORY:** close the controlled first inventory from 20/25 to 25/25 curated objects by adding Leopard, Eastern Gorilla, Chimpanzee, Bornean Orangutan and Emperor Penguin. Every added profile reuses the existing SPECIES engine and GBIF occurrence seam with a Source Envelope. Occurrence remains reported observation, never complete range, abundance, trend, residency or live location.

**EASTERN GORILLA PROVIDER MIGRATION:** retain legacy numeric GBIF Backbone key `7262070` only for the current occurrence-adapter contract while documenting that current GBIF web taxonomy presents accepted `Gorilla beringei` under Catalogue-of-Life identifier `3H3C3`. Provider ID migration must be deliberate and tested; the system must not silently rebind identity.

**PLACE INVENTORY:** add source-qualified public candidates for Serengeti and Costa Rica to the existing ATLAS Place registry and promote existing Norway / Great Barrier Reef registry objects into discovery inventory. Navigation bounding boxes are explicitly not official legal/ecological boundaries.

**SOURCE SET:** IUCN SSC Cat Specialist Group (Leopard); current GBIF + WWF subspecies context (Eastern Gorilla); WWF (Chimpanzee, Bornean Orangutan); British Antarctic Survey + U.S. Fish & Wildlife Service (Emperor Penguin); UNESCO + Protected Planet + GBIF Tanzania (Serengeti); SINAC + CBD (Costa Rica); Great Barrier Reef Marine Park Authority + AIMS + UNESCO (Great Barrier Reef); CBD Norway + Artsdatabanken + Miljødirektoratet (Norway).

**GRAPH / MACHINE READABILITY:** Place WebPage schema uses `citation` for provenance instead of incorrectly declaring source URLs as Place `sameAs`. Raw prerendered HTML carries related-species links; Species routes expose qualifying related Places; index pages use ItemList JSON-LD.

**TRUTH BOUNDARIES:** draft CBD country profiles remain labelled draft; AIMS survey results are survey-bounded; Artskart/GBIF points are observations; World Heritage/national/protected-area designations and areas are not collapsed; species/global status never becomes a local-population diagnosis.

**ACCEPTANCE:** exact HEIR SHA must pass typecheck, production build, full smoke/discovery contracts, product authority, Gold policy and immutable Pages/browser proof. No Phase-02 production release, search submission, social send or email send is authorised by this section.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — GLOBAL SPECIES BATCH 20 — 01 OCT 2026

**STATUS:** HEIR CANDIDATE / NO LIVE PROMOTION / EXACT-SHA QA REQUIRED.

**DELTA:** promote seven source-qualified, high-interest species into the existing curated SPECIES engine: Blue Whale, Asian Elephant, Tiger, Polar Bear, Giant Panda, Whale Shark and Green Turtle. Together with the prior 13, the controlled discovery inventory now contains 20 indexable curated species out of 25 candidates.

**SOURCE BOUNDARY:** NOAA Fisheries supplies Blue Whale and Green Turtle context; U.S. Fish & Wildlife Service supplies Asian Elephant, Polar Bear and Giant Panda context; IUCN SSC Cat Specialist Group supplies Tiger context; Convention on Migratory Species supplies Whale Shark context. GBIF numeric keys remain the existing engine's taxon/occurrence identifiers. Provider taxonomy changes are a refresh concern, not permission to silently rebind identity.

**OCCURRENCE LAW:** every added species reuses the shared GBIF occurrence seam. A reported occurrence is not complete range, abundance, trend, residency, population condition or live position. Green Turtle regulatory status stays population-segment-aware rather than being collapsed into one global label.

**QUALITY GATE:** Leopard, Eastern Gorilla, Chimpanzee, Bornean Orangutan and Emperor Penguin remain BUILD_NEXT/noindex instead of being promoted without the same source and product closure.

**ACCEPTANCE:** exact-head typecheck + production build + full smoke/discovery contracts + authority/Gold policy + browser/preview proof. No custom-domain promotion without exact-artifact Founder release.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — OWNED RETURN QA CORRECTION — 01 OCT 2026

**STATUS:** HEIR CONTROL CORRECTION / NO EXTERNAL SEND.

**DELTA:** correct the owned-return privacy contract so it forbids an `email` analytics parameter rather than falsely matching the event name `email_signup`. Remove `/signal` from the discovery sitemap because its page-level contract is deliberately `noindex,follow`.

**TRUTH:** PLANET SIGNAL remains a consented return/acquisition surface, not an SEO inventory object. No subscriber email, raw query string or raw referrer URL is added to analytics.

**ACCEPTANCE:** exact-head typecheck + build + smoke + discovery contracts + authority/Gold policy.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — PLANET SIGNAL TYPECHECK FIX — 01 OCT 2026

**STATUS:** HEIR CONTROL CORRECTION / NO EXTERNAL SEND.

**DELTA:** replace one invalid presentation-only `T.body` reference in the PLANET SIGNAL email input with the existing public body-font stack. Consent, Resend writes, analytics and routing are unchanged.

**ACCEPTANCE:** exact-head typecheck + build + smoke + owned-return contract.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — OWNED RETURN + DISTRIBUTION CLOSURE — 01 OCT 2026

**STATUS:** HEIR CANDIDATE / UNSENT / LIVE CONFIG UNTOUCHED.

**PLANET SIGNAL:** add `/signal` plus `/api/planet-signal`. Explicit consent creates/updates the one Resend Contact, adds the dedicated PLANET SIGNAL Segment and sets the opt-out-by-default PLANET SIGNAL Topic to `opt_in`. No local subscriber database and no automatic welcome email. Missing `RESEND_API_KEY` fails closed; the UI does not claim collection.

**MEASUREMENT:** successful signup emits only bounded `email_signup` metadata; the submitted email is not sent to analytics.

**DISTRIBUTION:** production-ready MAGAZINE queue, Kenya social copy/storyboard, PLANET SIGNAL issue queue and P2 4SAPIEN/4BRANDS readiness are internal assets only. P4nther remains the only Metricool brand discovered; no content is scheduled there.

**CLOUDFLARE ANALYTICS BLOCKER:** current repository workflow is production-connected and still omits `4brands.org`. Its mutation was deliberately not included in this HEIR product commit because changing/dispatching a production-linked workflow is a separate Founder-gated infrastructure action.

**ACCEPTANCE:** typecheck + build + smoke + owned-return contract + product authority/Gold policy. External social/email publication, IndexNow submission, Cloudflare analytics mutation and custom-domain promotion remain Founder-gated.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — INDEXNOW KEY CONTROL FIX — 01 OCT 2026

**STATUS:** HEIR / CONTROL CORRECTION / NO EXTERNAL SUBMISSION.

**DELTA:** normalise the public IndexNow ownership-key file to the exact key text with no literal escape characters. This change exists solely to satisfy the ownership-file contract and is paired with this Gold receipt in the same bounded change.

**TRUTH / RELEASE:** the key file alone does not notify a search engine or claim indexing. The submission script remains founder-gated behind `FOUNDER_INDEXNOW_RELEASE=ENIG_INDEXNOW`.

**ACCEPTANCE:** discovery contract + smoke + product authority + Gold policy on exact SHA.

---

# 4SAPIEN FOOD FIRST PROVEN VALUE LOOP 02 — 01 OCT 2026

**STATUS:** TECHNICAL LIVE CLOSURE VERIFIED / 4SAPIEN.COM LIVE / EMBLA V11 ACTIVE / HUMAN GOLD OPEN.

**BOUNDED PRODUCT DELTA:** existing 4PLANET ID + existing owner-RLS `four_sapien_embla_memories` carry the FOOD pantry loop through explicit save/readback/supersession/delete and return reuse. Existing `four_sapien_decisions` stores an explicit private meal-choice state without claiming the meal was cooked or useful. Existing `four_sapien_embla_events` receives only bounded stage/timing/count metadata. Ingredient names, pantry contents, prompts and free text are excluded from value-loop analytics.

**EMBLA LIVE SEAM:** production `embla-core-preview` is ACTIVE v11, hash `e94fe409d9b79f6cbef70954434e747d2ed705477d44b4c86cba7dac5ca5da1b`. The released delta changed only the existing `read_pantry` tool from `PANTRY_SCHEMA_NOT_IMPLEMENTED` to reading the same active user-confirmed `food_pantry_v1` Person memory under the caller's authenticated RLS context. Existing Brain reuse and Human Utility measurement events are preserved. The prior v10 runtime is the bounded rollback reference.

**LIVE PRODUCT PROOF:** canonical 4SAPIEN was released through the existing Founder-authorised bounded LIVE workflow to the existing `four-sapien-embla` Worker. Exact live source is `edcf5b6bf75a6b6f9436ab68105700dfe0c90c1a`. GitHub Actions run `36888848059` passed HEIR intent, materialisation, zero-loss/pantry gates, desktop + mobile pre-deploy first-return proof, existing Worker authority, production deploy, and physical desktop + mobile readback at `https://4sapien.com`. The live browser gate was hardened to cache-bust the just-deployed HTML after the first post-deploy run exposed a transient stale-cache desktop mismatch; the hardened exact run passed 2/2 live browser projects.

**MEASUREMENT:** bounded recruitment attribution accepts only `src=human_utility` → `human_utility_recruitment`, otherwise `direct_or_unknown`. The measured path separates identity, activation, first value, saved context, return, second value, saved decision and explicit useful outcome. The explicit useful/not-yet signal uses the existing `measurement_useful_outcome` Human Utility path; no second measurement truth system exists. Synthetic and Founder sessions never count as real-user or return proof.

**TRUTH BOUNDARY:** current deterministic meal examples remain `DEMO_FIXTURE_NOT_VERIFIED`. Missing price/amount/context stays UNKNOWN. Purchased is not consumed. A saved choice is not a cooked meal, useful outcome, payment or ecological result.

**CURRENT REAL-USER STATE:** production readback after release still shows 0 active `food_pantry_v1` rows/users, 0 FOOD decisions/users, 0 `measurement_useful_outcome` events/users and 0 `food_second_value_reached` events/users. Technical LIVE closure is therefore complete; Human Gold, independently attributable real return/value, NOK 100/month WTP/payment proof and source-grounded production recipe donors remain open.

**NEXT GATE:** recruit the existing 6–8 consenting Human Utility testers through the already-defined bounded protocol, then separate first-use utility, actual return, WTP and payment evidence. External outreach remains a distinct Founder-release action; this technical LIVE release does not fabricate or substitute Human Gold.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — DISTRIBUTION + MEASUREMENT SEAM — 01 OCT 2026

**STATUS:** HEIR CANDIDATE / UNSENT / NO LIVE PROMOTION.

**MEASUREMENT:** add one consent-bound, once-per-session `discovery_entry` classification for ChatGPT, Perplexity, Google, Bing, Instagram, Facebook, LinkedIn, email, direct and bounded other-referral. Raw query strings and raw referrer URLs are never emitted.

**INDEXNOW:** host-verification key + submission script are prepared. The script refuses execution unless `FOUNDER_INDEXNOW_RELEASE=ENIG_INDEXNOW` and the target origin is exactly `https://4planet.org`. Only indexable discovery inventory routes are submitted. This is release preparation, not a claim of indexing, crawl, ranking or traffic.

**EMAIL:** PLANET SIGNAL is created as a draft in the existing Resend account. Draft creation is internal preparation only; it is not published and no subscriber email has been sent.

**ACCEPTANCE:** exact-head typecheck/build/smoke/discovery contracts. IndexNow invocation and any external email remain Founder-gated actions.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — KENYA SPECIES GRAPH CLOSURE — 01 OCT 2026

**STATUS:** HEIR CANDIDATE / NO LIVE PROMOTION / EXACT-SHA QA REQUIRED.

**DELTA:** African Savanna Elephant (`Loxodonta africana`, GBIF 2435350), Lion (`Panthera leo`, GBIF 5219404) and Cheetah (`Acinonyx jubatus`, GBIF 2435270) are promoted from BUILD_NEXT into curated SPECIES objects. Each receives bounded source claims and a Source Envelope. The existing SPECIES page machinery supplies ATLAS embedding and GBIF occurrence retrieval; occurrence records remain reports of observations, never range, abundance, residency or live tracking.

**KENYA GRAPH:** `/place/kenya` now links to these three SPECIES objects. Discovery inventory increases from 10 to 13 indexable species while total candidate inventory remains 25. Sitemap and raw discovery prerender automatically follow the controlled inventory.

**SOURCE SET:** GBIF; Kenya Wildlife Service (Amboseli, lion recovery/action plan, 2026 lion census statement, historical cheetah strategy); U.S. Fish & Wildlife Service African Elephant; IUCN SSC Cat Specialist Group; Convention on Migratory Species. Historical Kenya cheetah sighting material is explicitly bounded as historical and non-residency evidence.

**ACCEPTANCE:** typecheck + production build + discovery/smoke contracts + product authority + TEST KING/browser proof on exact candidate. No custom-domain promotion without Founder exact-artifact release.

---

# DISCOVERY + TRAFFIC GROWTH SPRINT 01 — P0 DISCOVERY HEIR SLICE — 01 OCT 2026

**STATUS:** HEIR CANDIDATE / NO LIVE PROMOTION / EXACT-SHA QA REQUIRED.

**AUTHORITY:** one atomic product write to current `king/test` sole HEIR. No new branch, candidate class, truth store, Species engine or Atlas renderer is created.

**FOUNDER NORTH STAR:** UNKNOWN PERSON → SEARCH / AI / SOCIAL / EDITORIAL DISCOVERY → USEFUL PUBLIC OBJECT → PRODUCT EXPLORATION → RETURN → LEARNING.

**BOUNDED DELTA:** reusable Place routes + Kenya Gold candidate; 25-Species production inventory with only 10 existing curated profiles indexable; discovery-derived sitemap; raw HTML discovery prerender; runtime Species SEO/noindex threshold; explicit Search/AI crawler policy; non-production host noindex; and production GA4 isolation from TEST KING.

**KENYA TRUTH BOUNDARY:** KWS, CBD, GBIF and Protected Planet remain named sources. CBD marks its Kenya profile text as draft. The ATLAS bbox is navigation geometry only. KWS land-coverage and Protected Planet area-count measures remain separate.

**SPECIES TRUTH BOUNDARY:** occurrence records remain reported observations, not range, abundance, trend, population status or live location. BUILD_NEXT inventory is not publication approval.

**ACCEPTANCE:** typecheck + production build + discovery contract + existing smoke/contracts + rendered HEIR browser verification. Public custom-domain promotion requires a separate exact-artifact Founder release after Gold.

---

# MULTI-PRODUCT VALUE CONVERGENCE FINAL INTEGRATION + LIVE CLOSURE 02 — 28 SEP 2026

**STATUS:** HEIR CANDIDATE / EXACT-SHA VERIFICATION REQUIRED / NO LIVE CLAIM FROM SOURCE ALONE.

**AUTHORITY:** one atomic product write to the existing `king/test` sole HEIR. PR #347 / PR #345 are read-only donor provenance after this convergence; no new candidate class, second HEIR, parallel BRAIN, auth system, memory store or company database is created.

**FOUNDER DIRECTION:** converge the already-tested universal identity, Person memory, Company Brain, ATLAS/SPECIES and measurement improvements onto fresh HEIR, preserve all newer `king/test` work, verify the exact merged SHA, then promote only the verified artifact to existing authorised 4PLANET-owned live surfaces.

**BOUNDED USER VALUE:**
- 4PLANET ID client trusted-host parity now covers the same priority cross-product destinations accepted by the active server bridge, including 4PLANET, 4SAPIEN/S4PIENS, 4BRANDS, ATLAS, SPECIES, Labs and 4BRAIN.
- 4SAPIEN FOOD pantry reuses the existing private Person memory table under canonical 4PLANET ID. Persistence is explicit-consent only, requires server write/readback, supports supersession and deletion, and restores user-confirmed pantry context on return. Anonymous edits remain session-only.
- 4BRANDS keeps the existing Company Brain architecture. Versioned migrations make workspace owner-membership creation idempotent and permit only member-scoped authenticated audit writes for canonical Company Brain save/analysis actions.
- ATLAS and SPECIES keep the existing canonical context/return mechanisms; this change adds privacy-safe value-path instrumentation rather than a new router or camera authority.
- Existing consented analytics gains signup/login, Person-memory return value, Company Brain creation/value actions, ATLAS context opens, SPECIES/source opens and cross-product navigation. Free text and precise location are not added to analytics.

**DATABASE READBACK:** active `4Planet_ OS` has two auth users matched to two canonical profiles and two 4SAPIEN profiles. RLS readback shows the second sampled user can see its own canonical profile but zero of the first user's Person memories, Company workspaces or memberships. The two Company Brain audit policies are active. Prior transactional tests proved Person-memory write/readback/supersede/delete and Company Brain workspace → twin → metric → opportunity → decision → intervention → measured result → learning → audit, with rollback and zero synthetic value records retained.

**EXTERNAL BLOCKER / TRUTH BOUNDARY:** model-backed Embla / Brain turns are NOT VERIFIED while the configured upstream model account returns HTTP 429 `credit_balance_exhausted`. No conversational PLANETBRAIN Gold claim is permitted from this change.

**ACCEPTANCE:** exact HEIR SHA must pass typecheck, production build, full smoke/contracts, Chromium desktop + 390px mobile, WebKit desktop + 390px mobile, plus existing ATLAS/Species/pantry critical journeys. LIVE custom-domain status requires post-promotion runtime readback; a successful source commit or Pages build is not enough.

**LIVE RELEASE:** this section does not itself claim LIVE. Founder has authorised promotion only after the exact merged SHA passes the acceptance gate. Rollback is the prior immutable LIVE artifact / prior HEIR SHA.

---

# DATA VALUE CONVERGENCE 01 — SOURCE GATE RIGHTS / OPERATIONS HARDENING — 28 SEP 2026

**STATUS:** HEIR CANDIDATE / OFFICIAL TERMS VERIFIED.

Production-capable source responses now expose use boundaries directly: publisher/API, licence or rights state, commercial reuse, attribution, caching, access cost/rate where established, canonical mapping and limitations.

Verified rights/read constraints:
- Brønnøysundregistrene Enhetsregisteret: NLOD 2.0.
- GLEIF LEI Access Service: CC0 1.0.
- Climate TRACE core emissions data/metadata: CC BY 4.0; listed external and ownership sources can carry different terms and therefore remain review-gated.
- TED published procurement notices: freely reusable commercially/non-commercially unless otherwise noted; SIMAP metadata CC0.
- Stortinget Open Data: NLOD, Stortinget attribution, non-misleading presentation, 100 calls/min.
- SSB PxWebApi v2: CC BY 4.0, 30 queries/min, 800,000-cell extract limit.
- Matvaretabellen: official local caching permitted; clear source citation required. 4PLANET uses the publisher's requested 2026 citation and does not silently treat generic foods as branded-product facts.

No new Source Registry or truth store was created.

---

# DATA VALUE CONVERGENCE 01 — IMPACT / INDEPENDENT OBSERVATION + MRV RELATIONSHIP — 28 SEP 2026

**STATUS:** HEIR CANDIDATE / SOURCE CONNECTED / NO CLAIM PROMOTION.

**ACTION CONTRACT:** existing Bay of Biscay survey Action Contract now carries explicit independent evidence-source relationships. The existing OBIS adapter is attached as CONTEXT_ONLY over the existing Bay of Biscay navigation bounding box. A separate DELIVERY_LINKED independent survey-effort MRV requirement is present and truthfully remains NOT_CONNECTED.

**PRODUCT VALUE:** the IMPACT proof surface exposes the bounded OBIS source path and its limitations alongside the current survey-effort semantics. A reviewer can inspect independent ecological occurrence context without confusing it with ORCA delivery.

**PROOF PASSPORT HARDENING:** Passport VERIFIED / impact eligibility now requires a THIRD_PARTY VERIFICATION item explicitly marked IMPACT_LINKED. A third-party item marked CONTEXT_ONLY cannot increase verification depth or impact eligibility.

**TRUTH LAW:** co-location, subject similarity and independent publisher status are not a join. OBIS occurrences do not verify ORCA survey effort, population trend, ecological change or impact. ORCA evidence remains provider/partner evidence. Independent delivery MRV is still an explicit gap.

**NO DUPLICATE SYSTEM:** existing Action Contract + existing Proof Passport + existing OBIS adapter. No new MRV database or proof authority.

**ACCEPTANCE:** typecheck/build/smoke; Proof Passport negative context-only test; IMPACT independent-evidence contract; browser/public-preview gates. No physical-delivery, outcome or impact state is promoted.

---

# ATLAS MOBILE CONTEXT / NATIVE CONTROL COLLISION CLOSURE — 28 SEP 2026

**SOURCE FAILURE:** exact deployed HEIR browser proof on mobile-430 timed out because `.ctx-head` intercepted pointer events intended for MapLibre's visible native zoom-in control. 69 deployed ATLAS tests had passed before this single geometry failure.

**FIX:** no camera authority, test, MapLibre behavior or context model changed. On <=760px only while `.ctx` exists, move the existing bottom-right native navigation-control container above the maximum 72vh bottom sheet. No force-click, no hidden control, no parallel navigation UI.

**ACCEPTANCE:** contract test + full ATLAS Zero Loss deployed browser proof on exact candidate. Do not call the ATLAS gate green before that exact run passes.

---

# DATA VALUE CONVERGENCE 01 — 4NATION / SSB STATISTICAL CONTEXT — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / OFFICIAL STATISTICAL DISCOVERY + DEFAULT EXTRACT / PUBLIC LIVE UNTOUCHED.

**SOURCE:** Statistics Norway PxWebApi v2. Search uses `/tables?query=...`; selected tables use `/tables/{id}` and the source-defined default/latest `/data` extract. SSB documents open access without registration, CC BY 4.0, 30 queries/minute and 800,000-cell extract limits. 4PLANET caches metadata/default extracts for fifteen minutes.

**CANONICAL OBJECT:** `statistical-table:ssb:<5-digit-table-id>`. Returned data retain table label/update/periods/dimensions plus JSON-stat2 coordinates, cell values and source status markers.

**USER LAW:** the user chooses the table. 4NATION does not silently decide which statistic proves or disproves a public policy. Default extracts are context, not causal models.

**TRUTH BOUNDARY:** null/status/confidential values stay explicit. Units, dimensions, table metadata and footnotes remain necessary context. Statistical association does not establish policy causation or measured implementation outcome.

**BEFORE → AFTER:** a 4NATION user can move from a public case to official measurable context, inspect the latest default source extract and open the original SSB table without model-generated statistics.

**NO DUPLICATE SYSTEM:** read-through shared source adapter; no statistical warehouse or parallel public-decision store.

**ACCEPTANCE:** exact-head typecheck/build/smoke incl. `nation-ssb-contract.test.mjs`, 4NATION QA/browser proof, no production release.

---

# DATA VALUE CONVERGENCE 01 — 4NATION / STORTINGET LIVE CASE DISCOVERY — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / NEUTRAL SOURCE DISCOVERY / PUBLIC 4NATION RELEASE UNTOUCHED.

**AUTHORITY:** current 4NATION curated Oslofjord case remains unchanged. The live production Worker remains pinned to the previously founder-reviewed immutable artifact; this change affects the current HEIR candidate only.

**SOURCE:** Stortinget Open Data `/eksport/saker?format=JSON`, current session. Stortinget supports JSON/XML reuse without registration, requires Stortinget attribution under NLOD, and documents a 100-call/minute limit. 4PLANET caches the source session snapshot for ten minutes.

**CANONICAL OBJECT:** `public-decision:stortinget:<sakid>` retains Stortinget case ID, exact source status, case type, document group, committee, subjects, source update time and exact source-record URL.

**NEUTRALITY / TRUTH:** the finder performs bounded text filtering only. It does not rank options, infer ideology, recommend policy, assess political actors, or convert a case into adopted/implemented policy. Source status remains the authority.

**COVERAGE:** current parliamentary session only. It is not all Norwegian public decisions, government implementation, municipal/regional decisions or measured outcomes.

**BEFORE → AFTER VALUE:** users can now move from one curated 4NATION case to a live, original-source search of current parliamentary cases while retaining procedural status and provenance.

**NO DUPLICATE SYSTEM:** no new public-decision database, BRAIN or political knowledge store. One read-through cached adapter plus the existing 4NATION surface.

**ACCEPTANCE:** exact-head typecheck/build/smoke incl. `nation-stortinget-contract.test.mjs`, 4NATION QA/browser proof, neutrality/truth boundaries. No production release.

---

# DATA VALUE CONVERGENCE 01 — PUBLIC PROCUREMENT DEMAND SIGNALS — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / TED ACTIVE-NOTICE DISCOVERY / DOFFIN ACCESS GATE OPEN.

**SOURCE CHOICE:** use the official TED Search API v3 immediately because published-notice search is anonymous and explicitly supports commercial/reuser applications. Doffin Public API is the authoritative Norwegian search/download source for Doffin notices, but its official integration documentation requires registration/subscription. No undocumented or scraped Doffin runtime is substituted.

**USER FLOW:** 4BRANDS company analysis → user enters product/solution/capability keywords → choose Norway-on-TED or all TED markets → official active published notices → inspect buyer/date/CPV/deadline → open original TED notice.

**NO AUTOMATIC MARKET CLAIM:** company sector text does not trigger procurement queries. Search terms are user-controlled. A published notice is evidence of a published procurement process/market signal only. It is not a sale, award, company fit, willingness to pay, realised value or ecological outcome.

**CANONICAL OBJECT:** each returned notice is `procurement:ted:<publication-number>` with original source URL. No notice is automatically joined to a company, facility, solution or intervention.

**COVERAGE LIMIT:** Norway-on-TED is not complete Doffin coverage. National/Doffin-only notices remain an explicit coverage gap until the official Doffin subscription key and exact Public API contract are configured.

**BEFORE → AFTER VALUE:** a company user can now test whether public buyers are publishing notices around a capability using an authoritative, inspectable, current source instead of relying on model inference.

**ACCEPTANCE:** typecheck/build/smoke including procurement-demand contract, lint, 4BRAND runtime audit and browser proof. No public production claim until gates pass.

---

# DATA VALUE CONVERGENCE 01 — COMPANY → FACILITY / CLIMATE TRACE — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / REVIEW-GATED JOIN / NO LIVE RELEASE CLAIM.

**SHARED SOURCE OBJECT:** the existing `/api/climate-trace` adapter remains the one source/facility path already consumed by ATLAS. It is extended with the official v7 `ownerIds` filter and returns `facility:climatetrace:<sourceId>` identifiers. 4BRANDS uses the same endpoint; no second emissions store or ATLAS copy is created.

**JOIN LAW:** BRREG/GLEIF legal identity → Climate TRACE owner search is discovery only. The user must explicitly review/select a Climate TRACE owner candidate before 4BRANDS requests that owner's source records. Name similarity never auto-joins the company. The reviewed join remains session context and is not silently promoted into Company Brain or PLANETBRAIN.

**SOURCE CONTRACT:** Climate TRACE public API v7 beta exposes owner search and source filtering by owner IDs. Production dependence stays bounded because the API is beta; errors/empty contracts fail closed. Facility records retain Climate TRACE source ID, coordinates, sector/subsector, year/gas and emissions value. Climate TRACE and upstream ownership/source terms remain attached as limitations.

**ATLAS REUSE:** ATLAS already uses `/api/climate-trace` for its emissions layer. Facility identity is now shown in the ATLAS point detail, and 4BRANDS can deep-link to the same emissions layer/location. This is one data path viewed through two product lenses.

**TRUTH BOUNDARY:** source-level emissions do not by themselves assign legal responsibility to the BRREG entity. Ownership and emissions are source records. A possible reduction strategy is not a realised reduction, and no strategy dataset is promoted in this slice.

**BEFORE → AFTER VALUE:** a correctly identified company can now be used to discover/review Climate TRACE owner candidates, inspect source-level emitting facilities, see source/year/emissions context and continue spatially in ATLAS without 4PLANET inventing the company→facility relationship.

**ACCEPTANCE:** exact-head typecheck/build/smoke including company-climate contract, lint, 4BRAND runtime audit, ATLAS source bridge and browser proof. No public LIVE claim until gates pass.

---

# DATA VALUE CONVERGENCE 01 — 4BRANDS COMPANY IDENTITY SPINE — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / NO LIVE RELEASE CLAIM.

**SAME PROVIDER, NOT SECOND BRREG:** the existing authenticated 4SAPIEN exact-org-number adapter is refactored to call one shared BRREG provider module. 4BRANDS uses that same provider for name discovery and exact organisation-number resolution.

**USER FLOW:** company name → BRREG candidates → explicit user selection → exact BRREG organisation-number readback → optional GLEIF lookup → LEI auto-crosswalk only when GLEIF `registeredAs` exactly equals the BRREG organisation number → company analysis.

**TRUTH BOUNDARY:** name search is discovery, not identity. Fuzzy/name similarity never becomes canonical company identity. BRREG exact organisation number is the Norwegian legal-identity anchor. GLEIF name results remain candidates unless the registration ID exactly crosswalks. Legal identity does not prove ownership, financials, emissions or value.

**RIGHTS:** Brønnøysundregistrene Open Data / NLOD 2.0. GLEIF public LEI reference data / CC0. Source URLs and observed identity records travel into the 4BRANDS evidence list.

**BEFORE → AFTER VALUE:** before, arbitrary company analysis could begin from a free-text name with no canonical legal-entity anchor. After, Norwegian users can disambiguate the actual company first and carry organisation number + optional exact LEI into the value map and later Company Brain.

**NO DUPLICATE SYSTEM:** existing identity/auth, Company Brain and BRREG capability remain. No new company database or parallel company truth store.

**ACCEPTANCE:** exact-head typecheck/build/smoke including company identity contract; existing `embla-brreg` auth and fail-closed behaviour preserved; browser proof; no production release claim until gates pass.

---

# DATA VALUE CONVERGENCE 01 — 4SAPIEN FOOD / MATVARETABELLEN — 27 SEP 2026

**STATUS:** HEIR CANDIDATE / USER-FACING / NO LIVE RELEASE CLAIM.

**HUMAN TRUTH:** a branded grocery product and a generic food-composition reference are different objects. Name similarity is not provenance.

**SAME-COMMIT CHANGE:** add a server-side Matvaretabellen reference gateway over the official Norwegian foods dataset, with a bounded 30-day Cloudflare edge snapshot, source/version metadata and explicit attribution. Add a FOOD UI seam where the user searches Matvaretabellen and explicitly confirms a generic reference for the current GTIN. No candidate is auto-selected. The confirmed relation is recoverable on the same device only and is visibly NOT Personal Brain or shared PLANETBRAIN truth.

**SOURCE:** Mattilsynet / Matvaretabellen official API `/api/nb/foods.json`. Source docs state annual autumn updates, few/no changes during the rest of the year, local caching is safe, and Matvaretabellen should be cited.

**TRUTH BOUNDARY:** branded product facts continue to come from product-specific evidence. Generic composition values never overwrite GTIN identity, ingredients, allergens, price or product-specific nutrition. A user-confirmed generic reference is a relationship assertion with provenance, not proof that both compositions are identical.

**BEFORE → AFTER USER VALUE:** before, the FOOD surface could inspect a branded product but had no official Norwegian generic composition context. After, a user can inspect a product, deliberately connect it to an official generic food reference, see source-linked nutrient values, remove the join, and receive local return value on revisit.

**NO DUPLICATE SYSTEM:** no new database, BRAIN, Source Registry or product engine. Existing FOOD route + existing Cloudflare function plane + local non-canonical recovery only.

**ACCEPTANCE:** exact-head typecheck, build, smoke including `food-matvaretabellen-contract.test.mjs`, lint and browser product proof. No LIVE/Gold claim until gates prove it.

---

# 4PLANET MARKET — ATTRIBUTED PURCHASE PATH 01 / 27 SEP 2026

**STATUS:** HEIR / TEST CANDIDATE / NO FALSE PURCHASE CLAIM

**FOUNDER TASK:** Improve the real 4PLANET MARKET transaction/value-delivery loop without creating a second commerce stack.

**VERIFIED EXTERNAL STATE:** Connected Fourthwall shop readback on 27 Sep 2026 returned six offers: five are PUBLIC + AVAILABLE + Fourthwall-fulfilled at USD 50.50; one duplicate Summit offer is HIDDEN. No Fourthwall offer, price, payout or fulfilment state was mutated.

**HIGHEST-VALUE CORRECTABLE FRICTION:** 4PLANET MARKET already sends a buyer to the real Fourthwall product, but the outbound product URL had no Market-specific purchase attribution. A later real sale therefore could not be cleanly reconciled back to the originating 4PLANET MARKET product click from Fourthwall's UTM sales reporting.

**SAME-COMMIT CHANGE:** All five live product links now carry deterministic `utm_source=4planetmarket`, `utm_medium=market`, `utm_campaign=first_creator_proof` and product-specific `utm_content=<slug>`. External commerce opens in a separate tab with noopener/noreferrer so the Market context is retained. The visible catalogue verification date is refreshed to the actual connected-shop readback on 27 Sep 2026.

**TRUTH BOUNDARY:** Attribution creates a measurable path from Market traffic to a completed Fourthwall sale. It does NOT turn a click into a purchase, payment, delivery or ecological-impact record. Purchase/fulfilment proof remains Fourthwall-owned unless separately read back.

**QA:** Existing user-proof analytics contract is strengthened to require all four UTM dimensions, safe external-link semantics, current verification date and the explicit click ≠ purchase boundary. Exact-head build/browser gates still determine acceptance.

**LIVE:** 4planetmarket.com remains separately release/readback controlled. Do not call this LIVE until the existing production path serves this exact change and external readback verifies it.

---

# DATA VALUE CONVERGENCE 01 — SPECIES LIVE EVIDENCE DISCOVERY — 27 SEP 2026

STATUS: HEIR CANDIDATE BRIEF / NONPRODUCTION / NO CANON PROMOTION / NO LIVE RELEASE AUTHORITY.

HUMAN TRUTH: a species page becomes more useful when the person can move from a canonical species identity to current research metadata and source-linked interaction records without confusing discovery with established biological truth.

BOUNDED CHANGE: reuse the existing SPECIES evidence seam and newly added shared provider adapters. For curated species with an existing source envelope, fetch a small live discovery set from OpenAlex metadata and GloBI. OpenAlex results are research discovery only; titles/metadata are not biological findings. GloBI interactions remain REVIEW_REQUIRED and must retain study/dataset provenance; an indexed interaction is not universal behaviour, abundance, causality, local presence or current state.

TTFV: existing species page still renders from current sources first. Live discovery is progressive enhancement, never a blocker.

SOURCE / RIGHTS: OpenAlex metadata only; do not rehost abstract/full text. GloBI general data licence does not erase original dataset provenance/terms. React output escaping remains mandatory. Provider unavailable/rate-limited => explicit unavailable state; never fabricate fallback records.

MEASUREMENT: source-discovery load state, research records returned, interaction records returned, source-open actions later. These are product-use signals, not ecological outcome.

AUTHORITY: SPECIES = king/test HEIR_ONLY. No ATLAS sandbox mutation. No Supabase schema, BRAIN database, public domain, DNS, payment, outreach or production release.

ACCEPTANCE: typecheck/build/test:smoke plus TEST KING Species+Lens proof; exact candidate SHA; no claim of Gold or live deployment without independent proof.

IMPLEMENTATION COHERENCE RECEIPT: this brief and the SPECIES live-discovery surface marker are updated together in the same bounded change; source discovery stays noncanonical and fail-closed.

---

4NATION UX06 PASS B/C — FINAL RELEASE PREPARATION / PARENT ab08fed29b299779217e04cedf48c7281c1c436d / 27 SEP 2026
ACTUAL VISUAL JUDGMENT performed from Cloudflare screenshots at mobile390/mobile430/tablet/desktop, not source-only. First hosted pass showed overly long mobile page, always-open six-event timeline, oversized marketing WHY block and internal Nation Atlas/Nation Brain labels. PASS B/C commit d742f9ee6cc93c3754eb0c077e73109314e0233f collapses full timeline behind accessible native disclosure, keeps 6 verified events one tap away, changes visible layers to Map/Evidence, removes low-value Our purpose top nav link and replaces huge black marketing section with compact light 4PLANET close. Final immutable preview https://82a64686.4planet-05.pages.dev/4nation. Exact external preview/browser run 36340292741 SUCCESS: 18/18 desktop1440/mobile390/mobile430 including existing people/institution/source/deep-link/map/full ATLAS and new timeline disclosure; real final screenshots captured in workflow 36340696982 and visually reviewed. Product remains evidence-first and politically neutral; same official Oslofjord status/source bundle, no recommendation/ranking/official affiliation.
This SAME COMMIT updates repository release Worker source and existing dispatch-only live workflow to final immutable origin + source SHA d742f9ee6cc93c3754eb0c077e73109314e0233f. NO Cloudflare deploy occurs from this commit. The protected production workflow still requires exact founder_release input "enig send"; auto-push release remains disabled. Existing public 4nation.org therefore continues prior pinned version until that explicit production gate executes. Do not call UX06 LIVE yet. No other domain or Pages production branch may be mutated.
---
4NATION UX06 PASS B/C / VISUAL-JUDGE ITERATION / PARENT a1552c56385675178466a2623ade5f0a888ee3e5
Actual rendered screenshot evidence from immutable Cloudflare preview 852b848d: desktop, tablet, 390 and 430 captured by workflow 36340005095 artifact 4nation-ux06-visual-proof. Visual findings: first fold materially improved, but full mobile remained unnecessarily long because six-event timeline was always expanded; large black WHY block read like marketing instead of utility; Nation Atlas/Nation Brain labels exposed internal architecture; top nav carried low-value purpose jump. This SAME COMMIT responds to the rendered product: rename visible layers Map/Evidence (keys/data unchanged), remove purpose from primary nav, collapse full dated timeline behind native accessible details/summary (all six events and sources retained one tap away), replace oversized black marketing block with compact light 4PLANET-neutral explanation, shorten overall mobile page. No political meaning/status/source data/map behavior/audience modes removed. Tests updated to require disclosure mechanics, all six events after opening, plain labels. Existing new UX preview remains previous candidate until this commit gets exact host preview/browser QA. Public 4nation.org still old build; production release remains dispatch-only exact founder 'enig send'. Maker still not sole Judge.
---
# CURRENT GOLD BRIEF — 4BRANDS COMPANY INTELLIGENCE 0–3

**CHANGE ID:** 4BRANDS-COMPANY-INTELLIGENCE-0-3-2026-09-27

**STATUS:** HEIR / TEST CANDIDATE / NOT GOLD / NO PUBLIC CUSTOM-DOMAIN RELEASE

**BASE AUTHORITY:** `king/test` sole HEIR. This bounded change converges the already-existing 4BRANDS public analysis, authenticated Company Brain, Company Twin and Decision + Value Ledger into one explicit product architecture. It does not create a parallel 4BRANDS app, Brain, database or identity system.

**FOUNDER DIRECTION:** 0. Company Analysis → 1. Company Brain → 2. Company Twin → 3. Future Engine. Company Analysis is the free public entry and acquisition surface. Company Brain is durable company memory/knowledge. Company Twin models the current company. Future Engine explores explicit scenarios before action.

## USER ARRIVES BECAUSE
A person wants to understand a company from public evidence, find potential value, then connect authenticated internal context and test better decisions without losing the distinction between evidence and hypothesis.

## PRIMARY FLOW
Company Analysis → create/sign in with canonical 4PLANET ID → create/select Company Brain workspace → persist analysis + Twin state → inspect Decision + Value Ledger → explore bounded scenarios.

## COMPANY BRAIN
Reuse existing 4Planet_ OS 4BRANDS tenant state, memberships, RLS, durable memories, metrics, decisions, interventions, results, learning and audit. The browser no longer owns a separate Company-Brain-specific auth session; authentication converges on the existing universal 4PLANET ID. Local recovery is non-canonical only.

## FUTURE ENGINE BETA
The first Future Engine is deterministic scenario arithmetic over explicit user assumptions and numeric Twin baselines. It is NOT an AI forecast and does not claim causal prediction. Future probabilistic or learned models require evidence, calibration and separate validation.

## TRUTH BOUNDARY
FACT ≠ ASSUMPTION ≠ SCENARIO ≠ FORECAST ≠ OBSERVED RESULT ≠ ATTRIBUTED VALUE.
Public analysis remains source-aware. Unknown is not zero. Scenario outputs do not become realised value. Company-private state never becomes shared 4PLANET/PLANETBRAIN truth by convenience.

## SECURITY
Company RPCs are authenticated tenant operations. 2026-09-27 backend hardening removed anonymous EXECUTE from Company Brain workspace/snapshot/twin/analysis/intervention/result/value-report/compounding RPCs and narrowed material UPDATE policies to authenticated. Existing membership/RLS checks remain authoritative.

## HUMAN REVIEW INTENT
Verify desktop and mobile hierarchy; the 0–3 architecture is understandable without internal jargon; public Company Analysis still works without login; 4PLANET ID sign-in/create-account returns to Company Brain; authenticated workspace creation/save/readback works for an actual permitted user; scenario controls clearly show assumptions; Company Twin and Value Ledger remain usable; no false forecast/value/impact claim.

## QA / RELEASE GATE
Exact SHA typecheck/build and relevant 4BRANDS/identity/runtime journeys must pass on HEIR or controlled preview. Positive real-user authenticated readback cannot be inferred from source tests. Maker ≠ Judge. Custom-domain LIVE promotion remains a separate Founder-release action; this brief does not authorize it.

--- PRIOR GOLD HISTORY PRESERVED BELOW ---

ATLAS GOLD 04 / MAPLIBRE API TEST COMPATIBILITY / 22 SEP 2026
Parent 93212f4582d141287b7e833cdc1022827bf1a1eb. Exact SHA 1c98ec1 source had previously failing ATLAS Zero Loss mobile 390 click target blocked by Orca context; mobile native controls now usable and click reached MapLibre. Test then crashed on TypeError map.isEasing is not a function, MapLibre v6 runtime does not expose this optional legacy method. SAME COMMIT fixes test compatibility while RETAINING both !map.isMoving() and !map.isZooming() and checking isEasing only when supported. Camera ownership, settled zoom, lat/lng acceptance assertions and timeouts are unchanged. No production, DNS, branch, new architecture or external release. Exact HEAD rebuild/CI required, no Gold before portfolio gates and live camera approved separately.
--- PRIOR HISTORY BELOW ---

4NATION UX06 EXACT-PREVIEW LIVE RELEASE PREPARATION / PARENT 1c98ec1e8bb8a4895279c5365a90e01b5e7a0ecd / 22 SEP 2026
SOURCE: immutable https://852b848d.4planet-05.pages.dev/4nation built from latest authorised source 1c98ec1e8bb8a4895279c5365a90e01b5e7a0ecd incl 63e71442 human-first UX and newer shared ATLAS fix. Actual hosted QA 15/15 desktop/mobile PASS run 35762138657; Nation Gold Candidate QA 35762138682 PASS; Founder Review 35762138742 SUCCESS. This SAME COMMIT updates repo Worker source SHA+Pages origin only, not deployed Cloudflare Worker. Keeps existing workflow workflow_dispatch-only with input exact "enig send"; NO auto release or implicit approval. Repairs release flow stale-old-source checks to new exact preview, and corrects current-domain collision logic: requires root 4nation.org owned by existing Worker 4planet-nation-live; refuses any other Worker, Pages, www DNS or routes; does not edit other domains, Pages production branch or business logic. It also retriggers read-only Cloudflare audit to establish current host owner. PUBLIC ROOT STILL PREVIOUS IMMUTABLE PRODUCT until separately authorised deploy of this prepared Worker source and external 15/15 on 4nation.org. Do not mark UX06 LIVE from this code commit.
---
ATLAS FINAL GOLD CLOSURE 04 / SAME-COMMIT FIX / 22 SEP 2026
Parent 63e71442ef8b2d6f821bf0fa30f84b1652f71d63. Root-cause from exact prior real-domain Chromium: typed 4NATION Embed returns z/c + entity=place:4p:oslofjord WITHOUT record, while the one existing AtlasReturnCameraAuthority guarded ONLY record. World.openPlace then performs fitBounds and overwrites initial camera on full ATLAS; exact live zoom errors 1.486 desktop / 0.774 and 1.006 mobile. Extend the SAME authority to protect explicit entity+z/c, captured by semantic record/entity key; no second map or camera owner. Release on true user pointer/click of native MapLibre controls outside canvas; shift these controls above 58vh mobile context bottom sheet to prevent Orca title intercepting clicks (previous ATLAS Zero Loss failure). Existing PlanetProof Oslofjord constructs MapLibre without ATLAS' Vite self-contained worker; reuse it before Map creation to address HTML-worker fallback and missing MAP READY on 4 desktop/mobile Browser Product Proof cases. NO production/DNS/release/partner action. These are source fixes, not claimed passing until exact new SHA CI, remote preview, real-domain (which CANNOT receive these source changes without Founder release), and independent Gold. Local/end-to-end source-NEWS-Magazine remains outstanding. Preserve prior history below.
---

4NATION HUMAN-FIRST PREMIUM UX + LIVE 06 / CANDIDATE a416d54995a411fb9798beae8d36bd2a03a6f535 / 22 SEP 2026
Founder rejects current LIVE user experience. Rehydrated actual latest HEIR before this change. Code audit: repeated large Oslofjord introductions, two competing hero actions, two perspective entry points, six dashboard-like navigation modules, dense metadata and oversize first-mobile fold. Bounded human-first redesign: public question "What is happening to the Oslofjord?", one primary CTA, original source visible above fold, truthful proposal status + next deadline, compact case record, six preserved layers now progressive calm navigation and institution depth on demand. Original ATLAS Embed/full Atlas, sources, deep links, both audience modes, existing 4PLANET brand tokens and other products preserved. Norwegian ministry public record checked 22 Sept: under consideration, ordinary hearing deadline 15 September passed, separate municipal/county deadline 15 October; original source projection snapshot updated only to 22 Sept. Existing public root still pinned to previous immutable product SHA 4a13f9d...; do not claim UX 06 is LIVE until exact candidate preview QA and separately authorised Cloudflare host-only origin update. Real browser visual review still required; Gold is not self-certified.
---
ATLAS EMBED GOLD 03 / STRICT CONTEXT TEST / 22 SEP 2026
Parent f56f6e6192b0b818adfa488ad1a530dcb0329027. Real-domain read-only browser test at 9690d2b FAILED 3/9 because its regex was accidentally double-escaped. Concurrent f56f6e6 fixed that regex but only asserts *some* numeric zoom/coords, which masks the historically observed camera drift 6.3→7.79 at 4planetatlas.com. This same-commit TEST-ONLY change asserts loaded actual MapLibre style, loaded canvas, exact intended entity/layer and camera center/zoom after place animation, not a transient redirected URL. It additionally covers SPECIES Orca's genuine iframe, historical-observation caveat, same canonical taxon and full Atlas route in first-party previews. 4NATION isolated live host explicitly skips SPECIES route because it does not own that route; live 4NATION assertions remain strict. Expected historical camera drift may make this stricter gate red; do not weaken or claim Gold. No product source architecture, public DNS, hosted production, or release workflow changed. Safety push release guard remains in ceed492. Source/news chain remains blocked on real linked data.
--- EARLIER GOLD HISTORY PRESERVED BELOW ---

4NATION REAL ROOT BROWSER QA REGEX CORRECTION / PARENT 9690d2b01d4f1543c33196581d0e95423786e7f1
First real-domain live workflow 35667108534 proved HTTPS/root/full routes/exact SHA; 6/9 page journeys PASSED; remaining 3 reached https://4planetatlas.com with exact Oslofjord entity and center/zoom, but stale path assertion wrongly expected /atlas. Read-only QA 35667503015 corrected canonical path and still failed due incorrect backslash escaping in new test regex: source /\\d/ matched literal backslash rather than numeric zoom. This SAME COMMIT corrects test regex to numeric coordinates/zoom; no changes to product, Cloudflare, live Worker, immutable artifact, DNS, founder safety gate or other domains. Do not report full 9/9 until fresh read-only live browser workflow PASS.
---
4NATION REAL LIVE HOST VALIDATION / 22 SEP 2026 / PARENT ceed492e93150ac35023fbaf57e2fb388b1a8743
Actual release run 35667108534 attached 4nation.org custom domain and PASSED HTTPS, root, /atlas routes, exact SHA header, indexable HTML. Its external Chromium run has 6/9 PASS but 3 full ATLAS-link tests failed on *obsolete path assertion*: actual click correctly arrived at canonical https://4planetatlas.com/?... with Oslofjord entity=place:4p:oslofjord, valid center and zoom. The prior test incorrectly expected /atlas? on the public Nation hostname; do not redirect canonical product back to Nation or weaken case/map verification. This same-commit test now separately verifies canonical origin, exact entity, coordinates/zoom, and real full Atlas canvas on live host, while preserving original same-origin /atlas assertion for TEST Pages preview. New workflow read-only tests real https://4nation.org desktop/mobile without DNS/Cloudflare writes; protected independent Gold separate. Concurrent safety commit ceed492e... changed live release workflow to workflow_dispatch-only with founder phrase; DO NOT undo or re-enable on push. Real domain remains public and no other 4PLANET domain modified. No claim of 9/9 before new read-only result.
---
4NATION HOST RELEASE DEPLOY RETRY / PARENT 735b10665562c8ae7210f0a4a69b1d28a603170f
Exact root release run 35666998760 verified immutable 4NATION candidate, current HEIR and 4nation.org DNS/Worker/Pages collision none. Wrangler module upload blocked with actual CF error 10021: "Can't set compatibility date in the future: 2026-09-22" while runner UTC was 21 Sep 2026. Same-commit workflow change sets compatibility date 2026-09-21. NO worker/domain/DNS published from prior failed run. No bypass of exact SHA, collision or live browser QA; no effect on 4planet-05 production branch/other domains. Founder explicitly asked public 4nation.org. Report LIVE only after observed external HTTPS and 9/9 hosted Chromium.
---
4NATION EXPLICIT DOMAIN RELEASE / 22 SEP 2026 / PARENT b6ef125515fa37ab8338e1575081a084a7c73ca7
Founder explicit latest direction "fullfør og publiser på url!" specific 4nation.org. Exact immutable preview https://32f3e9de.4planet-05.pages.dev/4nation of source 4a13f9d118066cd6765c3399ebff46a7d3298609; external 9/9 browser PASS run 35664913835 and 4NATION scoped QA PASS 35664913904. Fresh audit 35666452026: active zone, no apex/www DNS, no Pages or Workers domains/routes. Existing 4planet-05 production serves other live sites and must NEVER be changed; new Pages denied quota 8000027. Same-commit host-only Worker custom domain 4nation.org proxies EXACT immutable Pages artifact, rewrites only ROOT to /4nation, preserves full /atlas and assets, strips preview noindex, exposes exact SHA, with fail-closed collision and actual external desktop/mobile proof. No other domains, partner outreach, money, alternate product systems. Historical broad Browser Product Proof RED on Oslofjord MAP READY noted independently; scoped 4NATION pass must not masquerade as all-portfolio Gold. No LIVE claim until actions show actual TLS/routes/QA on 4nation.org. Rollback must not affect existing sites.
---
4NATION DOMAIN 05 READ-ONLY ROUTING RECHECK / 22 SEP 2026
Parent 4a13f9d118066cd6765c3399ebff46a7d3298609. Founder asked to get verified 4nation.org LIVE, not another design round. Retain exact hosted 4NATION QA candidate 4a13f9d118066cd6765c3399ebff46a7d3298609 with immutable preview https://32f3e9de.4planet-05.pages.dev/4nation. This same-commit PRE-FLIGHT audit only extends existing read-only workflow: live apex/www DNS, Pages custom domain owner, existing project 4planet-05, Workers custom domain and Worker routes. It cannot deploy, map, revoke, delete, auto-release, touch other product or mint a parallel app. New Pages project creation blocked by Cloudflare project limit 8000027; do not retry. Protected Browser Product Proof still red on prior Oslofjord MAP READY; do not convert scoped preview QA into portfolio-wide Gold, and preserve Founder acceptance and exact production-release authority. Map approved immutable candidate via existing Cloudflare only after domain owner/collision/TLS and scoped source/visual/security review. No LIVE claim from this audit.
---
4NATION PREVIEW AS LIVING BUILD, SAME-ORIGIN ATLAS / 22 SEP 2026
Parent 63f12276998ba55abab0f66777125e585290af4b. Added canonical-host /atlas guard in parent to prevent "OPEN FULL ATLAS" from recursively landing on Nation homepage at 4nation.org; exact updated candidate must re-run QA and preview. This same commit makes noindex preview trigger from actual Nation/Atlas source and same-commit brief; final hosted page must pass real remote Playwright for people/institutions, full Atlas, sourced case, refresh, desktop 1440 and mobile 390/430. Reuses Cloudflare 4planet-05 nonproduction branch 4nation-preview because account Pages project quota 8000027. No 4nation.org DNS writes, production branch changes or external official claims. Human founder review and independently accepted root release still separate.
---
4NATION 05 / FULL ATLAS EXIT ON CANONICAL HOST / 22 SEP 2026
Parent e194a688879fdf9ae0d57ac09eeb882984302988. Cloudflare noindex preview exact e194a688879fdf9ae0d57ac09eeb882984302988 succeeded external HTTP/noindex on https://b4553b84.4planet-05.pages.dev/4nation in run 35664513886; site visibility is verified on a Pages preview, NOT on 4nation.org.
Before an apex domain LIVE release, inspected src/App.tsx and caught that isNationHost() intercepted plain /atlas (only /atlas?embed=nation escaped to StandardApp). Add canonical-host full /atlas path guard before Nation homepage so OPEN FULL ATLAS preserves the shared Atlas on real 4nation.org, without changing other host behavior or camera/datamodel. Static source contract same commit. No separate map, no root domain DNS action, no inference of independent Human GOLD. New exact QA + review of updated preview required.
---
4NATION preview URL proof / exact candidate bb6de9bcf4a9dced346b41f0aa1bd41e7ac06237. Use bracket-literal dots in Wrangler immutable Pages URL regex; prevents a literal double-backslash parsing error in shell grep. All previous controls remain: same original build, exact QA, noindex, nonproduction branch, no apex/www DNS or production writes; external HTTP/noindex remains mandatory before any Founder preview success. No live or Founder acceptance asserted.
---
4NATION VISUAL PREVIEW 05 — EXACT DEPLOY READBACK REPAIR / 22 SEP 2026
Parent 580021b9c3f90405d4ffee5e537b63de24a5bc19. Previous run 35664082661: 4NATION scoped QA 35664082608 PASS; Founder Review 35664082596 PASS. Cloudflare existing 4planet-05 branch 4nation-preview DEPLOY COMPLETE and immutable URL was printed by Wrangler, but post-deploy GET Pages deployment list with pagination returned HTTP400; job incorrectly lacked external verification despite successful upload. Same-commit bounded workflow fix reads immutable Pages URL printed by successful Wrangler CLI, then externally checks /4nation HTTP200 and noindex. Non-production branch; no 4nation.org DNS, production branch, shared domain or other product mutation; no infer LIVE. If external URL cannot be reached, fail closed. Independent visual Founder review and approved exact LIVE release remain pending.
---
4NATION 05 PREVIEW UNBLOCK / 22 SEP 2026 / PARENT c00f2a01ca1a60f3c421c05fc1566fc06f1d2c5f
Cloudflare token and zone/account GET work. First exact-head noindex preview job 35663783069 reached real Cloudflare Pages project create and returned Cloudflare API error 8000027: account project quota; NO project or DNS created. This SAME-COMMIT bounded adaptation reuses existing 4planet-05 Pages deployment origin via distinct non-production direct-upload branch 4nation-preview, fails if project missing or production branch matches preview branch. Existing 4PLANET build, existing root /4nation route on Preview host and same-origin /atlas preserved. The 4nation.org apex/www are NEVER touched by this workflow. Exact 4NATION QA run 35663783052 SUCCESS on parent version; check fresh new-head QA before any preview publish. Parent branch may move; fail closed on stale HEAD. A non-indexed preview URL is not live domain, independent Human Gold or accepted release. Root 4nation.org release separately Founder-approved after real review and domain/TLS/rollback checks.
---
4NATION EXACT PREVIEW CONTROL / 22 SEP 2026 / PARENT 0a692d4181a02d96c8c713b96c5f594ba4535c45
After candidate c7fcac2d569115988608745c8cf02eadfd0888ea PASS 4NATION QA 35663458214, first noindex preview workflow commit 0a692d4181a02d96c8c713b96c5f594ba4535c45 fail-closed before deploy: exact HEAD had no scoped QA run because workflow-only change did not trigger 4NATION QA. This SAME COMMIT fixes release control: nation QA triggers on visible-preview workflow changes and preview waits for its exact-sha conclusion before any Cloudflare write; Cloudflare account environment exported in same step for Wrangler. Dedicated Pages preview alone, no 4nation.org root DNS, no public live, no Founder acceptance fabricated. Existing latest Atlas, Nation user journeys, build reused without parallel code/data systems. If QA fails, project does not deploy. Independent Human Gold, exact-artifact Founder visual review and separately authorised root-domain release remain open.
---
4NATION LIVE CLOSURE 05 — REAL IFRAME CSS PARSE REPAIR / 22 SEP 2026
Parent 052bfc6b06723ba2b1a96659eb650d0ac639baaf. Source of observed failure: exact 4NATION QA run 35662994086 logged contextual .atlas-embed computed 'contain: strict', height=0, even though the contextual override existed as literal text in src/earth/atlas-embed.css. GitHub file inspection proved its first line contained FOUR literal backslash+n sequences (\\n), including after closing CSS comment; escaped selector did not match. This same-commit repair turns those FOUR malformed sequences into genuine newlines; preserves global legacy .atlas-embed strict containment for existing World/legacy home, while contextual only has contain:none!important and real min-height. Contract regression now checks CSS syntax and contextual override. No fake render, no additional map, no worker/Atlas camera rewrite. Target person/institution paths unchanged, official status remains a proposal, original sources near claims. Existing Cloudflare token availability was previously verified in read-only audit; 4nation.org DNS/Pages absent at prior proof. No LIVE or Human Gold claimed; execute bounded cross-product Chromium on this exact head, create and verify an authorised noindex visual preview before Founder-release, then release exact approved artifact only. Maker is not Judge.
---
ATLAS EMBED RUNTIME + GOLD CLOSURE 02 / AFTER REAL 7a6a76a BROWSER FAILURE / 21 SEP 2026
Parent 7a6a76a325b672841587772b0ff66ed475601713. Exact 4NATION browser run 35662405684: six failures; 3 new Embed tests had DOM section present with contextual subclass but Playwright still computed HIDDEN (toBeVisible timeout 12s) before scrolling, and 3 preexisting 'Outcomes' test selectors became ambiguous after concurrently introduced 4NATION journey navigation. Patch contextual ONLY to explicitly remove legacy strict size containment with !important and give it a real minimum height; legacy Home component untouched. Add diagnostic rect/display/contain log in iframe test without changing its visibility acceptance. Scope existing Outcomes test to the declared 'Explore decision layers' navigation (not waive assertion). Preserve full Atlas, access and source boundaries; Gold brief same atomic code change. Exact browser proof still required; NO GOLD/LIVE asserted.
--- PRIOR BRIEFS PRESERVED BELOW ---

ATLAS EMBED RUNTIME + GOLD CLOSURE 02 — REAL IFRAME ZERO-SIZE ROOT CAUSE / 22 SEP 2026
PARENT=780f625414ef056b64aac8643dffd8a8bfccf482. Playwright archived 4NATION visual + trace for 5f4edbc proved scroll-to-lazy iframe did not trigger /atlas network. The shared first-party worker asset WAS correctly emitted as dist/assets/maplibre-gl-worker-*.js in build, but contextual Embed itself vanished visually. Exact CSS culprit: existing src/styles/global.css line 404 '.atlas-embed { contain: strict; }' from LEGACY Home Globe. Strict contains SIZE, collapses the new contextual React section despite child 500px iframe frame. Fix is a scoped specificity-2 contextual override '.atlas-embed.atlas-embed--contextual{contain:layout paint}' and markup subclass, preserving old Home globe rules unchanged. No timeout manipulation, extra map engine, parallel camera, changes to public site, new branch or content claim. New source+script contract + current Gold brief in same atomic HEIR commit. Target browser proof: iframe URL actually fetched, canvas+isStyleLoaded, source/read state preserved on desktop/mobile; independent review before DONE. No LIVE release authorised.
--- EARLIER GOLD BRIEFS PRESERVED BELOW ---

ATLAS EMBED RUNTIME + GOLD CLOSURE 02 — STANDALONE HOST FULL-ATLAS EXIT / 22 SEP 2026
PARENT=1b61dc67a7212b4d74267ac208c1413c83e43032. The 4NATION standalone host routes ordinary /atlas through NationPage. Embedded /atlas?embed=nation already has a first-party guard, but the previous FULL ATLAS plain /atlas link on the standalone host would not open full ATLAS. Reuse the same canonical Atlas view query; link to 4planet.org/atlas from standalone product hosts and keep same-origin routes on 4planet.org, test.4planet.org, localhost, and existing 4planet-05 Pages previews. The iframe remains first-party; no duplicated renderer, redirected private data or second context. Product source, privacy, status and old Gold control retained. This exact code + brief are atomic. Browser cross-host production behaviour must still be independently verified before Gold; no live release authorized. Concurrent 4NATION journey changes on HEIR are preserved and not reimplemented.
--- PRIOR BRIEFS PRESERVED BELOW ---

4NATION LIVE CLOSURE 04 — BOUNDED HUMAN JOURNEY / 22 SEP 2026
CODE AUTHORITY: existing king/test sole HEIR. This bounded same-commit mutation strengthens focus feedback for the new six-step, source-backed Oslofjord decision journey; preserves current ATLAS shared Embed/worker fix. Earlier 4NATION journey CSS/Page commits were missing SAME-COMMIT Gold brief; historical failures preserved, not waived. Brand tokens #2E2EFF / DM Sans / Instrument Sans / Fragment Mono retained. User: an ordinary citizen or official explores one real proposal with one visible NEXT control, without six dashboard silos. Truth: proposal ≠ adopted policy, existing dated sources, no fake feed/AI/partner/outcome claim. Preview host routing on .4planet-nation.pages.dev is only intended for authorised dedicated noindex preview; no verified Pages host or LIVE 4nation.org. QA state: source/TypeScript existing build previously passed; candidate integrated iframe still under proof. Release: Founder-gated, no 4nation.org DNS/Pages mutation. Maker ≠ Judge. This commit does not imply live or independent Human Gold.
---
ATLAS EMBED RUNTIME + GOLD CLOSURE 02 — EXACT WORKER REPAIR / 22 SEP 2026
STATUS: HEIR TEST CANDIDATE / NO GOLD OR PRODUCTION RELEASE. Parent fbfe292d2bac47a90ec4d84054e4e41e5112b939. Read original Playwright TRACE of 11cd094 before this change: ONE INTERFACE desktop frame requested /assets/maplibre-gl-worker.mjs and received HTTP 200 text/html (Vite SPA fallback), although OpenFreeMap style and tiles responded 200. This is a real executable worker asset failure, not a reason to weaken map-ready/StyleLoaded tests, change basemap provider, duplicate renderer or add new maps. MapLibre v6 official Vite guidance: bundle maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url and call setWorkerUrl before new Map. New browser QA must demonstrate worker JavaScript MIME, isStyleLoaded + MAP READY when applicable, 4NATION lazy iframe on desktop/mobile, preserved canonical context; existing separate tests remain authoritative. Concurrent c512de3 / fbfe292 changed lazy iframe scroll and preview host on same HEIR; this worker repair applies AFTER those changes, no redo or overwrite. Two prior interim commits lacking same-commit Gold brief remain non-compliant history; current change includes this brief in same atomic commit. No production or outreach authorised.
--- PRIOR BRIEFS PRESERVED BELOW ---

CURRENT CORRECTION — 21 SEP 2026 — PRODUCT AUTHORITY ERROR-TO-IMMUNITY
Observed FOUR STATE Founder Review run 35659551649 FAIL for 7f5665a: two prior HEIR performance commits (89c103a, 7f5665a) changed product code without modifying this GOLD_CURRENT_BRIEF.md in the SAME commit. This is a real control-protocol defect, not a missing Cloudflare deploy. Preserve failed run and history; this correction does not retroactively mark earlier commits compliant.
This SAME correction commit adds an actual 4NATION desktop/mobile iframe/browser path, declares exact AtlasEmbed scope and reiterates independent Gold/release gates. Future performance fixes must include this brief in the same code change. Source for recovery: https://github.com/odinskogen-dev/4Planet.05/actions/runs/35659551649 .
--- PRIOR CURRENT BRIEF AND HISTORICAL RECORDS PRESERVED BELOW ---

# CURRENT GOLD BRIEF — ATLAS SHARED ENGINE + EMBED 01
CHANGE ID: ATLAS-SHARED-EMBED-2026-09-21
STATUS: HEIR TEST CODE CANDIDATE / NOT GOLD / NO PUBLIC RELEASE
BASE: king/test@e71f343af57f04a17a4468038b89e142794a083a; one controlled atomic commit. Existing ATLAS sandbox PR #263 remains separate and is not overwritten.
FOUNDER LAW: ONE PLANET. MANY WAYS TO SEE IT. Standalone Atlas Explore plus purpose-specific AtlasEmbed reusing the same MapLibre/PLANETBRAIN engine.
P1 DOMINANT: A person sees a focused interactive map inside an existing SPECIES profile or a dated 4NATION public decision, not the full ATLAS console.
P2 ORIENTATION: Source, geometry and time caveats are adjacent. A PLACE navigation bbox is not an official catchment, a taxon occurrence is not a live animal/range, a proposal is not a decided outcome.
P3 ACTION / NEXT: Open exact matching context in full ATLAS. On standalone product hosts /atlas?embed=... resolves to shared ATLAS rather than re-entering standalone product.
P4 DEPTH: MapLibre data layers and ProductContext retain authority. NEWS/IMPACT/BRANDS/PERSONAL/SOLUTIONS are typed consumers without fabricated content/private URL projection; MAGAZINE requires sourced Story/Place relation before adding a public pin.
WHAT CAN BE REMOVED: Coordinates-only pseudo-map in 4NATION and duplicate ATLAS chrome inside iframe. Never remove existing source/proof caveats, species Atlas links or editorial content.
WHAT MUST BE REUSED: existing World/PublicWorld; productContext camera+record authority; planet places and taxon identities; first-party embed and resize donor selectively; no second map engine, backend, source registry, private tenant store or independent AtlasNews.
MOBILE-FIRST RISK: WebKit zero-size embedded canvas, overlays intercepting touch pan, cross-host /atlas recursion. Only viewport resize recovery; full ATLAS exit remains available.
HUMAN SUCCESS: Desktop/mobile user opens real 4NATION Oslofjord navigation view and SPECIES canonical taxon view in shared ATLAS; full ATLAS remains useful, no misleading geography or false live state.
MAKER ≠ JUDGE: Exact SHA npm typecheck/build/smoke/browser, HEIR Pages readback, independent Gold and founder review before promotion. Inherited MAP READY defect stays open. No domain LIVE mutation, paid service, partner claim or external send. Capital APP-130 remains separate P0.
--- PRIOR GOLD BRIEFS PRESERVED BELOW ---

# CURRENT GOLD BRIEF

This file is the machine-readable human contract for the **current bounded TEST KING change**. Historical briefs belong in issue/PR evidence; this file always reflects the current mutation.

**CHANGE ID:** 4SAPIEN-CORE-FINANCE-01-2026-09-20

**STATUS:** HEIR / TEST-ONLY / PERSONAL ECONOMY CORE / NO PRODUCTION LIVE RELEASE

**BASE AUTHORITY:** `king/test` / sole HEIR integration line

**LIVE IDENTITY:** `https://4sapien.com/` remains unchanged; LIVE promotion is outside this change

**FOUNDER DIRECTION:** make personal economy useful in practice first; add legal/provider-ready bank connectivity and manual portfolio value without widening into a generic Life OS.

## USER ARRIVES BECAUSE
A person wants one honest view of the money they can use, what they owe, and what their manually entered investments are worth now.

## ONE THING TO UNDERSTAND
4SAPIEN can calculate a useful personal money picture immediately from user-entered facts. Bank data is shown as connected only after an authorised account-information provider and explicit user consent exist. Four bank refreshes per day is a target constrained by the bank/provider, never a universal guarantee.

## PRIMARY ACTION
Add or update an account or holding and immediately see recorded liquidity, debt, portfolio cost, current market value and unrealised change.

## SECONDARY DEPTH
Show source, as-of time, missing values, currency boundaries, bank consent/sync state, last successful sync, next eligible sync and provider limits. Manual current prices remain clearly manual until a licensed market-data source is configured.

## P1 DOMINANT
The dominant layer is the user's recorded economy: liquid accounts, debt and holdings. Empty states lead directly to a useful first entry.

## P2 ORIENTATION
The surface says whether data is MANUAL, CONNECTED, STALE, PARTIAL or UNKNOWN. It never presents a provider-ready seam as an active bank connection.

## P3 ACTION / NEXT
The next action is one of: add account, add holding, update current price, inspect sync status or remove local TEST data. No trade execution or personalised BUY / SELL instruction exists.

## P4 DEPTH
Deep evidence includes per-record source and as-of time, portfolio formula inputs, consent expiry, rate-limit state, sync receipts and explicit gaps. Provider credentials and bank link references stay server-side outside browser-readable tables.

## WHAT CAN BE REMOVED
Remove the old finance placeholder, fake-connected states, zero-as-unknown arithmetic, silent cross-currency totals and any market-data integration without production-use rights. Preserve the existing `GOLD-TEMPLATE-REFINEMENT-02` human hierarchy, provenance, privacy boundaries and Founder release gate.

## TRUTH BOUNDARY
- Manual values are user-entered facts, not bank-verified facts.
- Current holding price is a manual quote until a licensed provider is configured.
- Different currencies are never silently added together without an FX rate.
- Unknown is never coerced to zero.
- Four bank syncs per day is an adaptive target; provider/bank limits may allow fewer.
- Portfolio monitoring is factual arithmetic, not investment advice or trade execution.
- Yahoo/yfinance is not introduced as a commercial production dependency.

## PRIVACY AND SECURITY
- Authenticated canonical finance rows remain owner-scoped under RLS.
- Anonymous users receive no canonical finance-table privileges.
- Provider credentials and provider connection references are never exposed to the browser.
- The HEIR proof may use clearly labelled device-local storage only; it is not canonical authenticated state and can be cleared by the user.
- Analytics must never receive balances, holdings, tickers, quantities, prices, bank names or free text.

## MOBILE-FIRST RISK
Account and holding forms, summary cards, tables and sync state must remain complete at 390/430 widths with no horizontal overflow or hidden truth labels.

## HUMAN SUCCESS
Within two minutes, a first-time user can enter one liquid account and one holding, understand the resulting totals, update a price, reload without losing TEST state, and explain which values are manual versus bank/provider verified.

## WHAT MUST BE REUSED
Existing 4SAPIEN/Embla route, `king/test` HEIR, Product Surface Registry, Finance Twin truth rules, canonical `4Planet_ OS` Supabase project, owner RLS pattern, Cloudflare exact-SHA review surface and existing privacy-safe analytics spine. No new BRAIN, product, database, auth system or branch.

## CURRENT BOUNDED DELTAS
- Replace the `/4sapien/finance` placeholder with a working TEST-only manual economy and portfolio surface.
- Add deterministic finance arithmetic and adaptive bank-sync scheduling contracts.
- Add an additive Supabase migration for owner-scoped holdings, quotes, public connection status and private provider references.
- Record a provider boundary compatible with an authorised PSD2 account-information provider; do not activate credentials or consent externally.
- Correct the stale 4SAPIEN LIVE registry fact without granting LIVE write authority.
- Selectively adopt finance truth conventions from the read-only 4SAPIEN production donor; do not wholesale-merge it.

## OUT OF SCOPE / FOUNDER GATES
- No mutation or release to `4sapien.com`.
- `ENIG LIVE` remains the separate explicit production-release command; this change does not contain it.
- No provider signup, commercial agreement, credential creation or bank consent.
- No production database migration or Edge Function deployment.
- No payment, transfer, order, trade execution, NAV workflow or personalised financial recommendation.
- No automated Yahoo Finance dependency.

## ACCEPTANCE
1. `king/test` remains the sole write-authorised HEIR; LIVE remains unchanged.
2. Manual accounts and holdings persist on the device in HEIR TEST and can be deliberately cleared.
3. Liquidity, debt, cost basis, market value and unrealised change are deterministic and currency-safe.
4. Bank status explicitly says NOT CONNECTED until an authorised provider is configured and consented.
5. The bank scheduler respects consent and provider rate limits while targeting at most four successful refreshes per day.
6. Database objects are owner-scoped, explicitly granted, indexed and separated from provider secrets.
7. No sensitive finance values or identifiers are emitted to analytics.
8. Typecheck, build, finance contracts, product-authority gate and relevant 390/430/desktop browser tests pass on the exact HEIR head.
9. A working Founder-visible HEIR URL exists before delivery is called complete.
10. Production release remains a separate explicit Founder decision.

## MAKER ≠ JUDGE
The builder may prove deterministic calculations, security shape and browser behaviour, but may not self-certify Human Gold or release to LIVE. Founder review and separate production authority remain required.

## BOUNDED SECURITY REPAIR — VERIFIED VALUE CLOSURE 03
- ATLAS `src/earth/World.tsx` uses a MapLibre named namespace import in preparation for patched MapLibre 6.10.0 ESM; this is compatibility only, not new ATLAS capability.
- SAFE HEIR workflow must run npm audit, typecheck, build, smoke and assets on exact HEIR before committing package/lock; security remains RED until independent tests pass. No LIVE promotion or inflated product proof.


## BOUNDED PARALLEL 4NATION CANDIDATE — 21 SEPTEMBER 2026
- This addendum records a separate, isolated `work/4nation-first-gold-prototype-01` candidate. It DOES NOT replace the current 4SAPIEN finance HEIR brief above, promote the 4NATION branch to TEST KING, or authorise live mutation. No parallel write authority is claimed.
- USER ARRIVES BECAUSE: a citizen wants to know what is being considered in their place; an institutional analyst wants the factual decision context.
- ONE THING TO UNDERSTAND: a sourced Oslofjord 2026–2030 proposal is still under consideration, not a final adopted plan; six integrated lenses share one official evidence projection.
- PRIMARY ACTION: inspect one government hearing, its dates/status, original sources and human/ecological/financial constraints; switch between people and institutional views.
- SECONDARY DEPTH: scientific models versus measured outcomes, a separate grant announcement versus complete costs, unknowns and original source links.
- REUSE: existing PLANETBRAIN `src/planet/places.ts` Oslofjord place; `src/planet/decisionIntelligence.ts` donor as reference ONLY due unverified source states; Brand fonts/colors, `src/App.tsx` isolated host pattern and existing routes. No auth, DB, new BRAIN or paid service.
- TRUTH: 21 September 2026 dated manually reviewed primary-source fixture; ordinary hearing deadline 15 September passed, local/regional extended deadline 15 October; no fake AI, live feed, policy winner or governmental endorsement.
- MOBILE / HUMAN GOLD: two comprehensible user journeys with six lenses, source drawer and responsive 390px desktop; runtime QA pending.
- ACCEPTANCE: exact candidate commit, separate tests, independent source/UX/accessibility/security review and Founder release before 4nation.org. Do not merge this branch to main directly; reconcile via authorised `king/test` TEST KING path only after all gates.
- Project Home: https://docs.google.com/document/d/1IAB_myJZ3pT0rx58QNBJmuCutxhGlWBKBuOjO__NuBo/edit


## 4NATION WORLD-CLASS PRODUCT CONVERGENCE 02 — BOUNDED CHANGE / 21 SEPTEMBER 2026

**AUTHORISATION:** Existing `king/test` sole HEIR; independent production release remains a separate Founder decision. No change to live domains, no duplicate BRAIN, no new registered sandbox.

**USER ARRIVES BECAUSE:** People want to see a real public decision immediately; public-sector readers want inspectable evidence and material constraints without a six-app learning curve.

**ONE THING TO UNDERSTAND:** The proposed Oslofjord 2026–2030 plan is *under consideration*; both audiences share one date-stamped official-source case.

**PRIMARY ACTION:** Open the decision card directly from the first viewport, choose person/institution perspective, inspect the government record, follow the timeline or copy a deep link retaining the selected perspective and decision lens.

**SECONDARY DEPTH:** Progressively navigate Atlas, source-grounded Brain summary (NOT live AI), Solutions, Economy and Outcomes. Sources are adjacent to claims; unknowns are explicit.

**P1 DOMINANT:** Real Oslofjord decision is the first feature, not an abstract invented fjord illustration, giant manifesto or six equal app modules.

**P2 ORIENTATION:** Ministry, jurisdiction, snapshot date, proposal vs adopted distinction, ordinary consultation deadline vs special local/regional deadline.

**P3 ACTION / NEXT:** Explore public decisions / Explore decision intelligence / original proposal / copy case link, each advertised control actually functional.

**P4 DEPTH:** Case timeline with original sources, separate grants versus plan costs, model versus measured outcomes, PLACE lineage to existing ATLAS.

**WHAT CAN BE REMOVED:** Faux-geographical decorative hero; unsupported coordinates on home; redundant opening paragraphs, hidden and generic app-nav hierarchy; source-list-only access.

**WHAT MUST BE REUSED:** Existing `src/planet/places.ts`, Brand typography/color variables and main app route/host seam, shared authority, existing Gold/test and dated decision case.

**TRUTH BOUNDARY:** One dated, manually verified official decision candidate, no live feed, official partnership, policy recommendation, autonomous public action or proven ecological effect. Accessibility and rights checks remain independent QA.

**MOBILE-FIRST RISK:** 390/430 widths must display both entry actions and visible real case; no clipped case actions, horizontal overflow or inaccessible drawer. Reduced-motion scroll respected.

**HUMAN SUCCESS:** Within seconds a visitor understands 4NATION and notices the real Oslofjord issue; completes exact sourced status, authority, next step and original source in fewer clicks than initial large abstract hero. Two journeys share one case; no design success asserted until visually and human reviewed.

**MAKER ≠ JUDGE / RELEASE:** Factual source check and scoped technical tests are necessary but not sufficient for production. Existing FOUR STATE Founder Review exact ATLAS sandbox evidence and baseline Oslofjord MAP READY failure are open. No direct domain change, auto-promotion or false live claim from this brief.

Gold QA repair, 21 Sep: Source-contract test updated to assert the clearer actual UI wording ‘Proposal, not an adopted plan.’ No weakening of underlying claim; official status remains UNDER CONSIDERATION. This fix and its Gold brief are in one bounded TEST KING commit. No live authority.


## 4NATION 07 — ONE CASE FIRST / HUMAN-FIRST CORRECTION — 28 SEP 2026

STATUS: BOUNDED HEIR PRODUCT CHANGE / CANDIDATE QA REQUIRED / PUBLIC LIVE ORIGIN UNCHANGED BY THIS CHANGE.

USER JOB: A first-time person should immediately understand one real public decision without passing through source-search tools or internal product architecture first.

CHANGE: The Oslofjord case is again the first-screen object. The hero asks “What is happening to the Oslofjord?”, retains the single UX06 primary CTA “Explore public decisions”, and keeps source/status beside the case. Stortinget case discovery and SSB statistical context remain available but move behind progressive disclosure after the six-lens case journey. No source adapter, shared fact model, ATLAS contract, 4PLANET ID path or political decision logic is replaced.

SOURCE/TRUTH: Official Norwegian Ministry hearing record re-checked 28 Sep 2026. Public status remains under consideration; ordinary consultation deadline 15 Sep 2026 has passed; separate municipality/county politically processed deadline is 15 Oct 2026. Proposal, consultation, decision, implementation and measured outcome remain distinct. No policy recommendation or government affiliation is implied.

ACCEPTANCE: 4NATION source-state contracts, typecheck/build/smoke/lint, desktop 1440 and mobile 390/430 browser journey, primary-source access, people/institution views, six lenses, timeline disclosure, ATLAS embed/full route and progressive source-tool disclosure must pass. Human craft/Founder visual review remains distinct from maker implementation.

ROLLBACK: revert the bounded 4NATION 07 commit(s). Existing public 4nation.org Worker stays pinned to its previously verified immutable UX06 origin until a separately authorised exact tested artifact is promoted.

QA CORRECTION / 28 SEP 2026: 4NATION source-date contract advanced with the verified snapshot from 22 Sep to 28 Sep; no political status, deadline, source identity or decision semantics changed.

UX CONTRACT CORRECTION / 28 SEP 2026: “Understand your nation.” remains visible as the 4NATION product proposition, but is no longer a second competing hero heading. The Oslofjord question is the single hero heading. Browser acceptance now asserts that hierarchy directly. The compact factual status label remains “PROPOSAL · UNDER CONSIDERATION”.


## 4NATION 08 — HUMAN NATION + MUNICIPAL DECISION MAP — 28 SEP 2026

STATUS: BOUNDED HEIR PRODUCT CANDIDATE. 4NATION 07 is the current verified live origin while this exact 08 candidate completes Gold + hosted visual QA. Founder has explicitly authorised live iteration; only an exact tested immutable 08 artifact may replace the live origin.

PRODUCT JOB: make public decisions understandable as one connected journey: NORWAY → PLACE → PUBLIC DECISION → DECISION THREAD → ATLAS → ORIGINAL EVIDENCE.

DESIGN: 4NATION now adopts the existing 4SAPIEN human-first visual grammar rather than creating a parallel design system: white paper, soft 20–22px rounded cards, calm hairlines, compact rounded controls, Instrument Sans + DM Sans, and persistent light/dark mode. 4NATION keeps its own semantic identity and neutral public-decision status language.

CANONICAL OBJECT: src/planet/nationPublicDecisions.ts defines one PublicDecision shape for national and municipal records. Proposal, consultation, decided, implementing and measured remain distinct stages. A case may have additional evidence/process events without silently promoting its political state.

FIRST PLACE MODELS:
- NORWAY_ — Oslofjord proposal remains the national source-reviewed anchor.
- BERGEN_ — Bergen municipal model uses the official political case for “Et tryggere samfunn – sammen”, including recorded treatment through city government, committees and City Council.
- OSLO_ — Oslo municipal model includes the 2026 land-use-plan consultation and the separately adopted district reform, so consultation and implementation states are visibly different.

ATLAS: existing shared 4PLANET ATLAS is the geographic navigation surface for Norway, Bergen and Oslo through canonical PLACE ids. Current map extent is navigational context. Kartverket/Geonorge official administrative boundary data is registered as the authoritative boundary source, but 08 MUST NOT claim that legal municipal polygons or decision-specific implementation geometry are rendered until that overlay is physically integrated and verified.

DATA BACKBONE: official-source federation is exposed progressively: Kartverket/Geonorge geography, Stortinget open-data search, SSB Statbank search, Bergen municipality and Oslo municipality. Existing PLANETBRAIN/PLACE/ATLAS infrastructure remains shared; no Government Brain or duplicate truth database is created.

MOBILE / ACCESSIBILITY: place selector, municipality lookup, case selector, decision stage path, ATLAS and source thread must work at 390/430 and desktop widths without horizontal document overflow. Theme state persists locally; reduced-motion and existing source/dialog contracts remain.

POLITICAL / TRUTH BOUNDARY: 4NATION describes sourced procedural state and evidence. It does not rank political options, recommend a vote or policy choice, infer motives, claim governmental endorsement, or convert proposals/consultations into adopted or implemented policy.

ACCEPTANCE: source-contract test, typecheck, build, smoke, lint, desktop 1440 + mobile 390/430 browser proof, hosted immutable Founder Visual Preview, Norway/Bergen/Oslo place journey, shared ATLAS, original-source links and persistent light/dark mode must all pass on the exact artifact before live promotion.

LIVE PROOF CONTROL: the real-domain browser workflow derives the expected SOURCE_SHA from the canonical 4NATION Worker and waits for that exact artifact on 4nation.org before testing. No stale hard-coded live SHA is accepted.


4NATION 08 QA NOTE / 28 SEP 2026: Browser assertions are explicitly scoped to the intended decision surface and ATLAS iframe. This preserves both the new place-level map and the existing deep Oslofjord map without weakening either product contract. Real-domain proof now also triggers on canonical Worker source changes.


## SECURITY HEIR INTEGRATION — 03 OCT 2026

**STATE:** HEIR CONTROL CORRECTION / NOT A PRODUCT FEATURE / NOT LIVE / INDEPENDENT RE-JUDGEMENT REQUIRED.

**EXACT HEIR LINEAGE:** parent `46453259c9a15ffd8fd86daeb14e153f4ce72f40` → security lock commit `9c6dc8a418674b3819001966a2cc20246d431751` → this brief child.

**CHANGE:** retain the already independently-reviewed `package-lock.json` delta only: transitive `brace-expansion` 5.0.9 → 5.0.12 inside the existing `minimatch@10.2.5` range. `package.json` and user-facing product source are unchanged. The resulting lock blob is `c219160ec3d5bca8005793efc7edf1d6dd4a9760`, matching the accepted donor package.

**WHY:** remove the high-severity dependency-audit blocker from the lawful TEST KING receiver without suppressing audit rules, changing product behaviour, opening a parallel branch/system, or granting LIVE/release authority.

**HUMAN REVIEW INTENT:** independent Judge must confirm the exact HEIR candidate preserves product behaviour and that the high audit is cleared. Separate existing Andons remain separate: bundle-size gate and any unrelated workflow failures are not waived by this security correction.

**BOUNDARY:** no LIVE promotion, no external release, no product-value claim, no Human Gold claim. Maker ≠ Judge. The next state may advance only from physical CI + independent judgement.
# EXPOSURE — ORCA SEARCH / SHARE / AI DISCOVERY 01 — 03 OCT 2026

**STATUS:** HEIR-ONLY CANDIDATE / NOT GOLD / NO LIVE PROMOTION / NO INDEX SUBMISSION OR EXTERNAL DISTRIBUTION AUTHORISED.

**AUTHORITY / FOUR-STATE RESOLUTION:** Affected seam = SPECIES / ORCA discovery. LIVE remains `https://4planet.org/species/orca` with registry identity `READBACK_REQUIRED`. HEIR is the sole `king/test` line at the exact parent recorded by the commit. SPECIES and ORCA have no registered SANDBOX. The implementation therefore lands only on HEIR; the temporary unregistered work branch is quarantine/donor evidence with zero product or promotion authority. Rollback is the exact parent SHA. Production remains Founder-gated.

**USER ARRIVES BECAUSE:** A person searches for Orca / killer whale information, follows an AI answer or receives a shared link and needs a trustworthy, understandable species entry point.

**ONE THING TO UNDERSTAND:** This is the canonical 4PLANET profile for *Orcinus orca*, built from named source roles. Reported occurrence records are evidence records, not live animal positions, abundance, range or population trend.

**PRIMARY ACTION:** Understand the Orca profile, then open the linked whale context in the existing 4PLANET ATLAS.

**SECONDARY DEPTH:** Inspect GBIF taxon identity, OBIS occurrence provenance, NOAA descriptive context, uncertainty, rights and forbidden inferences through the existing evidence seam.

**P1 DOMINANT / P2 ORIENTATION / P3 ACTION / P4 DEPTH:** P1 = Orca identity and useful plain-language profile. P2 = scientific name plus truth boundary. P3 = explore the same subject in ATLAS. P4 = sources, provenance, rights, update semantics and limitations.

**QUESTION / DELETE / SIMPLIFY / REUSE:** Do not create a new Species page, SEO engine, source store or share-card system. Remove the generic search/share projection for Orca by reusing the existing Species route, discovery inventory, source envelope, rights-cleared Orca media, sitemap/prerender pipeline and ATLAS whales object.

**SIMPLEST CAPABLE EXECUTION:** Deterministic metadata and prerender projection over existing canonical objects. No new service, workflow, agent or database.

**TRUTH / SOURCE / RIGHTS BOUNDARY:** Citation URLs are copied only from the existing Orca Source Envelope: GBIF, OBIS and NOAA. JSON-LD identifies a `Taxon` but does not assert population, range, abundance, trend, ecotype, pod or live location. The social image is the existing founder-supplied Orca asset whose current repository rights record is `LICENCE_VERIFIED`; ownership is not asserted and source/rights detail remains visible in evidence records.

**MOBILE-FIRST RISK:** Metadata must not change the rendered mobile hierarchy. The added raw prerender source/limitations content is crawler-visible fallback and must not create duplicate visible content after hydration.

**HUMAN SUCCESS:** A search, AI or shared-link visitor sees a specific Orca title/description/image, can distinguish source fact from occurrence limitations and can continue into the ATLAS whales object. Actual ranking, reach, engagement, return or sharing remains UNKNOWN until measured on a released artifact.

**DESIRED STATE / PROOF:** Exact HEIR commit includes Orca-specific title/description, rights-controlled share image, three canonical citations, Taxon JSON-LD, limitations, ATLAS journey and regression tests. Required proof = discovery contract, Species source contract, product-authority gate, Gold policy gate, typecheck and production build on the exact SHA. Independent Gold plus a Founder-visible HEIR readback are required before any acceptance claim.

**DOOR CLASS / RELEASE:** Internal HEIR code is a reversible two-way door under current execution authority. HEIR→LIVE, IndexNow/search submission, public post, social distribution and any external publication remain one-way Founder-gated actions.

**MAKER ≠ JUDGE / ANDON:** AXE is maker for this bounded candidate, never Gold judge. Stop on source mismatch, rights regression, structured-data invalidity, authority failure, hydration duplication or exact-head CI failure.

---


## SPECIES GOLD PLANK 02 — QA_ACCEPT + FIRST FACTORY BATCH / 2026-10-06

JOB: Q4-REALITY-SPECIES-GOLD-PLANK-20261003-01.
ACCEPTED CANDIDATE: PR #390 exact SHA `300bec3246f489b3e2f42a062bdd728a0c89eae2`.
INDEPENDENT JUDGE: QA_ACCEPT at Slack message `1791247818.791819` after QA_CORRECT → minimal fix → exact-SHA reverify.
MAKER ≠ JUDGE: AXE/ChatGPT authored the successor; Cursor operated read-only verifier/Judge on the final exact SHA.

GOLD PLANK RESULT:
- one shared Human-First `SpeciesEditorialProfile`; no Orca/Jaguar layout fork and no `isOrca` shared-layout authority;
- child differences remain data/config/media/source driven;
- Jaguar unsupported ecosystem-health inference is absent and conflicting population estimates remain withheld/UNKNOWN;
- curated first read excludes the technical SpeciesEvidenceSeam while controlled source/truth/rights depth remains;
- ATLAS canonical taxon handoff preserves occurrence ≠ range / abundance / trend / migration / live position;
- parent-owned truthful no-photo fallback handles missing rights-cleared photography;
- Chromium + WebKit desktop/390/430 Gold Plank matrix = 30/30 on accepted SHA;
- typecheck PASS, production build PASS, smoke 317/317;
- inherited whole-app >1.8 MB bundle debt remains open and is not a SPECIES candidate-caused defect.

FIRST FACTORY BATCH 01:
10 source-envelope-bound species are contract/browser-proven through the same plank:
African Savanna Elephant; Cheetah; Blue Whale; Tiger; Polar Bear; Whale Shark; Green Turtle; Emperor Penguin; Giant Panda; Elkhorn Coral.
Factory browser matrix = 4/4 on accepted SHA.

NEW COMPOUNDING ASSET PROOF:
Elkhorn Coral (`taxon:gbif:5184657`, `/species/acropora-palmata`) was materialised from an already-existing canonical source envelope into the normal SPECIES object + discovery inventory + same shared renderer. No coral-specific renderer/layout was created. This is physical evidence that the plank can convert additional source-grounded species knowledge into a public product asset with lower marginal technical work.

DISCOVERY:
Accepted build prerenders 26 indexable curated species. Discovery contract now explicitly requires 26 and includes `acropora-palmata`. Ranking, organic traffic, AI-discovery reach and user value remain UNKNOWN until observed after release.

ASSET STATE AT HEIR INTEGRATION:
CONNECTED / PRODUCTISED / TEST-GOLD. Not LIVE until targeted release is separately authorised, deployed and physically verified.
CONSUMERS: SPECIES, NATUREBRAIN/PLANETBRAIN source graph, ATLAS taxon handoff, Search/AI discovery, Factory.
VALUE PATH: verified knowledge → shared plank → indexable species asset → discovery/user → ATLAS/deeper exploration → behavioural evidence → learning → next species.
FACTORY ECONOMICS: reuse/marginal-code reduction is proven qualitatively; exact compute/time/founder-minute economics are not yet instrumented and must not be invented.

NEXT AFTER HEIR LANDED + LIVE GATE:
targeted SPECIES release from current real LIVE/main baseline only; do not promote unrelated TEST HEIR changes. After LIVE verification, continue 25 → 50 → 100 using the same plank; floor +1 genuine Gold species/day, 3–5/day only if source/rights/product/Gold quality remains intact.

---

# ATLAS MOBILE HUMAN + PERFORMANCE CLOSURE 01 — 7 OCT 2026

**STATUS:** TEST HEIR CANDIDATE / NO LIVE RELEASE CLAIM.

**FOUNDER FAILURE EVIDENCE:** real iPhone use showed overlapping Search, EARTH/NOW/WATCH, Layers, My Atlas and Context surfaces; keyboard search clipping/duplicate taxon rows; misleading LIVE labels on source-query records; and severe interaction jank.

**BOUNDED OUTCOME:** preserve the existing ATLAS map engine, layers, source semantics and product depth while converging mobile interaction to one owning work surface at a time: SEARCH / CONTEXT / LAYERS / NOW-WATCH / MY ATLAS. At rest Earth remains primary. Controls are smaller and rounded rather than large rectangular chrome.

**PERFORMANCE LAW — NO INVISIBLE WORK:** remove the body-wide search MutationObserver; integrate data-layer intent directly into the existing React search path; stop one-second whole-ATLAS clock renders; replace sub-second Time polling with MapLibre events; reduce evidence fallback polling from 900 ms to 15 s; stop Zoom Stack work on tile/source churn; use a smaller mobile tile cache and shorter raster fade; do not fetch the shared EONET/USGS signal pool until NOW/WATCH or an explicit place/coordinate question needs it. Hidden surfaces do not earn recurring CPU/network work.

**SEARCH:** mobile search owns the interaction plane while active, uses dynamic viewport height for the iOS keyboard, hides competing controls, de-duplicates provider taxon rows by scientific identity, and resolves existing data-layer intents without page reload.

**TRUTH:** query-derived GBIF/source results are labelled RECORDS / RECENT RECORDS / SOURCE RECORD rather than implying that the underlying biological or event state itself is live. Coordinate-event search radius becomes zoom-sensitive instead of a fixed 400 km label.

**4PLANET ID / MY ATLAS:** anonymous use remains local-first. Signed-in users use the existing canonical 4PLANET ID/Supabase authority; follows and saved ATLAS views merge with the local copy and sync to the user-owned `four_planet_atlas_state` row. RLS restricts that row to `auth.uid()`; anonymous database access is revoked. No second identity system, Brain or account store is created.

**DATABASE:** one user-state projection only: `public.four_planet_atlas_state(user_id, follows, saved_views, updated_at)`. It stores explicit user choices, not location history, inferred interests or background tracking.

**ZERO-LOSS:** no existing public ATLAS layer, source, map engine, context type, Follow target, Saved View primitive, NOW/WATCH data path or provenance boundary is intentionally removed.

**ACCEPTANCE:** exact TEST HEIR SHA must pass typecheck, build, smoke including `atlas-mobile-human-performance-contract.test.mjs`, ATLAS Zero Loss, mobile browser proof at 390×844 and 430×932, and visual review showing no competing panel overlap. Production remains Founder/release-gated; do not call this LIVE before the canonical promotion path passes.

**COMPATIBILITY CLOSURE:** integrated search rows retain canonical `data-atlas-intent-layer` identity for proof/automation; anonymous My Atlas explicitly states device-local storage and `SAVE CURRENT VIEW +`; curated SPECIES retains an accessible same-entity continuation into ATLAS. These preserve existing zero-loss contracts while keeping the new mobile surface.

**DISCOVERY CLOSURE:** the canonical `/atlas` route retains explicit title/description/canonical metadata and `WebApplication` JSON-LD. The metadata names planetary layers and Biodiversity observations without implying coverage or source states not present in ATLAS; the wording intentionally preserves the existing discoverability contract.

**CROSS-PRODUCT GATE REPAIR:** Browser Product Proof exposed two real contract mismatches outside the ATLAS runtime. FOOD's generic-reference region no longer shares the input's accessible name, so "Generic food" resolves to the intended textbox only. 4NATION's official Stortinget/SSB tools remain intentionally collapsed behind progressive disclosure; the browser proof now opens that disclosure before exercising the tools instead of treating hidden content as visible. No 4NATION product disclosure was removed or forced open.

**MOBILE VIEWPORT CLOSURE:** MapLibre now resizes on actual window/orientation/VisualViewport changes and after ATLAS work-surface transitions. The root map uses dynamic viewport units with a legacy fallback, preventing the iOS/Safari canvas from retaining a stale height and appearing cut after browser chrome or keyboard changes. TIME no longer listens to tile-level sourcedata churn, and TIME / MY ATLAS explicitly close each other so two external sheets cannot own the phone viewport simultaneously.

**WEBGL CAPABILITY CLOSURE:** ATLAS no longer equates a browser-reported major performance caveat with absence of WebGL. A valid WebGL context may run the map; actual mobile cost remains bounded by the ATLAS performance controls. This prevents capable software-backed or power-constrained devices from being incorrectly forced into the static fallback.

**ATLAS PREVIEW PROOF ISOLATION:** browser QA may bypass only the preliminary WebGL capability probe when the host is localhost or a non-canonical `.pages.dev` preview and the explicit `atlasCiWebgl=1` parameter is present. Canonical public hosts cannot activate this path. The LIVE Atlas-only router maps the standalone domain root to the canonical `/atlas` app route while leaving shared Pages production untouched.
