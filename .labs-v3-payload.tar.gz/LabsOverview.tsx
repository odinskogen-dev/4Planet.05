import { useEffect, useMemo, useState, type CSSProperties, type ReactNode } from "react";
import {
  childrenOf,
  descendantsOf,
  founderQueue,
  portfolioStats,
  projectBySlug,
  projects,
  projectionState,
  recentSystemMoves,
  universeRoots,
  verifiedAt,
  type LabProject,
} from "./labsData";
import "./labs.css";

type Theme = "dark" | "light";
type InspectHandler = (project: LabProject) => void;

function isLabsHost() {
  if (typeof window === "undefined") return false;
  return window.location.hostname.toLowerCase() === "labs.4planet.org";
}

function currentSlug() {
  if (typeof window === "undefined") return "";
  if (isLabsHost()) return window.location.pathname.replace(/^\/+|\/+$/g, "");
  const query = new URLSearchParams(window.location.search).get("project");
  return query?.replace(/^\/+|\/+$/g, "") ?? "";
}

function labHref(slug = "") {
  const clean = slug.replace(/^\/+|\/+$/g, "");
  if (isLabsHost()) return clean ? `/${clean}` : "/";
  return clean ? `/labs?project=${encodeURIComponent(clean)}` : "/labs";
}

function accentStyle(project: LabProject) {
  return { "--accent": `var(--accent-${project.accent})` } as CSSProperties;
}

function milestoneRatio(project: LabProject) {
  const milestones = project.milestones ?? [];
  if (milestones.length === 0) return "UNKNOWN";
  return `${milestones.filter((item) => item.done).length}/${milestones.length}`;
}

function GridRails() {
  return (
    <div className="labs-rails" aria-hidden="true">
      {Array.from({ length: 13 }, (_, index) => <span key={index} />)}
    </div>
  );
}

function Arrow() {
  return <span aria-hidden="true">↗</span>;
}

function StatusPill({ children }: { children: ReactNode }) {
  return <span className="labs-status">{children}</span>;
}

function ShellHeader({ back, theme, onTheme }: { back?: string; theme: Theme; onTheme: () => void }) {
  return (
    <header className="labs-header">
      <a className="labs-brand" href={labHref(back ?? "")}><span className="labs-online-dot" />4PLANET LABS</a>
      <div className="labs-header-center">MISSION OS / HUMAN PROJECT CONTROL</div>
      <div className="labs-header-tools">
        <span>SNAPSHOT {verifiedAt}</span>
        <span className="labs-online">● ONLINE</span>
        <button
          className="labs-theme-toggle"
          type="button"
          onClick={onTheme}
          aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
        >
          <span className={theme === "dark" ? "is-active" : ""}>DARK</span>
          <span className={theme === "light" ? "is-active" : ""}>WHITE</span>
        </button>
      </div>
    </header>
  );
}

function LabsFooter() {
  return (
    <footer className="labs-footer">
      <span>4PLANET LABS / NOINDEX / PUBLIC DEVELOPMENT</span>
      <span>BRAIN IS AUTHORITY · LABS IS A VIEW</span>
      <a href="https://4planet.org">4PLANET.ORG <Arrow /></a>
    </footer>
  );
}

function Frame({ children, back, theme, onTheme }: { children: ReactNode; back?: string; theme: Theme; onTheme: () => void }) {
  return (
    <div className="labs-shell" data-theme={theme}>
      <ShellHeader back={back} theme={theme} onTheme={onTheme} />
      <main className="labs-page">
        <GridRails />
        {children}
      </main>
      <LabsFooter />
    </div>
  );
}

function Freshness() {
  return (
    <div className="labs-freshness" role="note">
      <span>DATA STATE</span>
      <strong>{projectionState}</strong>
      <span>VERIFIED {verifiedAt}</span>
    </div>
  );
}

function CommandMetric({ value, label, note, accent = false }: { value: string | number; label: string; note: string; accent?: boolean }) {
  return (
    <div className={`labs-command-metric${accent ? " is-accent" : ""}`}>
      <strong>{value}</strong>
      <div><span>{label}</span><small>{note}</small></div>
    </div>
  );
}

function CommandBar() {
  return (
    <section className="labs-command labs-grid-section" aria-label="Founder command overview">
      <div className="labs-command-label">FOUNDER COMMAND</div>
      <div className="labs-command-grid">
        <CommandMetric value={portfolioStats.founder} label="DECISIONS / ACTIONS" note="Projected Founder last-mile" accent />
        <CommandMetric value={portfolioStats.aiActive} label="AI NEXT / ACTIVE" note="Task items in this snapshot" accent />
        <CommandMetric value={portfolioStats.active} label="MOVING PROJECTS" note="Active / building / public" />
        <CommandMetric value={portfolioStats.queued} label="QUEUED / LABS" note="Not on the main critical path" />
        <CommandMetric value={portfolioStats.conflicts} label="OPEN CONFLICTS" note="Kept explicit, not guessed" />
      </div>
    </section>
  );
}

function ProjectBox({ project, onInspect, compact = false }: { project: LabProject; onInspect?: InspectHandler; compact?: boolean }) {
  return (
    <a
      className={`labs-project-box${compact ? " is-compact" : ""}`}
      href={labHref(project.slug)}
      style={accentStyle(project)}
      data-accent={project.accent}
      data-state={project.state}
      onMouseEnter={() => onInspect?.(project)}
      onFocus={() => onInspect?.(project)}
    >
      <div className="labs-box-scan" aria-hidden="true" />
      <div className="labs-box-top">
        <span>{project.kind}</span>
        <StatusPill>{project.state}</StatusPill>
      </div>
      <div className="labs-box-title">
        <strong>{project.title}</strong>
        <span>{project.priority}</span>
      </div>
      <div className="labs-box-bottom">
        <span>{project.next}</span>
        <span>OPEN →</span>
      </div>
      <div className="labs-box-hover" aria-hidden="true">
        <span className="labs-label">WHY</span><p>{project.why}</p>
        <span className="labs-label">CURRENT</span><p>{project.now}</p>
        <span className="labs-label">NEXT</span><p>{project.next}</p>
      </div>
    </a>
  );
}

function DomainPanel({ project, onInspect }: { project: LabProject; onInspect: InspectHandler }) {
  const missions = childrenOf(project.slug);
  return (
    <section className="labs-domain-panel" style={accentStyle(project)} data-accent={project.accent}>
      <a className="labs-domain-head" href={labHref(project.slug)} onMouseEnter={() => onInspect(project)} onFocus={() => onInspect(project)}>
        <div>
          <span>{project.eyebrow}</span>
          <strong>{project.title}</strong>
        </div>
        <div><StatusPill>{project.state}</StatusPill><span>{missions.length} MISSIONS</span></div>
      </a>
      <div className="labs-domain-missions">
        {missions.map((missionProject) => <ProjectBox project={missionProject} key={missionProject.slug} onInspect={onInspect} compact />)}
      </div>
    </section>
  );
}

function UniverseGlyph({ universe }: { universe: LabProject["universe"] }) {
  if (universe === "4PLANET") return <span aria-hidden="true">◎</span>;
  if (universe === "ODIN") return <span aria-hidden="true">✦</span>;
  if (universe === "P4NTHER") return <span aria-hidden="true">◇</span>;
  return <span aria-hidden="true">□</span>;
}

function UniversePanel({ root, onInspect }: { root: LabProject; onInspect: InspectHandler }) {
  const children = childrenOf(root.slug);
  const domains = children.filter((project) => project.kind === "DOMAIN");
  const core = children.filter((project) => project.kind !== "DOMAIN");

  return (
    <section className={`labs-universe labs-universe--${root.universe.toLowerCase()}`} style={accentStyle(root)} data-accent={root.accent}>
      <a className="labs-universe-head" href={labHref(root.slug)} onMouseEnter={() => onInspect(root)} onFocus={() => onInspect(root)}>
        <div className="labs-universe-title">
          <UniverseGlyph universe={root.universe} />
          <div>
            <span>{root.eyebrow}</span>
            <h2>{root.title}</h2>
          </div>
        </div>
        <div className="labs-universe-meta">
          <StatusPill>{root.state}</StatusPill>
          <span>{root.summary}</span>
          <span>OPEN UNIVERSE →</span>
        </div>
      </a>

      {core.length > 0 && (
        <div className="labs-core-maze">
          {core.map((project) => <ProjectBox project={project} key={project.slug} onInspect={onInspect} />)}
        </div>
      )}

      {domains.length > 0 && (
        <div className="labs-domain-maze">
          {domains.map((domain) => <DomainPanel project={domain} key={domain.slug} onInspect={onInspect} />)}
        </div>
      )}

      {children.length === 0 && (
        <div className="labs-empty-box">
          <span>NO PUBLIC-SAFE CHILD PROJECTS PROJECTED YET</span>
          <p>BRAIN may contain more. LABS does not invent or expose them until a verified projection is allowed.</p>
        </div>
      )}
    </section>
  );
}

function Inspector({ project }: { project: LabProject }) {
  const tasks = (project.tasks ?? []).slice(0, 3);
  const decisions = (project.founderDecisions ?? []).slice(0, 2);
  const assets = (project.assets ?? []).slice(0, 4);
  const children = childrenOf(project.slug);

  return (
    <aside className="labs-inspector" style={accentStyle(project)} data-accent={project.accent} aria-label="Selected project preview">
      <div className="labs-inspector-kicker">PROJECT PREVIEW / {project.kind}</div>
      <div className="labs-inspector-title">
        <div><StatusPill>{project.state}</StatusPill><span>{project.priority}</span></div>
        <h2>{project.title}</h2>
        <p>{project.summary}</p>
      </div>

      <div className="labs-inspector-strip">
        <div><span>MILESTONES</span><strong>{milestoneRatio(project)}</strong></div>
        <div><span>CHILDREN</span><strong>{children.length}</strong></div>
        <div><span>FOUNDER</span><strong>{decisions.length}</strong></div>
      </div>

      <div className="labs-inspector-section">
        <span className="labs-label">CURRENT TRUTH</span>
        <p>{project.now}</p>
      </div>
      <div className="labs-inspector-section is-next">
        <span className="labs-label">NEXT</span>
        <p>{project.next}</p>
      </div>
      <div className="labs-inspector-section">
        <span className="labs-label">AXE / AI PLAN</span>
        <p>{project.aiPlan}</p>
      </div>

      {tasks.length > 0 && (
        <div className="labs-inspector-list">
          <span className="labs-label">ACTIVE TASKS</span>
          {tasks.map((task, index) => <div key={`${task.text}-${index}`}><span>{task.owner}</span><p>{task.text}</p><StatusPill>{task.state}</StatusPill></div>)}
        </div>
      )}

      <div className="labs-inspector-list">
        <span className="labs-label">FOUNDER ACTION</span>
        {decisions.length > 0 ? decisions.map((decision, index) => <div key={decision}><span>{String(index + 1).padStart(2, "0")}</span><p>{decision}</p></div>) : <p className="labs-quiet">No Founder blocker projected.</p>}
      </div>

      <div className="labs-inspector-list">
        <span className="labs-label">LINKED ASSETS</span>
        {assets.length > 0 ? assets.map((asset) => (
          <a href={asset.href} target="_blank" rel="noreferrer" key={`${asset.kind}-${asset.href}`}><span>{asset.kind}</span><p>{asset.label}</p><span>↗</span></a>
        )) : <p className="labs-quiet">No public-safe linked assets projected.</p>}
      </div>

      <div className="labs-inspector-foot">
        <span>{project.authority}</span>
        <span>{project.freshness}</span>
      </div>
      <a className="labs-open-project" href={labHref(project.slug)}>OPEN FULL PROJECT PAGE →</a>
    </aside>
  );
}

function FounderQueue() {
  return (
    <section className="labs-founder-queue">
      <div className="labs-section-head labs-section-head--inline">
        <span>FOUNDER DECISIONS / ACTIONS</span>
        <span>{founderQueue.length.toString().padStart(2, "0")} PROJECTED</span>
      </div>
      <div className="labs-founder-list">
        {founderQueue.length > 0 ? founderQueue.map((item, index) => (
          <a href={labHref(item.slug)} key={`${item.slug}-${item.decision}`}>
            <span>{String(index + 1).padStart(2, "0")}</span>
            <strong>{item.project}</strong>
            <p>{item.decision}</p>
            <span>→</span>
          </a>
        )) : <p className="labs-empty-copy">No Founder decision is projected in this public-safe snapshot.</p>}
      </div>
    </section>
  );
}

function PortfolioView({ theme, onTheme }: { theme: Theme; onTheme: () => void }) {
  const [selectedSlug, setSelectedSlug] = useState("4planet");
  const selected = projectBySlug(selectedSlug) ?? projectBySlug("4planet")!;

  return (
    <Frame theme={theme} onTheme={onTheme}>
      <CommandBar />
      <Freshness />

      <section className="labs-intro labs-grid-section">
        <div>
          <span className="labs-kicker">PROJECT UNIVERSE / HUMAN VIEW</span>
          <h1>LABS</h1>
        </div>
        <p>One place to see what exists, what is moving, what comes next and where your judgement is needed. Hover or focus a project to inspect it; open it for the full project view.</p>
      </section>

      <div className="labs-portfolio-layout labs-grid-section">
        <div className="labs-portfolio-main">
          <div className="labs-section-head labs-section-head--inline">
            <span>PROJECT MAZE / PRIORITISED BY ACTIVE IMPORTANCE</span>
            <span>4PLANET → DOMAINS → ODIN → P4NTHER → SANDBOX</span>
          </div>
          <div className="labs-universe-stack">
            {universeRoots.map((root) => <UniversePanel key={root.slug} root={root} onInspect={(project) => setSelectedSlug(project.slug)} />)}
          </div>
          <FounderQueue />
          <section className="labs-system-feed">
            <div className="labs-section-head labs-section-head--inline"><span>SYSTEM FEED</span><span>LATEST CONTROL MOVES</span></div>
            {recentSystemMoves.map(([id, move, state]) => <div className="labs-feed-row" key={id}><span>{id}</span><strong>{move}</strong><StatusPill>{state}</StatusPill></div>)}
          </section>
          <section className="labs-projection-note">
            <span className="labs-label">PROJECTION RULE</span>
            <p>BRAIN remains the authority. LABS is deliberately read-only while LABS-7 is unverified. Missing values stay UNKNOWN. Private Founder finance, health, legal, sensitive capital intelligence, secrets and protected records do not cross into this public surface.</p>
          </section>
        </div>
        <Inspector project={selected} />
      </div>
    </Frame>
  );
}

function SectionTitle({ left, right }: { left: string; right?: string }) {
  return <div className="labs-section-head"><span>{left}</span><span>{right ?? ""}</span></div>;
}

function SnapshotCard({ label, text, accent }: { label: string; text: string; accent?: boolean }) {
  return <article className={`labs-snapshot-card${accent ? " is-accent" : ""}`}><span className="labs-label">{label}</span><p>{text || "UNKNOWN"}</p></article>;
}

function Milestones({ project }: { project: LabProject }) {
  const items = project.milestones ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="DONE / MILESTONES" right={`${items.filter((item) => item.done).length}/${items.length || 0} COMPLETE`} />
      <div className="labs-milestones">
        {items.length > 0 ? items.map((item) => (
          <div key={item.label} className="labs-milestone-row"><span>{item.done ? "✓" : "○"}</span><strong>{item.label}</strong><span>{item.done ? "DONE" : "OPEN"}</span></div>
        )) : <div className="labs-unknown-state">UNKNOWN — no milestone set is projected for this project yet.</div>}
      </div>
    </section>
  );
}

function Roadmap({ project }: { project: LabProject }) {
  const items = project.roadmap ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="ROADMAP" right="EVIDENCE-GATED" />
      {items.length > 0 ? <div className="labs-project-roadmap">{items.map((item, index) => (
        <article key={`${item.stage}-${item.title}`}><span>{String(index + 1).padStart(2, "0")} / {item.stage}</span><strong>{item.title}</strong><p>{item.text}</p></article>
      ))}</div> : <div className="labs-unknown-state">UNKNOWN — no project roadmap is projected here yet.</div>}
    </section>
  );
}

function Processes({ project }: { project: LabProject }) {
  const items = project.processes ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="PROCESSES" right="CURRENT PROJECT SYSTEM" />
      <div className="labs-process-list">
        {items.length > 0 ? items.map((item) => <div key={item.name} className="labs-process-row"><strong>{item.name}</strong><StatusPill>{item.state}</StatusPill><p>{item.text}</p></div>) : <div className="labs-unknown-state">UNKNOWN — process projection not connected yet.</div>}
      </div>
    </section>
  );
}

function Tasks({ project }: { project: LabProject }) {
  const items = project.tasks ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="ACTIVE TASKS" right="AI / FOUNDER OWNERSHIP" />
      <div className="labs-task-list">
        {items.length > 0 ? items.map((item, index) => <div key={`${item.text}-${index}`} className="labs-task-row"><span>{String(index + 1).padStart(2, "0")}</span><strong>{item.text}</strong><span>{item.owner}</span><StatusPill>{item.state}</StatusPill></div>) : <div className="labs-unknown-state">UNKNOWN — no current tasks are projected for this project.</div>}
      </div>
    </section>
  );
}

function Assets({ project }: { project: LabProject }) {
  const assets = project.assets ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="LINKED ASSETS" right="PUBLIC-SAFE LINKS ONLY" />
      {assets.length > 0 ? <div className="labs-assets-grid">{assets.map((asset) => (
        <a key={`${asset.kind}-${asset.href}`} href={asset.href} target="_blank" rel="noreferrer"><span>{asset.kind}</span><strong>{asset.label}</strong><span>OPEN ↗</span></a>
      ))}</div> : <div className="labs-unknown-state">UNKNOWN — no public-safe linked asset is projected for this project yet.</div>}
    </section>
  );
}

function ProjectChildren({ project }: { project: LabProject }) {
  const children = childrenOf(project.slug);
  if (children.length === 0) return null;
  const domains = children.filter((child) => child.kind === "DOMAIN");
  const rest = children.filter((child) => child.kind !== "DOMAIN");
  return (
    <section className="labs-project-section">
      <SectionTitle left="SUBPROJECTS / COMPONENTS" right={`${children.length.toString().padStart(2, "0")} DIRECT VIEWS`} />
      {rest.length > 0 && <div className="labs-child-grid">{rest.map((child) => <ProjectBox project={child} key={child.slug} />)}</div>}
      {domains.length > 0 && <div className="labs-detail-domains">{domains.map((domain) => <DomainPanel project={domain} key={domain.slug} onInspect={() => undefined} />)}</div>}
    </section>
  );
}

function FounderDecisions({ project }: { project: LabProject }) {
  const decisions = project.founderDecisions ?? [];
  return (
    <section className="labs-project-section">
      <SectionTitle left="FOUNDER DECISIONS" right={decisions.length > 0 ? "FOUNDER LAST-MILE" : "NO PROJECTED BLOCKER"} />
      <div className="labs-founder-project-list">
        {decisions.length > 0 ? decisions.map((decision, index) => <div key={decision}><span>{String(index + 1).padStart(2, "0")}</span><p>{decision}</p></div>) : <div className="labs-unknown-state">No Founder decision is projected as blocking this project in this public-safe snapshot.</div>}
      </div>
    </section>
  );
}

function EvidenceAuthority({ project }: { project: LabProject }) {
  return (
    <section className="labs-project-section">
      <SectionTitle left="EVIDENCE / AUTHORITY" right="READ-ONLY PROJECT PROJECTION" />
      <div className="labs-authority-grid">
        <div><span className="labs-label">EVIDENCE</span><p>{project.evidence}</p></div>
        <div><span className="labs-label">AUTHORITY</span><p>{project.authority}</p></div>
        <div><span className="labs-label">FRESHNESS</span><p>{project.freshness}</p></div>
        <div><span className="labs-label">LABS STATE</span><p>{projectionState}</p></div>
      </div>
    </section>
  );
}

function ProjectPage({ project, theme, onTheme }: { project: LabProject; theme: Theme; onTheme: () => void }) {
  const back = project.parent ?? "";
  const descendantCount = descendantsOf(project.slug).length;
  const founderCount = (project.founderDecisions ?? []).length;

  return (
    <Frame back={back} theme={theme} onTheme={onTheme}>
      <div className="labs-project-surface" style={accentStyle(project)} data-accent={project.accent}>
        <section className="labs-project-identity labs-grid-section">
          <div className="labs-project-path"><a href={labHref(back)}>← {project.parent ? "PARENT PROJECT" : "ALL LABS"}</a><span>{project.eyebrow}</span></div>
          <div className="labs-project-title-row"><h1>{project.title}</h1><div><StatusPill>{project.state}</StatusPill><span>{project.priority}</span></div></div>
          <p>{project.summary}</p>
        </section>

        <section className="labs-project-control labs-grid-section">
          <div><span>STATUS</span><strong>{project.state}</strong></div>
          <div><span>MILESTONES</span><strong>{milestoneRatio(project)}</strong></div>
          <div><span>DESCENDANTS</span><strong>{descendantCount}</strong></div>
          <div><span>FOUNDER ITEMS</span><strong>{founderCount}</strong></div>
          <div><span>FRESHNESS</span><strong>{verifiedAt}</strong></div>
        </section>

        <section className="labs-snapshot-grid labs-grid-section">
          <SnapshotCard label="WHY IT EXISTS" text={project.why} />
          <SnapshotCard label="CURRENT TRUTH" text={project.now} />
          <SnapshotCard label="NEXT MILESTONE" text={project.next} accent />
          <SnapshotCard label="AXE / AI FORWARD PLAN" text={project.aiPlan} />
        </section>

        <div className="labs-project-body labs-grid-section">
          <ProjectChildren project={project} />
          <FounderDecisions project={project} />
          <Milestones project={project} />
          <Roadmap project={project} />
          <Processes project={project} />
          <Tasks project={project} />
          <Assets project={project} />
          <EvidenceAuthority project={project} />
        </div>

        <section className="labs-project-actions labs-grid-section">
          <div><span className="labs-label">PROJECT ROUTE</span><strong>{`labs.4planet.org/${project.slug}`}</strong></div>
          <div className="labs-action-links">
            <a href={labHref(back)}>← BACK</a>
            {project.externalUrl && <a href={project.externalUrl} target="_blank" rel="noreferrer">OPEN PUBLIC SURFACE <Arrow /></a>}
          </div>
        </section>
      </div>
    </Frame>
  );
}

function UnknownProject({ slug, theme, onTheme }: { slug: string; theme: Theme; onTheme: () => void }) {
  return (
    <Frame theme={theme} onTheme={onTheme}>
      <section className="labs-unknown labs-grid-section">
        <span className="labs-label">UNREGISTERED PROJECT VIEW</span>
        <h1>NO CANONICAL PROJECT FOUND.</h1>
        <p>`/{slug}` is not represented as a registered LABS project in this projection. Nothing has been invented to fill the gap.</p>
        <a href={labHref()}>← RETURN TO LABS</a>
      </section>
    </Frame>
  );
}

export default function LabsOverview() {
  const slug = useMemo(currentSlug, []);
  const project = projectBySlug(slug);
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === "undefined") return "dark";
    return window.localStorage.getItem("4planet-labs-theme") === "light" ? "light" : "dark";
  });

  const onTheme = () => setTheme((current) => current === "dark" ? "light" : "dark");

  useEffect(() => {
    window.localStorage.setItem("4planet-labs-theme", theme);
  }, [theme]);

  useEffect(() => {
    const title = !slug ? "4PLANET LABS — Project Universe" : project ? `${project.title} — 4PLANET LABS` : "Unregistered Project — 4PLANET LABS";
    document.title = title;
    let robots = document.querySelector('meta[name="robots"]') as HTMLMetaElement | null;
    if (!robots) {
      robots = document.createElement("meta");
      robots.name = "robots";
      document.head.appendChild(robots);
    }
    const previous = robots.content;
    robots.content = "noindex,nofollow,noarchive";
    return () => { robots!.content = previous; };
  }, [project, slug]);

  if (!slug) return <PortfolioView theme={theme} onTheme={onTheme} />;
  if (project) return <ProjectPage project={project} theme={theme} onTheme={onTheme} />;
  return <UnknownProject slug={slug} theme={theme} onTheme={onTheme} />;
}

void projects;
