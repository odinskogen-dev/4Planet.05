import { test, expect } from "@playwright/test";

/**
 * GOLD / WORLD CLASS — objective Human Craft regression layer.
 * Founder-selected LOST GOLD baseline: build/market-sale-01-poster hero,
 * premium navigation/menu grammar and full-bleed Domain entries.
 *
 * Browser assertions prove structure, responsiveness and already-decided hierarchy;
 * they do not replace Founder judgement on visual taste.
 */

async function assertNoHorizontalOverflow(page) {
  const overflow = await page.evaluate(() => {
    const root = document.documentElement;
    return Math.max(root.scrollWidth, document.body?.scrollWidth || 0) - root.clientWidth;
  });
  expect(overflow).toBeLessThanOrEqual(1);
}

async function assertPremiumNavigation(page) {
  const width = page.viewportSize()?.width ?? 1440;

  if (width <= 920) {
    const menu = page.getByRole("button", { name: "Open menu" });
    await expect(menu).toBeVisible();
    await menu.click();
    await expect(page.getByRole("button", { name: "Close menu" })).toBeVisible();
    await expect(page.getByRole("dialog", { name: "4PLANET navigation" })).toBeVisible();
    await expect(page.getByText("EXPLORE_", { exact: true })).toBeVisible();
    for (const label of ["ATLAS", "SPECIES", "LIVING SYSTEMS", "IMPACT"]) {
      await expect(page.getByRole("link", { name: new RegExp(`^${label}`) }).first()).toBeVisible();
    }
    await expect(page.getByText("DOMAINS + MISSIONS_", { exact: true })).toBeVisible();
    await expect(page.getByRole("link", { name: /OCE4N/i }).first()).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(page.getByRole("button", { name: "Open menu" })).toBeVisible();
  } else {
    for (const label of ["EXPLORE", "DOMAINS", "MISSIONS", "CULTURE", "ABOUT"]) {
      await expect(page.getByRole("button", { name: label, exact: true })).toBeVisible();
    }
    await page.getByRole("button", { name: "EXPLORE", exact: true }).hover();
    await expect(page.getByRole("region", { name: "EXPLORE navigation" })).toBeVisible();
    await expect(page.getByRole("link", { name: /ATLAS/i }).first()).toBeVisible();
  }

  await expect(page.getByText(/4NTARCTICA/i)).toHaveCount(0);
  await expect(page.getByText(/4TELIER/i)).toHaveCount(0);
}

for (const project of ["desktop-1440", "mobile-390", "mobile-430"] as const) {
  test.describe(`${project} GOLD human-craft`, () => {
    test.use({});

    test("planet hero, join action, four ways in, sixteen missions and no overflow", async ({ page }, testInfo) => {
      test.skip(testInfo.project.name !== project, `belongs to ${project}`);
      await page.goto("/", { waitUntil: "load" });

      const h1 = page.getByRole("heading", { level: 1 });
      await expect(h1).toHaveCount(1);
      await expect(h1).toHaveText(/Everything you love is connected\./i);
      await expect(page.getByRole("link", { name: /^Join 4PLANET$/ }).first()).toBeVisible();
      await expect(page.getByRole("link", { name: /Explore the planet/i })).toBeVisible();

      await page.keyboard.press("Tab");
      const skip = page.getByRole("link", { name: /SKIP TO (MAIN )?CONTENT/i });
      await expect(skip).toBeFocused();
      await skip.press("Enter");
      await expect(page.locator("#main-content")).toBeFocused();

      await assertPremiumNavigation(page);

      // Four ways in sit inside the hero; Living Systems keeps its canonical document route.
      await expect(page.locator(".hp-ways a")).toHaveCount(4);
      await expect(page.locator('.hp-ways a[href="/livingsystems/"]')).toHaveCount(1);

      // ATLAS loads live on demand (no second app boot on first paint).
      await expect(page.getByRole("heading", { name: "One planet. Many relationships." })).toBeVisible();
      await expect(page.locator(".hp-atlas iframe")).toHaveCount(0);
      await page.getByRole("button", { name: /Start the live Atlas/i }).click();
      const atlasFrame = page.frameLocator('iframe[title="Interactive 4PLANET Atlas"]');
      await expect(atlasFrame.locator("canvas.maplibregl-canvas")).toBeVisible({ timeout: 20_000 });

      await expect(page.locator(".hp-sp")).toHaveCount(4);

      // Zero loss: four Domains and all sixteen Missions are visible links on the homepage.
      const worlds = page.locator(".hp-world");
      await expect(worlds).toHaveCount(4);
      await expect(page.locator(".hp-missions a")).toHaveCount(16);

      // Real IMPACT network objects, not prototype units.
      await expect(page.locator('.hp-pj[href^="/impact/project/"]')).toHaveCount(6);
      await expect(page.getByRole("heading", { name: "We believe the future can be better." })).toBeVisible();

      const width = page.viewportSize()?.width ?? 1440;
      if (width <= 680) {
        const firstWorld = await worlds.first().boundingBox();
        expect(firstWorld).not.toBeNull();
        expect(firstWorld!.width).toBeGreaterThanOrEqual(width - 2);
      }

      await assertNoHorizontalOverflow(page);
    });
  });
}
