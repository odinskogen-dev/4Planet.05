import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { img } from "@/content/imageRegistry";

/**
 * Planet entrance (founder decision 31 Oct 2026): full-bleed Earth, planetary scale first.
 * Primary action = Join 4PLANET (4PLANET ID sign-up). Four ways in sit inside the first fold.
 */
const still = img("heroEarth");
export const JOIN_URL = "https://id.4planet.org/login?mode=signup&return_to=" + encodeURIComponent("https://4planet.org/");


export function AtlasHero({ children }: { children?: ReactNode }) {
  return (
    <section className="hp-hero" aria-labelledby="hp-hero-title">
      <picture>
        {still.srcMobile && <source media="(max-width:680px)" srcSet={still.srcMobile} />}
        <img src={still.src} alt={still.alt} className="hp-hero__img" fetchPriority="high" decoding="async" width={2200} height={1464} />
      </picture>
      <div aria-hidden className="hp-hero__scrim" />
      <div className="hp-shell hp-hero__inner">
        <p className="hp-mono hp-hero__data">Earth · 6,371 km radius · The only known living planet</p>
        <h1 id="hp-hero-title">Everything you love is connected.</h1>
        <p className="hp-hero__lede">Discover life on Earth, understand what is changing, and meet the people working to protect and restore it.</p>
        <div className="hp-actions">
          <a href={JOIN_URL} className="hp-btn">Join 4PLANET</a>
          <Link to="/atlas" className="hp-btn hp-btn--ghost">Explore the planet</Link>
        </div>
        {children}
      </div>
    </section>
  );
}
