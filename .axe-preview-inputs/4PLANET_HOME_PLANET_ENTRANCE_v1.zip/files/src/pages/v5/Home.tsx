import { useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { PublicShell } from "@/components/layout/PublicShell";
import { GoldThemeToggle } from "@/components/gold/GoldThemeToggle";
import { content } from "@/content/contentRepository";
import { img, type ImageKey } from "@/content/imageRegistry";
import { IMPACT_UNITS } from "@/data/impactUnits";
import type { DomainKey } from "@/types/content";
import { AtlasHero, JOIN_URL } from "./AtlasHero";
import "@/styles/home-brand-reset.css";

/* ——— Editorial curation (founder-reviewable). All links are existing public routes. ——— */

const SPECIES = [
  { slug: "orca", name: "Orca", latin: "Orcinus orca", line: "Ocean hunters with cultures of their own — families pass on calls and hunting techniques.", src: "/assets/species/orca/detail-spyhop.jpg" },
  { slug: "humpback-whale", name: "Humpback whale", latin: "Megaptera novaeangliae", line: "Travels thousands of kilometres between feeding and breeding waters — and sings on the way.", src: "/assets/species/humpback-whale/SP-001-mobile.jpg" },
  { slug: "jaguar", name: "Jaguar", latin: "Panthera onca", line: "The largest cat in the Americas needs large, connected forests and rivers.", src: "/assets/species/jaguar/SP-005-mobile.jpg" },
  { slug: "hyacinth-macaw", name: "Hyacinth macaw", latin: "Anodorhynchus hyacinthinus", line: "The largest flying parrot, cracking palm nuts few other animals can open.", src: "/assets/species/hyacinth-macaw/SP-006-mobile.jpg" },
] as const;

type Dk = DomainKey;
const WORLDS: { dk: Dk; slug: string; system: string; line: string; image: ImageKey }[] = [
  { dk: "OCE4N_", slug: "oce4n", system: "Marine systems", line: "The ocean makes Earth a living planet. Follow whales across ocean basins, rebuild reefs and keep plastic out of the sea.", image: "oce4nDomainHero" },
  { dk: "E4RTH_", slug: "e4rth", system: "Terrestrial systems", line: "Forests, rivers, soil and wild species — the living land we all depend on, and how it comes back.", image: "e4rthDomainHero" },
  { dk: "S4PIENS_", slug: "s4piens", system: "Human systems", line: "Food, energy, cities and what we wear: the human systems where better choices change the most.", image: "s4piensDomainHero" },
  { dk: "4CULTURE_", slug: "4culture", system: "Cultural systems", line: "Stories, film, art and music that make people notice, care — and act.", image: "cultureAnchor" },
];

/** Curated from the public IMPACT Living Action Network (projection 30 Oct 2026). Listing ≠ partnership or verified outcome. */
const PROJECTS = [
  { slug: "great-pacific-garbage-patch", kind: "Operating programme", place: "North Pacific Ocean", title: "Great Pacific Garbage Patch Cleanup", actor: "The Ocean Cleanup", line: "Removing floating plastic at sea while improving how hotspots are found.", d: "OCE4N_" },
  { slug: "coral-gardeners-reef-restoration", kind: "Field restoration", place: "Pacific & Southeast Asia", title: "Coral Gardeners Reef Restoration", actor: "Coral Gardeners", line: "Growing corals in nurseries and replanting reefs, with ongoing monitoring.", d: "OCE4N_" },
  { slug: "acarai-rupununi-corridor-protection", kind: "Proposed protection", place: "Guyana", title: "Acarai–Rupununi Corridor", actor: "Rainforest Trust", line: "Funders have pledged support for Guyana’s proposal to protect the corridor. Formal protection is not yet in place.", d: "E4RTH_" },
  { slug: "phoenix-species-project", kind: "Species recovery", place: "30 countries", title: "Phoenix Species Project", actor: "Re:wild", line: "Locally led recovery for 100 highly threatened species. Funding announced; recovery still to come.", d: "E4RTH_" },
  { slug: "bee-friendly-farming", kind: "Farm stewardship", place: "Working farms", title: "Bee Friendly Farming", actor: "Pollinator Partnership", line: "Pollinator habitat and better management on farms that grow our food.", d: "S4PIENS_" },
  { slug: "wateraid-beacon-project-nepal", kind: "Community water", place: "Lahan, Nepal", title: "The Beacon Project", actor: "WaterAid", line: "Reliable water, sanitation and hygiene for a whole town by 2030.", d: "S4PIENS_" },
] as const;

const STORIES = [
  { slug: "amazonia-more-than-a-forest", tag: "E4RTH_ · AM4ZONIA_", title: "AM4ZONIA: more than a forest", src: "/assets/missions/am4zonia/hero-mobile.jpg", alt: "A rainforest waterfall in dense canopy" },
  { slug: "credible-tree-pathway", tag: "E4RTH_ · CLIM4TE_", title: "What a credible tree pathway actually looks like", src: "/assets/brand/why-forest-mobile.jpg", alt: "A forested mountain valley" },
  { slug: "making-impact-easy", tag: "IMPACT", title: "Making impact easy — without making it fake", src: "/assets/brand/participation-field-mobile.jpg", alt: "A lone walker in a vast desert landscape" },
] as const;

const WAYS = [
  ["ATLAS", "See the planet in context", "https://4planetatlas.com/atlas/"],
  ["SPECIES", "Meet the life behind the data", "https://4species.com/species/"],
  ["LIVING SYSTEMS", "Discover how life connects", "/livingsystems/"],
  ["IMPACT", "Meet the people doing the work", "/impact"],
] as const;

function Ways() {
  return (
    <nav className="hp-ways" aria-label="Ways into 4PLANET">
      {WAYS.map(([name, line, to], i) => {
        const inner = (<><span className="hp-mono">0{i + 1} {name}</span><b>{line}</b></>);
        return to.startsWith("http")
          ? <a key={name} href={to}>{inner}</a>
          : <Link key={name} to={to} reloadDocument={to === "/livingsystems/"}>{inner}</Link>;
      })}
    </nav>
  );
}

const MAG = "https://4planetmagazine.com/magazine/";
const HOME_ATLAS_SRC = "/embed/atlas?l=bluemarble&c=0%2C15&z=1.35&t=light&embed=place";
const dkClass = (dk: Dk) => "hp-d-" + dk.replace("_", "").toLowerCase();

function Head({ kicker, title, lede, children }: { kicker: string; title: string; lede?: string; children?: ReactNode }) {
  return (
    <div className="hp-head">
      <div><p className="hp-mono">{kicker}</p><h2>{title}</h2></div>
      <div>{lede && <p className="hp-lede">{lede}</p>}{children}</div>
    </div>
  );
}

function AtlasSection() {
  const [live, setLive] = useState(false);
  return (
    <section className="hp-sec hp-dark hp-atlas" aria-labelledby="hp-atlas">
      <div className="hp-shell hp-atlas__grid">
        <div>
          <p className="hp-mono">ATLAS — Explore the planet</p>
          <h2 id="hp-atlas">One planet. Many relationships.</h2>
          <p className="hp-lede">Fly from the open ocean to the forests to the place you live. See where life is observed, where pressure builds and where people are already acting — always with the source and the date.</p>
          <div className="hp-chips">
            <Link to="/living-systems/oslofjord">Oslofjord</Link>
            <Link to="/living-systems/great-barrier-reef">Great Barrier Reef</Link>
            <Link to="/missions/am4zonia">Amazonia</Link>
            <Link to="/place/kenya">Kenya</Link>
          </div>
          <a className="hp-link" href="https://4planetatlas.com/atlas/">Open the full ATLAS ↗</a>
        </div>
        <div className="hp-atlas__window">
          {live
            ? <iframe src={HOME_ATLAS_SRC} title="Interactive 4PLANET Atlas" referrerPolicy="no-referrer" allowFullScreen />
            : (
              <button type="button" className="hp-atlas__poster" onClick={() => setLive(true)}>
                <img src="/assets/brand/earthrise.jpg" alt="" loading="lazy" decoding="async" />
                <span className="hp-btn">Start the live Atlas</span>
              </button>
            )}
        </div>
      </div>
    </section>
  );
}

function World({ w, flip }: { w: typeof WORLDS[number]; flip: boolean }) {
  const media = img(w.image);
  const missions = content.getMissionsByDomain(w.dk);
  return (
    <section className={`hp-world ${dkClass(w.dk)}${flip ? " hp-world--flip" : ""}`} aria-label={w.dk}>
      <Link to={`/domains/${w.slug}`} className="hp-world__media" tabIndex={-1} aria-hidden>
        <picture>
          {media.srcMobile && <source media="(max-width:900px)" srcSet={media.srcMobile} />}
          <img src={media.src} alt="" loading="lazy" decoding="async" style={{ objectPosition: media.objectPosition ?? "50% 50%" }} />
        </picture>
      </Link>
      <div className="hp-world__panel">
        <p className="hp-mono">{w.dk} · {w.system}</p>
        <h3><Link to={`/domains/${w.slug}`}>{w.dk.replace("_", "")}<span>_</span></Link></h3>
        <p className="hp-world__line">{w.line}</p>
        <ul className="hp-missions">
          {missions.map((m) => (
            <li key={m.slug}><Link to={`/missions/${m.slug}`}><b>{m.name}</b><span>{m.hero}</span></Link></li>
          ))}
        </ul>
        <Link to={`/domains/${w.slug}`} className="hp-link">Enter {w.dk.replace("_", "")} →</Link>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <PublicShell>
      <div className="hp">
        <AtlasHero><Ways /></AtlasHero>

        {/* PREMISE — curiosity, love, solutions */}
        <section className="hp-sec hp-premise">
          <div className="hp-shell hp-premise__grid">
            <p className="hp-mono">4PLANET_ — For a Living Planet</p>
            <div>
              <p className="hp-statement">Earth is the only place we know where life exists. It is astonishing, connected and worth protecting.</p>
              <p className="hp-lede">4PLANET makes the living planet easier to understand — and connects that understanding to people and projects already making things better. Every problem we show comes with someone working on the answer.</p>
            </div>
          </div>
        </section>

        <AtlasSection />

        {/* SPECIES */}
        <section className="hp-sec" aria-labelledby="hp-life">
          <div className="hp-shell">
            <Head kicker="SPECIES — Meet life" title="Meet the life behind the data." lede="Every species is a story of adaptation, relationship and survival. Start with one.">
              <a className="hp-link" href="https://4species.com/species/">All species on 4SPECIES ↗</a>
            </Head>
            <div className="hp-species">
              {SPECIES.map((s) => (
                <a key={s.slug} className="hp-sp" href={`https://4species.com/species/${s.slug}`}>
                  <div className="hp-sp__img"><img src={s.src} alt={s.name} loading="lazy" decoding="async" /></div>
                  <p className="hp-mono">{s.latin}</p>
                  <h3>{s.name}</h3>
                  <p>{s.line}</p>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* FOUR WORLDS · SIXTEEN MISSIONS */}
        <section className="hp-sec hp-sec--tight" aria-labelledby="hp-worlds" id="worlds">
          <div className="hp-shell">
            <Head kicker="Four domains · Sixteen missions" title="Four worlds. One living planet." lede="Ocean, land, human systems and culture are parts of the same living system. Each mission is a way in." />
          </div>
        </section>
        <div className="hp-worlds">{WORLDS.map((w, i) => <World key={w.dk} w={w} flip={i % 2 === 1} />)}</div>

        {/* IMPACT — two relationships: discovered work, and (soon) action through 4PLANET */}
        <section className="hp-sec hp-dark hp-impact" aria-labelledby="hp-impact">
          <div className="hp-shell">
            <Head kicker="IMPACT — Living Action Network" title="People bringing life back." lede="We seek out the strongest projects working on the planet’s biggest challenges, and make them easier to find, understand and support. A listing is recognition, not partnership.">
              <Link className="hp-link" to="/impact">Explore all projects →</Link>
            </Head>
            <div className="hp-projects">
              {PROJECTS.map((p) => (
                <Link key={p.slug} to={`/impact/project/${p.slug}/`} className={`hp-pj ${dkClass(p.d as Dk)}`}>
                  <p className="hp-mono">{p.kind} · {p.place}</p>
                  <h3>{p.title}</h3>
                  <p>{p.line}</p>
                  <span className="hp-pj__actor">{p.actor}</span>
                </Link>
              ))}
            </div>
            <p className="hp-note">Details and results come from each organisation’s public sources. Reported results are not independently verified by 4PLANET.</p>

            <div className="hp-soon">
              <div className="hp-soon__copy">
                <p className="hp-mono">Coming to 4PLANET</p>
                <h3>Act directly, with proof of what happened.</h3>
                <p>We are preparing Impact units with selected partners — plant trees, clear plastic, restore reefs — each with clear evidence of what was done. Join to hear first when they open.</p>
                <a href={JOIN_URL} className="hp-btn">Join 4PLANET</a>
              </div>
              <div className="hp-soon__units">
                {IMPACT_UNITS.slice(0, 4).map((u) => (
                  <figure key={u.slug}>
                    {!u.imagePending && <img src={u.imageMobile ?? u.image} alt={u.imageAlt} loading="lazy" decoding="async" />}
                    <figcaption><span className="hp-mono">In preparation</span>{u.action.charAt(0).toUpperCase() + u.action.slice(1).toLowerCase()}</figcaption>
                  </figure>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* MAGAZINE */}
        <section className="hp-sec" aria-labelledby="hp-mag">
          <div className="hp-shell">
            <Head kicker="4PLANET MAGAZINE" title="Stories from a living planet." lede="Small and big stories about life on Earth, and the people finding ways forward.">
              <a className="hp-link" href={MAG}>Read the Magazine ↗</a>
            </Head>
            <div className="hp-stories">
              {STORIES.map((s, i) => (
                <a key={s.slug} href={MAG + s.slug} className={"hp-story" + (i === 0 ? " hp-story--lead" : "")}>
                  <div className="hp-story__img"><img src={s.src} alt={s.alt} loading="lazy" decoding="async" /></div>
                  <p className="hp-mono">{s.tag}</p>
                  <h3>{s.title}</h3>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* JOIN */}
        <section className="hp-sec hp-join" aria-labelledby="hp-join">
          <div className="hp-shell hp-join__grid">
            <div>
              <p className="hp-mono">Join 4PLANET</p>
              <h2 id="hp-join">Join us — for the planet.</h2>
            </div>
            <div>
              <p className="hp-lede">Create your free 4PLANET ID. One account across 4PLANET — and the first to know when you can act through us. There is a place for everyone who wants to help — including you.</p>
              <div className="hp-actions">
                <a href={JOIN_URL} className="hp-btn hp-btn--white">Create your 4PLANET ID</a>
                <Link to="/signal" className="hp-btn hp-btn--ghost">Email updates only</Link>
              </div>
              <p className="hp-join__tool"><span className="hp-mono">Useful today</span> <a href="https://4sapien.com">Ask Embla on 4SAPIEN ↗</a> — better everyday food choices, with the facts and sources shown.</p>
            </div>
          </div>
        </section>

        {/* BELIEF */}
        <section className="hp-sec" aria-labelledby="hp-belief">
          <div className="hp-shell hp-belief">
            <figure className="hp-belief__img">
              <img src={img("s4piensFieldResearcher").src} alt={img("s4piensFieldResearcher").alt} loading="lazy" decoding="async" />
            </figure>
            <div>
              <p className="hp-mono">What we believe</p>
              <h2 id="hp-belief">We believe the future can be better.</h2>
              <p className="hp-lede">Care deeply. Truth first. Everyone has a part to play. Build things that are useful, make them real, use power for good — and leave things better.</p>
              <ul className="hp-index">
                <li><Link to="/about/story">The story <span>→</span></Link></li>
                <li><Link to="/about/what-we-believe">What we believe <span>→</span></Link></li>
                <li><Link to="/about/system">The system <span>→</span></Link></li>
                <li><Link to="/about/founder">The founder <span>→</span></Link></li>
              </ul>
              <div className="hp-theme"><span className="hp-mono">Appearance</span><GoldThemeToggle /></div>
            </div>
          </div>
        </section>
      </div>
    </PublicShell>
  );
}
