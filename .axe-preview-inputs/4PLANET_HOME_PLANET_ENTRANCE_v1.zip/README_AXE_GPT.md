# 4PLANET.ORG HOMEPAGE — PLANET ENTRANCE 01 (code)
**Status:** OUTPUT RECEIVED / AWAITING GPT AUDIT. Preview only. No merge or production deploy without the founder gate.
**Issue:** P1 #13 under PRODUCT 1 #10 · **Base:** `main` @ `edb37456` · **Branch:** `claude/home-planet-entrance-01` · **Commit:** `efd04c0c`
**Founder decisions applied (31 Oct):**
- Keep the planet hero, full-bleed. Not orca.
- Primary action is **Join 4PLANET**, which opens 4PLANET ID sign-up.
- Impact units are not live yet: show them honestly as "in preparation".
- Sister sites link out to 4species.com, 4planetmagazine.com and 4planetatlas.com.

## What changed (5 files)
| File | Change |
|---|---|
| `src/pages/v5/Home.tsx` | New homepage sequence: **Hero → Premise → ATLAS → SPECIES → Four worlds / 16 missions → IMPACT → MAGAZINE → Join → Belief**.<br>Missions come from `content.getMissionsByDomain`, so all 16 stay in sync with canon. IMPACT shows 6 curated Living Action Network projects plus 4 existing `IMPACT_UNITS` images as "In preparation" (no links to the old `/impact/:slug` prototype).<br>Dark/light switch reuses `GoldThemeToggle`. |
| `src/pages/v5/AtlasHero.tsx` | Full-bleed Earth hero:<br>• `<picture>` with mobile source and `fetchpriority=high`<br>• data line "Earth · 6,371 km radius · The only known living planet"<br>• Join 4PLANET as primary CTA, Explore the planet as secondary<br>• four ways in rendered inside the first fold |
| `src/styles/home-brand-reset.css` | Rewritten and scoped to `.hp`. Brand OS colours. Section colour system with readable contrast:<br>• OCE4N: navy #0D0A1E with white text<br>• E4RTH: #3AE86F with black text<br>• S4PIENS: #FF4D22 with black text<br>• 4CULTURE: #FF5ACD with black text (white on pink fails WCAG, 2.4:1)<br>Dark mode is driven by `html[data-fourplanet-theme=dark]`. |
| `index.html` | Variable font ranges (`Instrument Sans wght 400..700`, `DM Sans 300..700`), so the 450 display weight actually renders. `og:image` / `twitter:image` now use absolute URLs. |
| `tests/e2e/gold-human-craft.spec.ts` | Homepage assertions updated: the old ones referenced headings that no longer exist on `main`. New assertions:<br>• Join link<br>• 4 ways in, including the `/livingsystems/` document route<br>• Atlas iframe absent until clicked, then the MapLibre canvas loads<br>• 4 species, 4 worlds, **16 mission links**, 6 `/impact/project/` links<br>• values heading<br>• no horizontal overflow |

**Untouched on purpose:**
- `App.tsx` host branching, `router.tsx`, `PublicShell.tsx`
- Atlas camera lock and authority
- All other routes

Preserved markers: `live-promotion-authority-gate` VALUES markers in Home.tsx, and the `living-systems-v142-zero-loss` contract (passes).

## Verified locally
- `tsc --noEmit` clean.
- ESLint clean on the changed files.
- `vite build` OK.
- `node scripts/living-systems-v142-zero-loss.test.mjs` passes.
- Screenshots of a local build, 390×844 and 1440×900, are in `evidence/`. Fonts were substituted with the same families because Google Fonts and live are not reachable from the sandbox, and external tiles were blocked.
- **Not run here:** Playwright e2e (needs a preview server with Atlas tiles), the full `test:smoke`, and the prebuild/live snapshot.

| Measured (local build, lower bound) | Baseline `edb37456` | This branch |
|---|---|---|
| Mobile transfer for a full scroll | ≈ 9.3 MB | ≈ 6.2 MB |
| Atlas app boots on load | Yes (second 1.96 MB app in iframe) | No (on click) |
| Mission links on home | 0 | 16 |
| Real IMPACT project links | 0 | 6 |
| Page length, mobile / desktop | 12.4 / 12.5 screens | 14.5 / 12.9 screens (adds species, 16 missions, IMPACT, Magazine, Join) |

## Apply, preview, rollback
```bash
git checkout -b claude/home-planet-entrance-01 edb37456
git am 0001-feat-home-planet-entrance-join-4PLANET-sixteen-missi.patch
npm ci && npm run build        # includes prebuild snapshots, so record generated-file diffs first
npx wrangler pages deploy dist --project-name <4planet-pages-project> --branch claude-home-planet-entrance-01   # preview only
npx playwright test tests/e2e/gold-human-craft.spec.ts
# Rollback: git revert efd04c0c  (or redeploy the previous production deployment in Cloudflare Pages)
```
Cloudflare Pages: build `npm run build`, output `dist`, Node as in the current project settings. No new environment variables.

## Known limitations / next PR
- The main JS bundle is still about 1.96 MB. Code-splitting goes in a separate PR with the host and camera differential proof agreed earlier.
- Domain desktop images are still JPEG, including `culture-anchor.jpg` at 916 kB. AVIF/WebP pipeline is the next PR.
- Curated species, projects and stories are editorial constants in Home.tsx. Moving them to the IMPACT snapshot or a CMS is optional later.
- The identity sign-up UI is in Norwegian ("Opprett 4PLANET ID") while the site is British English.

## Open questions (please resolve before production)
1. **4PLANET ID:** does `https://id.4planet.org/login?mode=signup` work end-to-end in production now (email confirmation, return to 4planet.org)? If not, Join must point to `/signal` until it does.
2. **Sister URLs:** confirm these return 200 on live:
   - `4species.com/species/{orca,humpback-whale,jaguar,hyacinth-macaw}`
   - `4planetmagazine.com/magazine/{amazonia-more-than-a-forest,credible-tree-pathway,making-impact-easy}`
   - `4planetatlas.com/atlas/`
3. **IMPACT curation:** confirm the 6 slugs return 200 with trailing slash. Check each source/date again, especially the Acarai–Rupununi pledge (30 Oct) and Phoenix (a funding commitment, not recovery). Is founder approval of the selection required?
4. **Rights:** confirm image rights for the 4 `IMPACT_UNITS` images, the species images (orca spyhop, SP-001, SP-005, SP-006) and `earthrise.jpg` as the Atlas poster.
5. **Fact lines:** the species one-liners and the hero data line are general knowledge. Does the founder want sources linked on the species cards?
6. **Theme:** should dark mode remain home-only, or should `PublicShell` adopt the same switch site-wide?
7. **Bug outside scope:** `public/assets/brand/founder-grass.jpg` is not a valid image (used on `/about/founder`). Please replace it from the original.
