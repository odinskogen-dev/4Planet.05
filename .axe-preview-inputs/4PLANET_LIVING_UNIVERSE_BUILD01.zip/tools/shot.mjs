// Usage: node shot.mjs <rootDir> <outPrefix> [path]
// Serves rootDir with SPA fallback, substitutes Google Fonts with local fontsource files,
// blocks other external requests, and captures first-fold + full-page at 390 and 1440.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");

const [root, outPrefix, route = "/"] = process.argv.slice(2);
const FONTS = path.resolve("node_modules");
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".avif": "image/avif", ".woff2": "font/woff2", ".json": "application/json", ".mp4": "video/mp4" };

const server = http.createServer((req, res) => {
  const u = decodeURIComponent(new URL(req.url, "http://x").pathname);
  let file = u.startsWith("/__fonts/") ? path.join(FONTS, u.slice(9)) : path.join(root, u);
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    const idx = path.join(file, "index.html");
    file = fs.existsSync(idx) ? idx : path.join(root, "index.html");
  }
  res.writeHead(200, { "content-type": types[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
}).listen(0);
const port = server.address().port;

const fontCss = `
@font-face{font-family:'DM Sans';font-style:normal;font-weight:100 1000;font-display:swap;src:url(/__fonts/@fontsource-variable/dm-sans/files/dm-sans-latin-opsz-normal.woff2) format('woff2')}
@font-face{font-family:'Instrument Sans';font-style:normal;font-weight:400 700;font-display:swap;src:url(/__fonts/@fontsource-variable/instrument-sans/files/instrument-sans-latin-wght-normal.woff2) format('woff2')}
@font-face{font-family:'Fragment Mono';font-style:normal;font-weight:400;font-display:swap;src:url(/__fonts/@fontsource/fragment-mono/files/fragment-mono-latin-400-normal.woff2) format('woff2')}`;

const browser = await chromium.launch();
const stats = {};
for (const [name, vp] of [["mobile390", { width: 390, height: 844 }], ["desktop1440", { width: 1440, height: 900 }]]) {
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, reducedMotion: "reduce" });
  const page = await ctx.newPage();
  let bytes = 0;
  page.on("response", async (r) => { try { const b = await r.body(); bytes += b.length; } catch {} });
  await page.route("**/*", (r) => {
    const url = r.request().url();
    if (url.startsWith("https://fonts.googleapis.com")) return r.fulfill({ contentType: "text/css", body: fontCss });
    if (url.startsWith(`http://localhost:${port}`) || url.startsWith("data:")) return r.continue();
    return r.abort();
  });
  await page.goto(`http://localhost:${port}${route}`, { waitUntil: "load" });
  await page.waitForTimeout(1200);
  // Force Reveal()/IO-gated content visible for full-page capture.
  await page.evaluate(async () => {
    for (let y = 0; y < document.body.scrollHeight; y += 600) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 60)); }
    window.scrollTo(0, 0);
  });
  await page.waitForTimeout(800);
  await page.screenshot({ path: `${outPrefix}-${name}-fold.png` });
  const h = await page.evaluate(() => document.documentElement.scrollHeight);
  await page.screenshot({ path: `${outPrefix}-${name}-full.png`, fullPage: true });
  stats[name] = { pageHeightPx: h, screens: +(h / vp.height).toFixed(1), transferredKB: Math.round(bytes / 1024) };
  await ctx.close();
}
console.log(JSON.stringify(stats));
await browser.close();
server.close();
