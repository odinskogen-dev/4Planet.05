# 4PLANET LIVING UNIVERSE — BUILD 01: ENGINE + ORCA JOURNEY + DISTRIBUTION
**Status:** OUTPUT RECEIVED / AWAITING GPT AUDIT. Preview only. No merge or deploy without the founder gate.
**Base:** `main` @ `edb37456` · **Branch:** `claude/home-planet-entrance-01` · **Commits:** `efd04c0c` (homepage V1), `ecee0b11` (Living Universe)
**Patches:** `patches/0001…`, `patches/0002…` (apply with `git am` onto `edb37456`)

## 1. Revised plan (distribution built in from day one)
The engine now has a sixth shared capability, **Discovery & Distribution**, used by every block:

| Block | Experience (people) | Discovery (search / AI / sharing) |
|---|---|---|
| Living Window | 2.5D habitat, opt-in 3D | Plate image + alt text; truth boundary as text |
| Discovery Layer | Hotspots: hover / tap / focus → card → open | Every hotspot is a real link with an evidence label |
| Living Thread | Radial drawing | **The content is an `<ol>`**: relation, target, detail, evidence, source link |
| Journey Engine | Chapters, rail, own pace | One stable URL, `#chapter` anchors, Article JSON-LD with `hasPart`, crawler HTML from middleware |
| Distribution | Share this discovery (Web Share / copy), Story card download, Follow (`follow.ts`), Join, Become the orca | Per-journey OG card (1200×630) + Story card (1080×1920); `og:image` set per route in middleware |

**Rule kept:** 3D is presentation only. Every fact exists in readable HTML, and the same facts are served to crawlers via `functions/_middleware.js` (existing `/journey/:slug` config, extended).

## 2. What was built (commit `ecee0b11`)
| File | What |
|---|---|
| `src/universe/model.ts` | Shared types: Journey, Chapter (9 kinds), Hotspot, ThreadEdge, Proof (established / documented / reported / context / uncertain) |
| `src/universe/journeys/orca.ts` | **Orca Journey data.** General facts sourced to NOAA Fisheries. Pressures named only for the Southern Resident population. 2 IMPACT projects marked as *context, not orca-specific*. |
| `src/universe/LivingWindow.tsx` | 2.5D scene: plate, depth, light rays, marine snow (canvas, pauses off-screen and for reduced motion), hotspots, «Dive in 3D» |
| `src/universe/Orca3D.tsx` | Three.js scene, lazy chunk of 145 kB gzip.<br>• Orca GLB baked like WILD: ORCA (first mesh × `matrixWorld`, head → +Z)<br>• procedural fluke beat, fog, marine snow, pointer parallax<br>• pauses off-screen; credit "Abner Wu · CC BY 4.0" shown |
| `src/universe/Thread.tsx` | Living Thread (SVG + accessible list + legend) |
| `src/universe/Share.tsx` | ShareBar + FollowButton (analytics events: `journey_share`, `journey_story_card`, `follow_added`) |
| `src/universe/JourneyPage.tsx` | Route `/journey/:slug` with Seo + JSON-LD, chapter rail, Atlas on demand |
| `src/styles/universe.css` | Brand OS; proof-state colour and line language |
| `src/pages/v5/Home.tsx` + CSS | • New «Dive into the living ocean» habitat teaser → Orca Journey<br>• domains as a compact 2×2 grid with all 16 missions<br>• AXE copy fixes: removed «every problem…», «strongest projects», «selected partners», «first to know»<br>• aria ids fixed; dark-mode link contrast fixed<br>• «Support 4PLANET → /funders» |
| `functions/_middleware.js` | `/journey/orca` gets real title, description, 6 fact paragraphs, 5 links and Article schema; `og:image` / `twitter:image` per route when `config.image` is set |
| `public/robots.txt` | Explicit `Allow` for `Claude-SearchBot` and `Claude-User`. **Training-bot policy unchanged.** |
| `public/journey/orca/classic/` | Old static orca journey preserved, not deleted (it would otherwise shadow the new React route) |
| `tests/e2e/living-universe-journey.spec.ts` | New e2e test covering:<br>• 9 chapters, 4 hotspots (keyboard), 5 edges each with a source<br>• truth boundary, 2 IMPACT links<br>• share and follow<br>• 3D opt-in |
| `package.json` | `three@0.170.0` + `@types/three` |

## 3. Verified here
- `tsc` clean, ESLint clean, `vite build` OK, middleware syntax OK, and the `living-systems-v142-zero-loss` contract test passes.
- Assertions run with the installed Chromium. The repo's `@playwright/test` browser was missing, so the equivalent script is `tools/journeytest.mjs`. Results:
  - All 9 chapters, 4 hotspots, keyboard proof label, 5 sourced edges, truth boundary, IMPACT links, share, follow, 3D opt-in
  - Home has 16 missions and links to the journey
  - No horizontal overflow on desktop or 390 px mobile
- **3D rendered in headless Chromium (SwiftShader):** the orca is visible with correct orientation (`evidence/v4-habitat-3d.jpg`). Real-device FPS is **not** measured.
- Bundle: main entry +≈6 kB gzip; JourneyPage 3 kB gzip; Three/Orca3D 145 kB gzip loads only on «Dive in 3D».
- **Not done:** live-host tests, Search Console / Bing validation, IndexNow submit. The sitemap already lists `/journey/orca/`.

## 4. Apply, preview, rollback
```bash
git checkout -b living-universe-01 edb37456 && git am patches/*.patch
npm ci && npm run build      # record prebuild-generated diffs first
npx wrangler pages deploy dist --project-name <pages-project> --branch living-universe-01   # preview only
npx playwright test tests/e2e/living-universe-journey.spec.ts tests/e2e/gold-human-craft.spec.ts
# Rollback: git revert ecee0b11 efd04c0c, or redeploy the previous Pages deployment
```

## 5. Next builds (same engine)
1. **Jaguar / AM4ZONIA journey:** new data file plus forest plate. The jaguar 3D runtime exists. This is the reuse test (target ≤ 25 % of the effort).
2. **Journeys index `/journey/`** and «Choose a journey» on the homepage.
3. **Living Collections:** save objects with `follow.ts`, then «My Living Planet» summary card (Wrapped-style) after 4PLANET ID is verified.
4. **Embeddable objects:** `/embed/thread/orca`, plus a species card embed for NGOs, media and teachers.
5. **IndexNow on publish** and Search Console / Bing AI Performance baseline.
6. **Support page:** Vipps Donasjoner once the legal entity and agreement are confirmed. Official donate links for IMPACT projects.

## 6. Open questions / blockers
1. **Rights:**
   - Orca GLB (CC BY 4.0, Abner Wu; ORCAST modifications): is visible credit enough? Should it link to the upstream source?
   - `species/orca/hero.jpg` (habitat plate) and `detail-pod.jpg` (share cards): source and licence?
2. **Facts:** confirm the NOAA Fisheries killer whale page as an acceptable source, and that the Southern Resident pressures are worded correctly.
3. **IMPACT in the journey:** Global Fishing Watch and Oceana are shown as *context, not orca-specific*. Approved? Are there more relevant orca or North Atlantic projects for NATUREBRAIN?
4. **Magazine URL:** `4planetmagazine.com/magazine/wh4les-migratory-intelligence` must return 200.
5. **WILD: ORCA:** is `/games/wild-orca/` the correct public URL for «Become the orca»?
6. **Old journey:** OK to move the static v17 journey to `/journey/orca/classic/`? Should `/journey/jaguar/` stay static until its React version exists?
7. **robots.txt:** I added only search and user-fetch bots. Founder decision needed on training bots (GPTBot, ClaudeBot, Google-Extended).
8. **4PLANET ID sign-up** end-to-end (still blocking Join).
9. **Instagram / Living Planet Brief:** the official Instagram handle and email owner, so links and signup can be added.
10. **Support 4PLANET:** which legal entity receives funds, and is Vipps Donasjoner approved?
